/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;
import org.apache.uima.jcas.tcas.Annotation;

public class DiscourseFeatures extends Annotation {
  /**
   * @generated
   * @ordered
   */
  public final static int typeIndexID = JCasRegistry.register(DiscourseFeatures.class);
  /**
   * @generated
   * @ordered
   */
  public final static int type = typeIndexID;

  /** @generated */
  @Override
  public int getTypeIndexID() {
    return typeIndexID;
  }

  /**
   * Never called. Disable default constructor
   * 
   * @generated
   */
  public DiscourseFeatures() {}

  /**
   * Internal - constructor used by generator
   * 
   * @generated
   */
  public DiscourseFeatures(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  /** @generated */
  public DiscourseFeatures(JCas jCas) {
    super(jCas);
    readObject();
  }

  /** @generated */
  public DiscourseFeatures(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  /**
   * <!-- begin-user-doc --> Write your own initialization here <!-- end-user-doc -->
   * 
   * @generated modifiable
   */
  private void readObject() {}

  // *--------------*
  // * Feature: matchesMFFontName
  /**
   * getter for matchesMFFontName
   * 
   * @generated
   */
  public boolean matchesMFFontName() {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_matchesMFFontName == null) {
      jcasType.jcas.throwFeatMissing("matchesMFFontName",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_matchesMFFontName);
  }

  /**
   * setter for matchesMFFontName
   * 
   * @generated
   */
  public void setMatchesMFFontName(boolean v) {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_matchesMFFontName == null) {
      jcasType.jcas.throwFeatMissing("matchesMFFontName",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_matchesMFFontName, v);
  }

  // *--------------*
  // * Feature: matchesMFFontSize
  /**
   * getter for matchesMFFontSize
   * 
   * @generated
   */
  public boolean matchesMFFontSize() {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_matchesMFFontSize == null) {
      jcasType.jcas.throwFeatMissing("matchesMFFontSize",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_matchesMFFontSize);
  }

  /**
   * setter for matchesMFFontSize
   * 
   * @generated
   */
  public void setMatchesMFFontSize(boolean v) {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_matchesMFFontSize == null) {
      jcasType.jcas.throwFeatMissing("matchesMFFontSize",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_matchesMFFontSize, v);
  }

  // *--------------*
  // * Feature: matchesMFFontItalic
  /**
   * getter for matchesMFFontItalic
   * 
   * @generated
   */
  public boolean matchesMFFontItalic() {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_matchesMFFontItalic == null) {
      jcasType.jcas.throwFeatMissing("matchesMFFontItalic",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_matchesMFFontItalic);
  }

  /**
   * setter for matchesMFFontItalic
   * 
   * @generated
   */
  public void setMatchesMFFontItalic(boolean v) {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_matchesMFFontItalic == null) {
      jcasType.jcas.throwFeatMissing("matchesMFFontItalic",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_matchesMFFontItalic, v);
  }

  // *--------------*
  // * Feature: matchesMFFontBold
  /**
   * getter for matchesMFFontBold
   * 
   * @generated
   */
  public boolean matchesMFFontBold() {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_matchesMFFontBold == null) {
      jcasType.jcas.throwFeatMissing("matchesMFFontBold",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_matchesMFFontBold);
  }

  /**
   * setter for matchesMFFontBold
   * 
   * @generated
   */
  public void setMatchesMFFontBold(boolean v) {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_matchesMFFontBold == null) {
      jcasType.jcas.throwFeatMissing("matchesMFFontBold",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_matchesMFFontBold, v);
  }

  // *--------------*
  // * Feature: pctMFNP
  /**
   * getter for pctMFNP
   * 
   * @generated
   */
  public double getPctMFNP() {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_pctMFNP == null) {
      jcasType.jcas.throwFeatMissing("pctMFNP",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return jcasType.ll_cas.ll_getDoubleValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_pctMFNP);
  }

  /**
   * setter for pctMFNP
   * 
   * @generated
   */
  public void setPctMFNP(double v) {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_pctMFNP == null) {
      jcasType.jcas.throwFeatMissing("pctMFNP",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    jcasType.ll_cas.ll_setDoubleValue(addr, ((DiscourseFeatures_Type) jcasType).casFeatCode_pctMFNP,
        v);
  }

  // *--------------*
  // * Feature: idPatternFrequency
  /**
   * getter for idPatternFrequency
   * 
   * @generated
   */
  public String getIdPatternFrequency() {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_idPatternFrequency == null) {
      jcasType.jcas.throwFeatMissing("idPatternFrequency",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_idPatternFrequency);
  }

  /**
   * setter for idPatternFrequency
   * 
   * @generated
   */
  public void setIdPatternFrequency(String v) {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_idPatternFrequency == null) {
      jcasType.jcas.throwFeatMissing("idPatternFrequency",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    jcasType.ll_cas.ll_setStringValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_idPatternFrequency, v);
  }

  // *--------------*
  // * Feature: hasMFModal
  /**
   * getter for hasMFModal
   * 
   * @generated
   */
  public boolean hasMFModal() {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_hasMFModal == null) {
      jcasType.jcas.throwFeatMissing("hasMFModal",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_hasMFModal);
  }

  /**
   * setter for hasMFModal
   * 
   * @generated
   */
  public void setHasMFModal(boolean v) {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_hasMFModal == null) {
      jcasType.jcas.throwFeatMissing("hasMFModal",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_hasMFModal, v);
  }

  // *--------------*
  // * Feature: hasMFNP
  /**
   * getter for hasMFNP
   * 
   * @generated
   */
  public boolean hasMFNP() {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_hasMFNP == null) {
      jcasType.jcas.throwFeatMissing("hasMFNP",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_hasMFNP);
  }

  /**
   * setter for hasMFNP
   * 
   * @generated
   */
  public void setHasMFNP(boolean v) {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_hasMFNP == null) {
      jcasType.jcas.throwFeatMissing("hasMFNP",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_hasMFNP, v);
  }

  // *--------------*
  // * Feature: matchesMFCategory
  /**
   * getter for matchesMFCategory
   * 
   * @generated
   */
  public boolean matchesMFCategory() {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_matchesMFCategory == null) {
      jcasType.jcas.throwFeatMissing("matchesMFCategory",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_matchesMFCategory);
  }

  /**
   * setter for matchesMFCategory
   * 
   * @generated
   */
  public void setMatchesMFCategory(boolean v) {
    if (DiscourseFeatures_Type.featOkTst
        && ((DiscourseFeatures_Type) jcasType).casFeat_matchesMFCategory == null) {
      jcasType.jcas.throwFeatMissing("matchesMFCategory",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((DiscourseFeatures_Type) jcasType).casFeatCode_matchesMFCategory, v);
  }

}
