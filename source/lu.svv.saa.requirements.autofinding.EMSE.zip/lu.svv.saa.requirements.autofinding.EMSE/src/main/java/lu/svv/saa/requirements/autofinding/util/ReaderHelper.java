/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.util;

import java.util.Collections;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.aspose.words.Paragraph;

public class ReaderHelper {

  /*** changing the numbering style from d. into d) ***/
  public static String changeNumbering(String text) {
    text = text.replaceAll("\\s+", " ");
    if (text.trim().length() <= 2) {
      return text;
    }
    String pattern = "^[a-zA-Z]+\\.\\s";// 0-9
    Pattern p = Pattern.compile(pattern);
    Matcher m = p.matcher(text);
    if (m.find()) {
      if (text.substring(0, text.indexOf(".")).length() <= 3)
        return text.replaceFirst("\\.", ")");
    }
    pattern = "^[[0-9]+\\.]+\\s";
    p = Pattern.compile(pattern);
    m = p.matcher(text);
    if (m.find() && text.split(" ")[0].trim().endsWith(".")) {
      return text = text.substring(0, m.end() - 2) + ") " + text.substring(m.end());
    }
    pattern = "^[[0-9]\\.]+\\s";
    p = Pattern.compile(pattern);
    m = p.matcher(text);
    if (m.find() && text.split(" ")[0].trim().endsWith(".")) {
      return text = text.substring(0, m.end() - 2) + ") " + text.substring(m.end());
    }
    return text;
  }

  public String getMFName(Map<String, Integer> map) {
    String result = "";
    int maxValueInMap = (Collections.max(map.values()));
    for (Entry<String, Integer> entry : map.entrySet()) {
      if (entry.getValue() == maxValueInMap) {
        result = entry.getKey();
      }
    }
    return result;
  }

  public int getMFSize(Map<Integer, Integer> map) {
    int result = -1;
    int maxValueInMap = (Collections.max(map.values()));
    for (Entry<Integer, Integer> entry : map.entrySet()) {
      if (entry.getValue() == maxValueInMap) {
        result = entry.getKey();
      }
    }
    return result;
  }

  public String extractNumbering(Paragraph paragraph) {
    String numbering = "";
    if (paragraph.isListItem()) {
      char[] format = paragraph.getListFormat().getListLevel().getNumberFormat().toCharArray();
      int numstyle = paragraph.getListFormat().getListLevel().getNumberStyle();
      String special = "$";
      if (numstyle == 0) {
        special = "1";// d
      } else if (numstyle == 4) {
        special = "c";
      } else if (numstyle == 3) {
        special = "C";
      }
      for (char t : format) {
        if (Character.toString(t).trim().isEmpty()) {
          numbering += special;
        } else {
          numbering += t;
        }
      }
    }
    return numbering;
  }
}
