/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;
import org.apache.uima.jcas.tcas.Annotation;

public class SyntacticalFeatures extends Annotation {
  /**
   * @generated
   * @ordered
   */
  public final static int typeIndexID = JCasRegistry.register(SyntacticalFeatures.class);
  /**
   * @generated
   * @ordered
   */
  public final static int type = typeIndexID;

  /** @generated */
  @Override
  public int getTypeIndexID() {
    return typeIndexID;
  }

  /**
   * Never called. Disable default constructor
   * 
   * @generated
   */
  public SyntacticalFeatures() {}

  /**
   * Internal - constructor used by generator
   * 
   * @generated
   */
  public SyntacticalFeatures(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  /** @generated */
  public SyntacticalFeatures(JCas jCas) {
    super(jCas);
    readObject();
  }

  /** @generated */
  public SyntacticalFeatures(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  /**
   * <!-- begin-user-doc --> Write your own initialization here <!-- end-user-doc -->
   * 
   * @generated modifiable
   */
  private void readObject() {}

  // *--------------*
  // * Feature: sentenceType

  /**
   * getter for sentenceType
   * 
   * @generated
   * @return value of the feature
   */
  public SentenceType getSentenceType() {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_sentenceType == null)
      jcasType.jcas.throwFeatMissing("sentenceType",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    return (SentenceType) (jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_sentenceType)));
  }

  /**
   * setter for sentenceType
   * 
   * @generated
   * @param v value to set into the feature
   */
  public void setSentenceType(SentenceType v) {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_sentenceType == null)
      jcasType.jcas.throwFeatMissing("sentenceType",
          "dlu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    jcasType.ll_cas.ll_setRefValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_sentenceType,
        jcasType.ll_cas.ll_getFSRef(v));
  }


  // *--------------*
  // * Feature: hasVerb

  /**
   * getter for hasVerb
   * 
   * @generated
   */
  public boolean hasVerb() {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_hasVerb == null) {
      jcasType.jcas.throwFeatMissing("hasVerb",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_hasVerb);
  }

  /**
   * setter for hasVerb
   * 
   * @generated
   */
  public void setHasVerb(boolean v) {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_hasVerb == null) {
      jcasType.jcas.throwFeatMissing("hasVerb",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_hasVerb, v);
  }

  // *--------------*
  // * Feature: startsWithVerb

  /**
   * getter for startsWithVerb
   * 
   * @generated
   */
  public boolean sartsWithVerb() {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_startsWithVerb == null) {
      jcasType.jcas.throwFeatMissing("startsWithVerb",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_startsWithVerb);
  }

  /**
   * setter for number of words
   * 
   * @generated
   */
  public void setStartsWithVerb(boolean v) {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_startsWithVerb == null) {
      jcasType.jcas.throwFeatMissing("id",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_startsWithVerb, v);
  }

  // *--------------*
  // * Feature: startsWithPronoun

  /**
   * getter for startsWithPronoun
   * 
   * @generated
   */
  public boolean sartsWithPronoun() {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_startsWithPronoun == null) {
      jcasType.jcas.throwFeatMissing("startsWithPronoun",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_startsWithPronoun);
  }

  /**
   * setter for number of words
   * 
   * @generated
   */
  public void setStartsWithPronoun(boolean v) {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_startsWithPronoun == null) {
      jcasType.jcas.throwFeatMissing("id",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_startsWithPronoun, v);
  }

  // *--------------*
  // * Feature: startsWithDTVB

  /**
   * getter for startsWithDTVB
   * 
   * @generated
   */
  public boolean sartsWithDTVB() {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_startsWithDTVB == null) {
      jcasType.jcas.throwFeatMissing("startsWithDTVB",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_startsWithDTVB);
  }

  /**
   * setter for number of words
   * 
   * @generated
   */
  public void setStartsWithDTVB(boolean v) {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_startsWithDTVB == null) {
      jcasType.jcas.throwFeatMissing("id",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_startsWithDTVB, v);
  }

  // *--------------*
  // * Feature: hasModal

  /**
   * getter for hasModal
   * 
   * @generated
   */
  public boolean hasModal() {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_hasModal == null) {
      jcasType.jcas.throwFeatMissing("hasModal",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_hasModal);
  }

  /**
   * setter for hasModal
   * 
   * @generated
   */
  public void setHasModal(boolean v) {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_hasModal == null) {
      jcasType.jcas.throwFeatMissing("hasModal",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_hasModal, v);
  }

  // *--------------*
  // * Feature: whichModals

  /**
   * Getter for whichModals
   * 
   * @generated
   */
  public String getWhichModals() {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_whichModals == null)
      jcasType.jcas.throwFeatMissing("whichModals",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_whichModals);
  }

  /**
   * Getter for whichModals
   * 
   * @generated
   */
  public void setWhichModals(String v) {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_whichModals == null)
      jcasType.jcas.throwFeatMissing("whichModals",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    jcasType.ll_cas.ll_setStringValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_whichModals, v);
  }


  // *--------------*
  // * Feature: hasNPmodalVP

  /**
   * getter for hasNPmodalVP
   * 
   * @generated
   */
  public boolean hasNPmodalVP() {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_hasNPmodalVP == null) {
      jcasType.jcas.throwFeatMissing("hasNPmodalVP",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_hasNPmodalVP);
  }

  /**
   * setter for hasNPmodalVP
   * 
   * @generated
   */
  public void setHasNPmodalVP(boolean v) {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_hasNPmodalVP == null) {
      jcasType.jcas.throwFeatMissing("hasNPmodalVP",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_hasNPmodalVP, v);
  }

  // *--------------*
  // * Feature: isConditional

  /**
   * getter for isConditional
   * 
   * @generated
   */
  public boolean isConditional() {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_isConditional == null) {
      jcasType.jcas.throwFeatMissing("isConditional",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_isConditional);
  }

  /**
   * setter for isConditional
   * 
   * @generated
   */
  public void setIsConditional(boolean v) {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_isConditional == null) {
      jcasType.jcas.throwFeatMissing("isConditional",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_isConditional, v);
  }

  // *--------------*
  // * Feature: hasPassive

  /**
   * getter for hasPassive
   * 
   * @generated
   */
  public boolean hasPassive() {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_hasPassive == null) {
      jcasType.jcas.throwFeatMissing("hasPassive",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_hasPassive);
  }

  /**
   * setter for hasPassive
   * 
   * @generated
   */
  public void setHasPassive(boolean v) {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_hasPassive == null) {
      jcasType.jcas.throwFeatMissing("hasPassive",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_hasPassive, v);
  }

  // *--------------*
  // * Feature: isPresentTense

  /**
   * getter for isPresentTense
   * 
   * @generated
   */
  public boolean isPresentTense() {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_isPresentTense == null) {
      jcasType.jcas.throwFeatMissing("isPresentTense",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_isPresentTense);
  }

  /**
   * setter for isPresentTense
   * 
   * @generated
   */
  public void setIsPresentTense(boolean v) {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_isPresentTense == null) {
      jcasType.jcas.throwFeatMissing("isPresentTense",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_isPresentTense, v);
  }
  
  // *--------------*
  // * Feature: hasVerbToBeAdj

  /**
   * getter for hasVerbToBeAdj
   * 
   * @generated
   */
  public boolean hasVerbToBeAdj() {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_hasVerbToBeAdj == null) {
      jcasType.jcas.throwFeatMissing("hasVerbToBeAdj",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_hasVerbToBeAdj);
  }

  /**
   * setter for hasVerbToBeAdj
   * 
   * @generated
   */
  public void setHasVerbToBeAdj(boolean v) {
    if (SyntacticalFeatures_Type.featOkTst
        && ((SyntacticalFeatures_Type) jcasType).casFeat_hasVerbToBeAdj == null) {
      jcasType.jcas.throwFeatMissing("hasVerbToBeAdj",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SyntacticalFeatures_Type) jcasType).casFeatCode_hasVerbToBeAdj, v);
  }
}
