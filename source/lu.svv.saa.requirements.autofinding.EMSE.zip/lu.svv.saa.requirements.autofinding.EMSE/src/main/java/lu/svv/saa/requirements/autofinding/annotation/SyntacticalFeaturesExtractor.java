/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.annotation;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngine;
import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;
import static org.apache.uima.fit.util.JCasUtil.select;
import static org.apache.uima.fit.util.JCasUtil.selectCovered;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.log4j.Logger;
import org.apache.uima.UIMAException;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_engine.AnalysisEngine;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.factory.JCasFactory;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;
import org.uimafit.component.JCasAnnotator_ImplBase;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.core.api.syntax.type.chunk.Chunk;
import de.tudarmstadt.ukp.dkpro.core.api.syntax.type.constituent.PP;
import de.tudarmstadt.ukp.dkpro.core.api.syntax.type.constituent.SBAR;
import de.tudarmstadt.ukp.dkpro.core.api.syntax.type.dependency.Dependency;
import de.tudarmstadt.ukp.dkpro.core.berkeleyparser.BerkeleyParser;
import de.tudarmstadt.ukp.dkpro.core.languagetool.LanguageToolSegmenter;
import de.tudarmstadt.ukp.dkpro.core.maltparser.MaltParser;
import de.tudarmstadt.ukp.dkpro.core.opennlp.OpenNlpChunker;
import de.tudarmstadt.ukp.dkpro.core.opennlp.OpenNlpPosTagger;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordPosTagger;
import lu.svv.saa.requirements.autofinding.type.RequirementStatement;
import lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures;

public class SyntacticalFeaturesExtractor extends JCasAnnotator_ImplBase {

  private final Logger logger = Logger.getLogger(getClass());

  private AnalysisEngine parsingPipeline;
  private AnalysisEngine chunkingPipeline;

  private String modals;
  private static final String STARTS_WITH_VERB = "startsWithVerb";
  private static final String STARTS_WITH_PRONOUN = "startsWithPronoun";
  private static final String HAS_MODAL = "hasModal";
  private static final String HAS_VERB = "hasVerb";
  private static final String HAS_NP_modalVP = "hasNPmodalVP";
  private static final String IS_CONDITIONAL = "isConditional";
  private static final String DT_VBZ = "dtVBZ";
  private static final String HAS_PASSIVE = "hasPassive";
  private static final String IS_PRESENT_TENSE = "isPresentTense";
  private static final String HAS_VERB_TO_BE_ADJ = "hasVerbToBeAdj";
  
  @Override
  public void initialize(final UimaContext context) throws ResourceInitializationException {
    super.initialize(context);

    chunkingPipeline =
        createEngine(createEngineDescription(createEngineDescription(LanguageToolSegmenter.class),
            createEngineDescription(OpenNlpPosTagger.class),
            createEngineDescription(OpenNlpChunker.class),
            createEngineDescription(MaltParser.class)));

    parsingPipeline =
        createEngine(createEngineDescription(createEngineDescription(LanguageToolSegmenter.class),
            createEngineDescription(StanfordPosTagger.class),
            createEngineDescription(BerkeleyParser.class),
            createEngineDescription(MaltParser.class)));
  }

  @Override
  public void process(JCas jcas) throws AnalysisEngineProcessException {
    for (RequirementStatement reqSt : select(jcas, RequirementStatement.class)) {
      SyntacticalFeatures synFeat = new SyntacticalFeatures(jcas);
      synFeat.setBegin(reqSt.getBegin());
      synFeat.setEnd(reqSt.getEnd());

      Map<String, Boolean> results = shallowParsing(reqSt);
      synFeat.setHasVerb(results.get(HAS_VERB));
      synFeat.setStartsWithVerb(results.get(STARTS_WITH_VERB));
      synFeat.setStartsWithPronoun(results.get(STARTS_WITH_PRONOUN));
      synFeat.setStartsWithDTVB(results.get(DT_VBZ));
      synFeat.setHasModal(results.get(HAS_MODAL));
      synFeat.setWhichModals(modals);
      synFeat.setHasNPmodalVP(results.get(HAS_NP_modalVP));
      synFeat.setIsConditional(results.get(IS_CONDITIONAL));
      synFeat.setHasPassive(results.get(HAS_PASSIVE));
      synFeat.setIsPresentTense(results.get(IS_PRESENT_TENSE));
      synFeat.setHasVerbToBeAdj(results.get(HAS_VERB_TO_BE_ADJ));
      synFeat.addToIndexes();
    }
  }

  /***** Syntactical Features ******/
  // Applying the chunking pipeline
  public JCas textChunking(String text) {
    JCas tcas = null;
    try {
      tcas = JCasFactory.createJCas();
      tcas.setDocumentLanguage("en");
      tcas.setDocumentText(text);
      chunkingPipeline.process(tcas);
    } catch (UIMAException e) {
      e.printStackTrace();
    }
    return tcas;
  }

  // Applying the parsing pipeline
  public JCas textParsing(String text) {
    JCas tcas = null;
    try {
      tcas = JCasFactory.createJCas();
      tcas.setDocumentLanguage("en");
      tcas.setDocumentText(text);
      parsingPipeline.process(tcas);
    } catch (UIMAException e) {
      e.printStackTrace();
    }
    return tcas;
  }

  // check if it starts with a verb or VP
  public Map<String, Boolean> shallowParsing(RequirementStatement reqSt) {
    String text = reqSt.getText();
    JCas tcas = textChunking(text);
    JCas pcas = null;

    int condBegin = 0;
    int conseqBegin = 0;
    Map<String, Boolean> results = new HashMap<String, Boolean>();
    String modal = "";
    modals = "";

    boolean startVerb = false;
    boolean startVP = false;
    boolean startPrp = false;
    boolean first;
    boolean hasVerb = false;
    boolean hasVP = false;
    boolean hasModal = false;
    boolean npModalVP = false;
    boolean isConditional = false;
    boolean dt = false;
    boolean dtVB = false;

    // If the sentence has a condition: PP or SBAR then parse deeply
    for (Token t : select(tcas, Token.class)) {
      if (t.getPosValue().equalsIgnoreCase("in") || t.getPosValue().equalsIgnoreCase("wrb")) {
        pcas = textParsing(reqSt.getText());

        // SBAR for when if while where conditionals
        Collection<SBAR> sbar =
            (select(pcas, SBAR.class).size() >= 1 ? select(pcas, SBAR.class) : null);

        // PP conditionals using: upon, for, by ... etc.
        Collection<PP> pp = (select(pcas, PP.class).size() >= 1 ? select(pcas, PP.class) : null);

        if (sbar != null && sbar.iterator().next().getBegin() - condBegin == 0) {
          conseqBegin = sbar.iterator().next().getEnd() + 1;
        } else if (pp != null && pp.iterator().next().getBegin() - condBegin == 0) {
          conseqBegin = pp.iterator().next().getEnd() + 1;
        }
        isConditional = true;
      }
      break;
    }

    if (text.toLowerCase().matches("[if|when]"))
      isConditional = true;
    if (conseqBegin > 0 && conseqBegin < reqSt.getText().length()) {
      text = reqSt.getText().substring(conseqBegin).trim();
      tcas = textChunking(text);
    }

    first = true;
    for (Token token : select(tcas, Token.class)) {
      if (dt) {
        if (token.getPosValue().equalsIgnoreCase("vbz")
            || token.getPosValue().equalsIgnoreCase("md")) {
          dtVB = true;
        }
        dt = false;
      }
      if (first) {
        if (token.getPosValue().equalsIgnoreCase("vb")
            || token.getPosValue().equalsIgnoreCase("to")) {
          startVerb = true;
        } else if (token.getPosValue().equalsIgnoreCase("prp")) {
          startPrp = true;
        } else if (token.getPosValue().equalsIgnoreCase("dt")) {
          dt = true;
        }
        first = false;
      }
      if (token.getPosValue().toLowerCase().startsWith("vb")
          && !token.getPosValue().equalsIgnoreCase("vbg")) { 
        hasVerb = true;
      }
      if (token.getPosValue().equalsIgnoreCase("md")) {
        hasModal = true;
        modal = token.getCoveredText();
        modals += modal + ";";
      }
    }
    first = true;
    for (Chunk chunk : select(tcas, Chunk.class)) {
      if (first) {
        if (chunk.getChunkValue().equalsIgnoreCase("vp")) {
          startVP = true;
        }
        first = false;
      }
      if (chunk.getChunkValue().equalsIgnoreCase("vp")) {
        hasVP = true;
        break;
      }
    }
    results.put(STARTS_WITH_VERB, startVerb && startVP);
    results.put(STARTS_WITH_PRONOUN, startPrp);
    results.put(HAS_MODAL, hasModal);
    results.put(HAS_VERB, hasVerb && hasVP);
    results.put(DT_VBZ, dtVB);

    if (hasModal) {// if hasModal=true, look for NPmodalVP, ow return false
      npModalVP = hasNPmodalVPPattern(tcas);
    }
    results.put(HAS_NP_modalVP, npModalVP);
    results.put(IS_CONDITIONAL, isConditional);

    // has Passive, hasVToBeAdj, IsPresentTense
    results.put(HAS_PASSIVE, false);
    String mainverb = "";
    results.put(IS_PRESENT_TENSE, false);
    results.put(HAS_VERB_TO_BE_ADJ, false);
      for (Dependency dep : select(tcas, Dependency.class)) {
        if(dep.getDependencyType().equalsIgnoreCase("auxpass")){
          results.put(HAS_PASSIVE, true);
        }
        if(dep.getDependencyType().equalsIgnoreCase("nsubj")){
           mainverb = dep.getGovernor().getCoveredText();
        }
        if(dep.getDependencyType().equalsIgnoreCase("cop")){
          results.put(HAS_VERB_TO_BE_ADJ, true);
        }
      }
      for(Token tok: select(tcas, Token.class)) {
        if(tok.getCoveredText().equalsIgnoreCase(mainverb) && 
            (tok.getPosValue().equalsIgnoreCase("vbp") || tok.getPosValue().equalsIgnoreCase("vbz")))
        results.put(IS_PRESENT_TENSE, true);
      }
        return results;
  }

  // Check if the sentence has NP+modalVP pattern (not necessarily consecutive)
  private static boolean hasNPmodalVPPattern(JCas tcas) {
    // TWO CASES: vp: modal + vp: verb OR vp: modal+verb
    boolean np = false;
    boolean modal = false;
    boolean vp = false;
    Iterator<Chunk> chunksItrator = select(tcas, Chunk.class).iterator();
    while (chunksItrator.hasNext()) {
      Chunk chunk = chunksItrator.next();
      if (np && modal && vp) {
        return true;
      }
      if (chunk.getChunkValue().equalsIgnoreCase("vp") && np && modal) {
        vp = true;
      }
      // Even if the chunker marks it as NP if it includes a modal, then I assume it was a mistake
      if (np && !modal) {
        for (Token t : selectCovered(Token.class, chunk)) {
          if (t.getPosValue().equalsIgnoreCase("md")) {
            modal = true;
            break;
          }
        }
        if (selectCovered(Token.class, chunk).size() > 1) {
          vp = true;
        }
      }
      if (chunk.getChunkValue().equalsIgnoreCase("np")) {
        np = true;
      }
      if (np && modal && vp) {
        return true;
      }
    }
    return false;
  }

  @Override
  public void collectionProcessComplete() {
    String message = String.format("%s has been processed successfully ..",
        "Syntactic Feature Extraction");
    this.logger.info(message);
  }

}
