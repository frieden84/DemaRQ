package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.cas.Feature;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.tcas.Annotation_Type;


public class SemanticalFeatures_Type extends Annotation_Type {
  /** @generated */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  protected FSGenerator getFSGenerator() {
    return fsGenerator;
  }

  /** @generated */
  @SuppressWarnings("rawtypes")
  private final FSGenerator fsGenerator = new FSGenerator() {
    public FeatureStructure createFS(int addr, CASImpl cas) {
      if (SemanticalFeatures_Type.this.useExistingInstance) {
        // Return eq fs instance if already created
        FeatureStructure fs = SemanticalFeatures_Type.this.jcas.getJfsFromCaddr(addr);
        if (null == fs) {
          fs = new SemanticalFeatures(addr, SemanticalFeatures_Type.this);
          SemanticalFeatures_Type.this.jcas.putJfsFromCaddr(addr, fs);
          return fs;
        }
        return fs;
      } else {
        return new SemanticalFeatures(addr, SemanticalFeatures_Type.this);
      }
    }
  };
  /** @generated */
  public final static int typeIndexID = SemanticalFeatures.typeIndexID;
  /**
   * @generated
   * @modifiable
   */
  public final static boolean featOkTst =
      JCasRegistry.getFeatOkTst("lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");


  /**** Feature: isExplanation ****/
  /** @generated */
  final Feature casFeat_isExplanation;
  /** @generated */
  final int casFeatCode_isExplanation;

  /** @generated */
  public boolean isExplanation(int addr) {
    if (featOkTst && casFeat_isExplanation == null) {
      jcas.throwFeatMissing("isExplanation",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_isExplanation);
  }

  /** @generated */
  public void setIsExplanation(int addr, boolean v) {
    if (featOkTst && casFeat_isExplanation == null) {
      jcas.throwFeatMissing("isExplanation",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_isExplanation, v);
  }

  /**** Feature: hasActionVerb ****/
  /** @generated */
  final Feature casFeat_hasActionVerb;
  /** @generated */
  final int casFeatCode_hasActionVerb;

  /** @generated */
  public boolean hasActionVerb(int addr) {
    if (featOkTst && casFeat_hasActionVerb == null) {
      jcas.throwFeatMissing("hasActionVerb",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_hasActionVerb);
  }

  /** @generated */
  public void setHasActionVerb(int addr, boolean v) {
    if (featOkTst && casFeat_hasActionVerb == null) {
      jcas.throwFeatMissing("hasActionVerb",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_hasActionVerb, v);
  }

  /**** Feature: hasStativeVerb ****/
  /** @generated */
  final Feature casFeat_hasStativeVerb;
  /** @generated */
  final int casFeatCode_hasStativeVerb;

  /** @generated */
  public boolean hasStativeVerb(int addr) {
    if (featOkTst && casFeat_hasStativeVerb == null) {
      jcas.throwFeatMissing("hasStativeVerb",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_hasStativeVerb);
  }

  /** @generated */
  public void setHasStativeVerb(int addr, boolean v) {
    if (featOkTst && casFeat_hasStativeVerb == null) {
      jcas.throwFeatMissing("hasStativeVerb",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_hasStativeVerb, v);
  }

  /**** Feature: expressesProbability ****/
  /** @generated */
  final Feature casFeat_expressesProbability;
  /** @generated */
  final int casFeatCode_expressesProbability;

  /** @generated */
  public boolean expressesProbability(int addr) {
    if (featOkTst && casFeat_expressesProbability == null) {
      jcas.throwFeatMissing("expressesProbability",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_expressesProbability);
  }

  /** @generated */
  public void setExpressesProbability(int addr, boolean v) {
    if (featOkTst && casFeat_expressesProbability == null) {
      jcas.throwFeatMissing("expressesProbability",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_expressesProbability, v);
  }

  /**
   * initialize variables to correspond with Cas Type and Features
   * 
   * @generated
   */
  public SemanticalFeatures_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl) this.casType, getFSGenerator());

    casFeat_isExplanation =
        jcas.getRequiredFeatureDE(casType, "isExplanation", "uima.cas.Boolean", featOkTst);
    casFeatCode_isExplanation = (null == casFeat_isExplanation) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_isExplanation).getCode();

    casFeat_hasActionVerb =
        jcas.getRequiredFeatureDE(casType, "hasActionVerb", "uima.cas.Boolean", featOkTst);
    casFeatCode_hasActionVerb = (null == casFeat_hasActionVerb) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_hasActionVerb).getCode();

    casFeat_hasStativeVerb =
        jcas.getRequiredFeatureDE(casType, "hasStativeVerb", "uima.cas.Boolean", featOkTst);
    casFeatCode_hasStativeVerb = (null == casFeat_hasStativeVerb) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_hasStativeVerb).getCode();

    casFeat_expressesProbability =
        jcas.getRequiredFeatureDE(casType, "expressesProbability", "uima.cas.Boolean", featOkTst);
    casFeatCode_expressesProbability =
        (null == casFeat_expressesProbability) ? JCas.INVALID_FEATURE_CODE
            : ((FeatureImpl) casFeat_expressesProbability).getCode();

  }

}
