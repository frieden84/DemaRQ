package lu.svv.saa.requirements.autofinding.pipelines;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;
import static org.apache.uima.fit.factory.CollectionReaderFactory.createReaderDescription;
import static org.uimafit.factory.AnalysisEngineFactory.createPrimitiveDescription;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.io.FileUtils;
import org.apache.uima.UIMAException;
import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.collection.CollectionReaderDescription;
import org.apache.uima.fit.pipeline.SimplePipeline;
import org.apache.uima.resource.ResourceInitializationException;
import org.uimafit.component.xwriter.CASDumpWriter;
import de.tudarmstadt.ukp.dkpro.core.dictionaryannotator.DictionaryAnnotator;
import de.tudarmstadt.ukp.dkpro.core.languagetool.LanguageToolSegmenter;
import lu.svv.saa.requirements.autofinding.analysis.DiscourseMetadataAnnotator;
import lu.svv.saa.requirements.autofinding.analysis.EnumeratedListDetector;
import lu.svv.saa.requirements.autofinding.annotation.DiscourseFeaturesExtractor;
import lu.svv.saa.requirements.autofinding.annotation.LexicalFeaturesExtractor;
import lu.svv.saa.requirements.autofinding.annotation.RequirementCandidateAnnotator;
import lu.svv.saa.requirements.autofinding.annotation.RequirementStatementAnnotator;
import lu.svv.saa.requirements.autofinding.annotation.SemanticalFeaturesExtractor;
import lu.svv.saa.requirements.autofinding.annotation.SyntacticalFeaturesExtractor;
import lu.svv.saa.requirements.autofinding.io.reader.DocxReader;
import lu.svv.saa.requirements.autofinding.io.writer.DatasetWriter;
import lu.svv.saa.requirements.autofinding.util.Abbreviation;
import weka.classifiers.Classifier;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;


public class DemarcateRequirements {

  static final Abbreviation ABB = Abbreviation.DOC;
  static String DOCUMENT_NAME = "Demo.docx";
  static String TESTSET = ".testset.arff";
  static String PREDICTIONS = "predictions.tsv";
 
  // args: -Document "x.docx" 
  public static void main(String[] args) throws Exception {
    String currentPath = new java.io.File(".").getCanonicalPath();
    Map<String, String> arguments = new HashMap<String, String>();
    int i=0;
    while(i<args.length) {
      String arg = args[i].toLowerCase();
      if(arg.startsWith("-")) {
        arguments.put(arg, args[i+1]);
      }
      i++;
    }
    if (args.length > 0) {
      if(arguments.get("-document")!=null) 
        DOCUMENT_NAME = arguments.get("-document");
    }
    extractFeatures(currentPath, DOCUMENT_NAME);
    predictRequirements(currentPath);
  }

  public static void extractFeatures(String currentPath, String documentName) {
    try {
      // Reader
      CollectionReaderDescription docxReader =
          createReaderDescription(DocxReader.class, DocxReader.PARAM_INPUT_PATH,
              currentPath + "/" + documentName, DocxReader.PARAM_LICENSE_PATH, currentPath+"/resources/license"); 

      // Enumerated List Detector
      AnalysisEngineDescription listRecognizer =
          createPrimitiveDescription(EnumeratedListDetector.class);

      // Tokenizer
      AnalysisEngineDescription segmenter = createEngineDescription(LanguageToolSegmenter.class);
      
      
      // Statement Splitter if demarcation: extract id, Otherwise, take text as is (or if it has a
      // title)
      AnalysisEngineDescription stSplitter =
          createEngineDescription(RequirementStatementAnnotator.class);

      // Discourse Metadata
      AnalysisEngineDescription discourseFrequencyData =
          createEngineDescription(DiscourseMetadataAnnotator.class);

      // Look-up units of measurements
      AnalysisEngineDescription unitsFinder = createEngineDescription(DictionaryAnnotator.class,
          DictionaryAnnotator.PARAM_MODEL_LOCATION, currentPath + "/resources/dictionaries/units.lst");

      // Lexical Features extraction
      AnalysisEngineDescription lexFeatExtractor =
          createEngineDescription(LexicalFeaturesExtractor.class);
      // Syntactical Features extraction
      AnalysisEngineDescription synFeatExtractor =
          createEngineDescription(SyntacticalFeaturesExtractor.class);
      // Semantical Features extraction
      AnalysisEngineDescription semFeatExtractor =
          createEngineDescription(SemanticalFeaturesExtractor.class);
      // Discourse Features extraction
      AnalysisEngineDescription disFeatExtractor =
          createEngineDescription(DiscourseFeaturesExtractor.class);

      // Requirement Candidate Annotator
      AnalysisEngineDescription reqCandidate =
          createEngineDescription(RequirementCandidateAnnotator.class,
              RequirementCandidateAnnotator.PARAM_DOC_ABB, ABB.name());

      AnalysisEngineDescription datasetWriter =
          createEngineDescription(DatasetWriter.class, DatasetWriter.PARAM_FILE_PATH, currentPath);

      // Dump Consumer
      AnalysisEngineDescription consumer = createPrimitiveDescription(CASDumpWriter.class);

      SimplePipeline.runPipeline(docxReader, listRecognizer, segmenter, stSplitter, 
          discourseFrequencyData, disFeatExtractor, unitsFinder,
          lexFeatExtractor, synFeatExtractor, semFeatExtractor, reqCandidate, datasetWriter,
          consumer);

    } catch (final ResourceInitializationException e) {
      e.printStackTrace();
    } catch (final UIMAException e) {
      e.printStackTrace();
    } catch (final IOException e) {
      e.printStackTrace();
    }
  }

  private static void predictRequirements(String currentPath) throws Exception {
    Map<String, String> sentences = readSentences(currentPath);
    Map<String, String> sentencePrediction = new HashMap<String, String>();
    StringBuilder predictions = new StringBuilder();
  
    Classifier savedModel = (Classifier) weka.core.SerializationHelper.read(currentPath + "/resources/model/csRF.model");
    
    // ReadTestData
    Instances testset = readDataset(currentPath + "/");
    if (testset.classIndex() == -1) {
      testset.setClassIndex(testset.numAttributes() - 1);
    }
    // Classify instance by instance
    for (Instance testInst : testset) {
      double predicted = savedModel.classifyInstance(testInst);

      String prediction = testset.classAttribute().value((int) predicted);
      String sentence = sentences.get(testInst.stringValue(0));
      sentencePrediction.put(testInst.stringValue(0), prediction);
      predictions.append(String.format("%14s\t%s%n", prediction, sentence));
    }
    // Write Results
    writeToFile(currentPath + "/", predictions.toString());
    replaceClass(currentPath + "/", sentencePrediction);
    // delete test arff file
    File file = new File(currentPath+"/.testset.arff");   
    file.deleteOnExit();
  }

  public static Instances readDataset(String path) throws Exception {
    File directory;
    directory = new File(path);
    if (!directory.isDirectory())
      throw new IOException("Dataset path " + directory + " is expected to be a directory!");
    FilenameFilter arffFilter = new FilenameFilter() {
      public boolean accept(File dir, String name) {
        String lowercaseName = name.toLowerCase();
        // Read arff files
        if (lowercaseName.endsWith(".arff")) {
          return true;
        } else {
          return false;
        }
      }
    };
    final String[] files = directory.list(arffFilter);
    File file = new File(directory,files[0]);
    DataSource source = new DataSource(file.getAbsolutePath());
    Instances dataset = source.getDataSet();

    return dataset;
  }

  private static Map<String, String> readSentences(String inputpath) throws IOException {
    Map<String, String> sentences = new HashMap<String, String>();
    File directory;
    directory = new File(inputpath);
    if (!directory.isDirectory())
      throw new IOException("Dataset path " + directory + " is expected to be a directory!");
    FilenameFilter infoFilter = new FilenameFilter() {
      public boolean accept(File dir, String name) {
        String lowercaseName = name.toLowerCase();
        // Read info files
        if (lowercaseName.endsWith(".info")) {
          return true;
        } else {
          return false;
        }
      }
    };
    final String[] files = directory.list(infoFilter);
    File file = new File(directory, files[0]);
    FileReader fr = new FileReader(file.getAbsolutePath());
    @SuppressWarnings("resource")
    BufferedReader br = new BufferedReader(fr);
    String sCurrentLine;
    while ((sCurrentLine = br.readLine()) != null) {
      String key = sCurrentLine.substring(0, sCurrentLine.indexOf(","));
      String value = sCurrentLine.substring(sCurrentLine.indexOf(",") + 1).trim();
      sentences.put(key, value);
    }
    return sentences;
  }

  private static void writeToFile(String resultsPath, String content) {
    BufferedWriter writer;
    try {
      // BufferedWriter
      writer = new BufferedWriter(new FileWriter(resultsPath + PREDICTIONS));
      writer.write(content);
      writer.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private static void replaceClass(String resultsPath, Map<String, String> predictions) {
    try {
      FileReader fr = new FileReader(resultsPath + TESTSET);
      @SuppressWarnings("resource")
      BufferedReader br = new BufferedReader(fr);
      StringBuilder modifications = new StringBuilder();
      String sCurrentLine;
      while ((sCurrentLine = br.readLine()) != null) {
        if (sCurrentLine.startsWith("DOC")) {
          String key = sCurrentLine.substring(0, sCurrentLine.indexOf(","));
          String value = predictions.get(key);
          modifications.append(String.format("%s%n", sCurrentLine.replace("?", value)));
        } else {
          modifications.append(String.format("%s%n", sCurrentLine));
        }
      }

      File tempFile = new File(resultsPath + TESTSET);
      FileUtils.writeStringToFile(tempFile, modifications.toString(), "UTF-8");
      
    } catch (IOException e) {
      throw new RuntimeException("Generating file failed", e);
    }
  }

}
