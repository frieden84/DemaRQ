/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;
import org.apache.uima.jcas.tcas.Annotation;

public class WordDocFeatures extends Annotation {
  /**
   * @generated
   * @ordered
   */
  public final static int typeIndexID = JCasRegistry.register(WordDocFeatures.class);
  /**
   * @generated
   * @ordered
   */
  public final static int type = typeIndexID;

  /** @generated */
  @Override
  public int getTypeIndexID() {
    return typeIndexID;
  }

  /**
   * Never called. Disable default constructor
   * 
   * @generated
   */
  public WordDocFeatures() {}

  /**
   * Internal - constructor used by generator
   * 
   * @generated
   */
  public WordDocFeatures(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  /** @generated */
  public WordDocFeatures(JCas jCas) {
    super(jCas);
    readObject();
  }

  /** @generated */
  public WordDocFeatures(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  /**
   * <!-- begin-user-doc --> Write your own initialization here <!-- end-user-doc -->
   * 
   * @generated modifiable
   */
  private void readObject() {}

  // *--------------*
  // * Feature: fontName

  /**
   * getter for fontName
   * 
   * @generated
   */
  public String getFontName() {
    if (WordDocFeatures_Type.featOkTst
        && ((WordDocFeatures_Type) jcasType).casFeat_fontName == null) {
      jcasType.jcas.throwFeatMissing("fontName",
          "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((WordDocFeatures_Type) jcasType).casFeatCode_fontName);
  }

  /**
   * setter for fontName
   * 
   * @generated
   */
  public void setFontName(String v) {
    if (WordDocFeatures_Type.featOkTst
        && ((WordDocFeatures_Type) jcasType).casFeat_fontName == null) {
      jcasType.jcas.throwFeatMissing("fontName",
          "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    jcasType.ll_cas.ll_setStringValue(addr, ((WordDocFeatures_Type) jcasType).casFeatCode_fontName,
        v);
  }

  // *--------------*
  // * Feature: fontSize

  /**
   * getter for fontSize
   * 
   * @generated
   */
  public int getFontSize() {
    if (WordDocFeatures_Type.featOkTst
        && ((WordDocFeatures_Type) jcasType).casFeat_fontSize == null) {
      jcasType.jcas.throwFeatMissing("fontSize",
          "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((WordDocFeatures_Type) jcasType).casFeatCode_fontSize);
  }

  /**
   * setter for fontSize
   * 
   * @generated
   */
  public void setFontSize(int v) {
    if (WordDocFeatures_Type.featOkTst
        && ((WordDocFeatures_Type) jcasType).casFeat_fontSize == null) {
      jcasType.jcas.throwFeatMissing("fontSize",
          "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    jcasType.ll_cas.ll_setIntValue(addr, ((WordDocFeatures_Type) jcasType).casFeatCode_fontSize, v);
  }

  // *--------------*
  // * Feature: isItalic

  /**
   * getter for isItalic
   * 
   * @generated
   */
  public boolean getIsItalic() {
    if (WordDocFeatures_Type.featOkTst
        && ((WordDocFeatures_Type) jcasType).casFeat_isItalic == null) {
      jcasType.jcas.throwFeatMissing("isItalic",
          "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((WordDocFeatures_Type) jcasType).casFeatCode_isItalic);
  }

  /**
   * setter for isItalic
   * 
   * @generated
   */
  public void setIsItalic(boolean v) {
    if (WordDocFeatures_Type.featOkTst
        && ((WordDocFeatures_Type) jcasType).casFeat_isItalic == null) {
      jcasType.jcas.throwFeatMissing("isItalic",
          "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr, ((WordDocFeatures_Type) jcasType).casFeatCode_isItalic,
        v);
  }

  // *--------------*
  // * Feature: isBold

  /**
   * getter for isBold
   * 
   * @generated
   */
  public boolean getIsBold() {
    if (WordDocFeatures_Type.featOkTst
        && ((WordDocFeatures_Type) jcasType).casFeat_isBold == null) {
      jcasType.jcas.throwFeatMissing("isBold",
          "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((WordDocFeatures_Type) jcasType).casFeatCode_isBold);
  }

  /**
   * setter for isBold
   * 
   * @generated
   */
  public void setIsBold(boolean v) {
    if (WordDocFeatures_Type.featOkTst
        && ((WordDocFeatures_Type) jcasType).casFeat_isBold == null) {
      jcasType.jcas.throwFeatMissing("isBold",
          "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr, ((WordDocFeatures_Type) jcasType).casFeatCode_isBold,
        v);
  }

}
