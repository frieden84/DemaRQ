/**
 * Writing the features extracted into a feature matrix in a file of
 * the format .arff to be used in ML pipeline
 */
/**
 * @author <a href="mailto:sallam.abualhaija@uni.lu">Sallam Abualhaija</a> 
 *
 */
package lu.svv.saa.requirements.autofinding.io.writer;
