/**
 * Writing the features extracted into a feature matrix in a file of
 * the format .arff to be used in ML pipeline
 */
/**
 * @author sallam.abualhaija
 *
 */
package lu.svv.saa.requirements.autofinding.io.writer;
