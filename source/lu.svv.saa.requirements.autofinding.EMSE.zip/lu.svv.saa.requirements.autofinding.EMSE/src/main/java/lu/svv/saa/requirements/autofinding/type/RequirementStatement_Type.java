/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.cas.Feature;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.tcas.Annotation_Type;


public class RequirementStatement_Type extends Annotation_Type {
  /** @generated */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  protected FSGenerator getFSGenerator() {
    return fsGenerator;
  }

  /** @generated */
  @SuppressWarnings("rawtypes")
  private final FSGenerator fsGenerator = new FSGenerator() {
    public FeatureStructure createFS(int addr, CASImpl cas) {
      if (RequirementStatement_Type.this.useExistingInstance) {
        // Return eq fs instance if already created
        FeatureStructure fs = RequirementStatement_Type.this.jcas.getJfsFromCaddr(addr);
        if (null == fs) {
          fs = new RequirementStatement(addr, RequirementStatement_Type.this);
          RequirementStatement_Type.this.jcas.putJfsFromCaddr(addr, fs);
          return fs;
        }
        return fs;
      } else {
        return new RequirementStatement(addr, RequirementStatement_Type.this);
      }
    }
  };
  /** @generated */
  public final static int typeIndexID = RequirementStatement.typeIndexID;
  /**
   * @generated
   * @modifiable
   */
  public final static boolean featOkTst =
      JCasRegistry.getFeatOkTst("lu.svv.saa.requirements.autofinding.type.RequirementStatement");

  /**** Feature: id ****/
  /** @generated */
  final Feature casFeat_id;
  /** @generated */
  final int casFeatCode_id;

  /** @generated */
  public String getId(int addr) {
    if (featOkTst && casFeat_id == null) {
      jcas.throwFeatMissing("id", "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_id);
  }

  /** @generated */
  public void setId(int addr, String v) {
    if (featOkTst && casFeat_id == null) {
      jcas.throwFeatMissing("id", "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_id, v);
  }

  /**** Feature: idBegin ****/
  /** @generated */
  final Feature casFeat_idBegin;
  /** @generated */
  final int casFeatCode_idBegin;

  /** @generated */
  public int getIdBegin(int addr) {
    if (featOkTst && casFeat_idBegin == null) {
      jcas.throwFeatMissing("idBegin",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return ll_cas.ll_getIntValue(addr, casFeatCode_idBegin);
  }

  /** @generated */
  public void setIdBegin(int addr, int v) {
    if (featOkTst && casFeat_idBegin == null) {
      jcas.throwFeatMissing("idBegin",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    ll_cas.ll_setIntValue(addr, casFeatCode_idBegin, v);
  }

  /**** Feature: idEnd ****/
  /** @generated */
  final Feature casFeat_idEnd;
  /** @generated */
  final int casFeatCode_idEnd;

  /** @generated */
  public int getIdEnd(int addr) {
    if (featOkTst && casFeat_idEnd == null) {
      jcas.throwFeatMissing("idEnd",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return ll_cas.ll_getIntValue(addr, casFeatCode_idBegin);
  }

  /** @generated */
  public void setIdEnd(int addr, int v) {
    if (featOkTst && casFeat_idEnd == null) {
      jcas.throwFeatMissing("idEnd",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    ll_cas.ll_setIntValue(addr, casFeatCode_idEnd, v);
  }

  /**** Feature: title ***/
  /** @generated */
  final Feature casFeat_title;
  /** @generated */
  final int casFeatCode_title;

  /** @generated */
  public String getTitle(int addr) {
    if (featOkTst && casFeat_title == null) {
      jcas.throwFeatMissing("title",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_title);
  }

  /** @generated */
  public void setTitle(int addr, String v) {
    if (featOkTst && casFeat_title == null) {
      jcas.throwFeatMissing("title",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_title, v);
  }

  /**** Feature: titleBegin ****/
  /** @generated */
  final Feature casFeat_titleBegin;
  /** @generated */
  final int casFeatCode_titleBegin;

  /** @generated */
  public int getTitleBegin(int addr) {
    if (featOkTst && casFeat_titleBegin == null) {
      jcas.throwFeatMissing("titleBegin",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return ll_cas.ll_getIntValue(addr, casFeatCode_titleBegin);
  }

  /** @generated */
  public void setTitleBegin(int addr, int v) {
    if (featOkTst && casFeat_titleBegin == null) {
      jcas.throwFeatMissing("titleBegin",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    ll_cas.ll_setIntValue(addr, casFeatCode_titleBegin, v);
  }

  /**** Feature: titleEnd ****/
  /** @generated */
  final Feature casFeat_titleEnd;
  /** @generated */
  final int casFeatCode_titleEnd;

  /** @generated */
  public int getTitleEnd(int addr) {
    if (featOkTst && casFeat_idEnd == null) {
      jcas.throwFeatMissing("titleEnd",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return ll_cas.ll_getIntValue(addr, casFeatCode_titleBegin);
  }

  /** @generated */
  public void setTitleEnd(int addr, int v) {
    if (featOkTst && casFeat_idEnd == null) {
      jcas.throwFeatMissing("titleEnd",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    ll_cas.ll_setIntValue(addr, casFeatCode_titleEnd, v);
  }

  /**** Feature: text ***/
  /** @generated */
  final Feature casFeat_text;
  /** @generated */
  final int casFeatCode_text;

  /** @generated */
  public String getText(int addr) {
    if (featOkTst && casFeat_text == null) {
      jcas.throwFeatMissing("text",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_text);
  }

  /** @generated */
  public void setText(int addr, String v) {
    if (featOkTst && casFeat_text == null) {
      jcas.throwFeatMissing("text",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_text, v);
  }

  /**** Feature: textBegin ****/
  /** @generated */
  final Feature casFeat_textBegin;
  /** @generated */
  final int casFeatCode_textBegin;

  /** @generated */
  public int getTextBegin(int addr) {
    if (featOkTst && casFeat_textBegin == null) {
      jcas.throwFeatMissing("textBegin",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return ll_cas.ll_getIntValue(addr, casFeatCode_textBegin);
  }

  /** @generated */
  public void setTextBegin(int addr, int v) {
    if (featOkTst && casFeat_textBegin == null) {
      jcas.throwFeatMissing("textBegin",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    ll_cas.ll_setIntValue(addr, casFeatCode_textBegin, v);
  }

  /**** Feature: textEnd ****/
  /** @generated */
  final Feature casFeat_textEnd;
  /** @generated */
  final int casFeatCode_textEnd;

  /** @generated */
  public int getTextEnd(int addr) {
    if (featOkTst && casFeat_idEnd == null) {
      jcas.throwFeatMissing("textEnd",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return ll_cas.ll_getIntValue(addr, casFeatCode_textBegin);
  }

  /** @generated */
  public void setTextEnd(int addr, int v) {
    if (featOkTst && casFeat_idEnd == null) {
      jcas.throwFeatMissing("textEnd",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    ll_cas.ll_setIntValue(addr, casFeatCode_textEnd, v);
  }

  /**
   * initialize variables to correspond with Cas Type and Features
   * 
   * @generated
   */
  public RequirementStatement_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl) this.casType, getFSGenerator());

    casFeat_id = jcas.getRequiredFeatureDE(casType, "id", "uima.cas.String", featOkTst);
    casFeatCode_id =
        (null == casFeat_id) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl) casFeat_id).getCode();

    casFeat_idBegin = jcas.getRequiredFeatureDE(casType, "idBegin", "uima.cas.Integer", featOkTst);
    casFeatCode_idBegin = (null == casFeat_idBegin) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_idBegin).getCode();

    casFeat_idEnd = jcas.getRequiredFeatureDE(casType, "idEnd", "uima.cas.Integer", featOkTst);
    casFeatCode_idEnd = (null == casFeat_idEnd) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_idEnd).getCode();

    casFeat_title = jcas.getRequiredFeatureDE(casType, "title", "uima.cas.String", featOkTst);
    casFeatCode_title = (null == casFeat_title) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_title).getCode();

    casFeat_titleBegin =
        jcas.getRequiredFeatureDE(casType, "titleBegin", "uima.cas.Integer", featOkTst);
    casFeatCode_titleBegin = (null == casFeat_titleBegin) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_titleBegin).getCode();

    casFeat_titleEnd =
        jcas.getRequiredFeatureDE(casType, "titleEnd", "uima.cas.Integer", featOkTst);
    casFeatCode_titleEnd = (null == casFeat_titleEnd) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_titleEnd).getCode();

    casFeat_text = jcas.getRequiredFeatureDE(casType, "text", "uima.cas.String", featOkTst);
    casFeatCode_text =
        (null == casFeat_text) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl) casFeat_text).getCode();

    casFeat_textBegin =
        jcas.getRequiredFeatureDE(casType, "textBegin", "uima.cas.Integer", featOkTst);
    casFeatCode_textBegin = (null == casFeat_textBegin) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_textBegin).getCode();

    casFeat_textEnd = jcas.getRequiredFeatureDE(casType, "textEnd", "uima.cas.Integer", featOkTst);
    casFeatCode_textEnd = (null == casFeat_textEnd) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_textEnd).getCode();

  }

}
