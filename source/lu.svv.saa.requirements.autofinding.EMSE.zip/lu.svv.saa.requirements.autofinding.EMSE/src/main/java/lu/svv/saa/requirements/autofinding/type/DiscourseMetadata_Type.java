package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.cas.Feature;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.tcas.Annotation_Type;


public class DiscourseMetadata_Type extends Annotation_Type {
  /** @generated */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  protected FSGenerator getFSGenerator() {
    return fsGenerator;
  }

  /** @generated */
  @SuppressWarnings("rawtypes")
  private final FSGenerator fsGenerator = new FSGenerator() {
    public FeatureStructure createFS(int addr, CASImpl cas) {
      if (DiscourseMetadata_Type.this.useExistingInstance) {
        // Return eq fs instance if already created
        FeatureStructure fs = DiscourseMetadata_Type.this.jcas.getJfsFromCaddr(addr);
        if (null == fs) {
          fs = new DiscourseMetadata(addr, DiscourseMetadata_Type.this);
          DiscourseMetadata_Type.this.jcas.putJfsFromCaddr(addr, fs);
          return fs;
        }
        return fs;
      } else {
        return new DiscourseMetadata(addr, DiscourseMetadata_Type.this);
      }
    }
  };
  /** @generated */
  public final static int typeIndexID = DiscourseMetadata.typeIndexID;
  /**
   * @generated
   * @modifiable
   */
  public final static boolean featOkTst =
      JCasRegistry.getFeatOkTst("lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");

  /**** Feature: MFFontName ****/
  /** @generated */
  final Feature casFeat_MFFontName;
  /** @generated */
  final int casFeatCode_MFFontName;

  /** @generated */
  public String getMFFontName(int addr) {
    if (featOkTst && casFeat_MFFontName == null) {
      jcas.throwFeatMissing("MFFontName",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_MFFontName);
  }

  /** @generated */
  public void setMFFontName(int addr, String v) {
    if (featOkTst && casFeat_MFFontName == null) {
      jcas.throwFeatMissing("MFFontName",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_MFFontName, v);
  }

  /**** Feature: MFFontSize ****/
  /** @generated */
  final Feature casFeat_MFFontSize;
  /** @generated */
  final int casFeatCode_MFFontSize;

  /** @generated */
  public String getMFFontSize(int addr) {
    if (featOkTst && casFeat_MFFontSize == null) {
      jcas.throwFeatMissing("MFFontSize",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_MFFontSize);
  }

  /** @generated */
  public void setMFFontSize(int addr, String v) {
    if (featOkTst && casFeat_MFFontSize == null) {
      jcas.throwFeatMissing("MFFontSize",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_MFFontSize, v);
  }

  /**** Feature: MFFontItalic ****/
  /** @generated */
  final Feature casFeat_MFFontItalic;
  /** @generated */
  final int casFeatCode_MFFontItalic;

  /** @generated */
  public boolean getMFFontItalic(int addr) {
    if (featOkTst && casFeat_MFFontItalic == null) {
      jcas.throwFeatMissing("MFFontItalic",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_MFFontItalic);
  }

  /** @generated */
  public void setMFFontItalic(int addr, boolean v) {
    if (featOkTst && casFeat_MFFontItalic == null) {
      jcas.throwFeatMissing("MFFontItalic",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_MFFontItalic, v);
  }

  /**** Feature: MFFontBold ****/
  /** @generated */
  final Feature casFeat_MFFontBold;
  /** @generated */
  final int casFeatCode_MFFontBold;

  /** @generated */
  public boolean getMFFontBold(int addr) {
    if (featOkTst && casFeat_MFFontBold == null) {
      jcas.throwFeatMissing("MFFontBold",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_MFFontBold);
  }

  /** @generated */
  public void setMFFontBold(int addr, boolean v) {
    if (featOkTst && casFeat_MFFontBold == null) {
      jcas.throwFeatMissing("MFFontBold",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_MFFontBold, v);
  }

  /**** Feature: MFNP ****/
  /** @generated */
  final Feature casFeat_MFNP;
  /** @generated */
  final int casFeatCode_MFNP;

  /** @generated */
  public String getMFNP(int addr) {
    if (featOkTst && casFeat_MFNP == null) {
      jcas.throwFeatMissing("MFNP", "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_MFNP);
  }

  /** @generated */
  public void setMFNP(int addr, String v) {
    if (featOkTst && casFeat_MFNP == null) {
      jcas.throwFeatMissing("MFNP", "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_MFNP, v);
  }

  /**** Feature: MFCategory ****/
  /** @generated */
  final Feature casFeat_MFCategory;
  /** @generated */
  final int casFeatCode_MFCategory;

  /** @generated */
  public String getMFCategory(int addr) {
    if (featOkTst && casFeat_MFCategory == null) {
      jcas.throwFeatMissing("MFCategory",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_MFCategory);
  }

  /** @generated */
  public void setMFCategory(int addr, String v) {
    if (featOkTst && casFeat_MFCategory == null) {
      jcas.throwFeatMissing("MFCategory",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_MFCategory, v);
  }

  /**** Feature: hasIds ****/
  /** @generated */
  final Feature casFeat_hasIds;
  /** @generated */
  final int casFeatCode_hasIds;

  /** @generated */
  public boolean hasIds(int addr) {
    if (featOkTst && casFeat_hasIds == null) {
      jcas.throwFeatMissing("hasIds", "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_hasIds);
  }

  /** @generated */
  public void setHasIds(int addr, boolean v) {
    if (featOkTst && casFeat_hasIds == null) {
      jcas.throwFeatMissing("hasIds", "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_hasIds, v);
  }

  /**** Feature: idPattern ****/
  /** @generated */
  final Feature casFeat_idPattern;
  /** @generated */
  final int casFeatCode_idPattern;

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @return the feature value
   */
  public int getIdPattern(int addr) {
    if (featOkTst && casFeat_idPattern == null)
      jcas.throwFeatMissing("idPattern",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    return ll_cas.ll_getRefValue(addr, casFeatCode_idPattern);
  }

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @param v value to set
   */
  public void setIdPattern(int addr, int v) {
    if (featOkTst && casFeat_idPattern == null)
      jcas.throwFeatMissing("idPattern",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    ll_cas.ll_setRefValue(addr, casFeatCode_idPattern, v);
  }

  /**** Feature: MFModal ****/
  /** @generated */
  final Feature casFeat_MFModal;
  /** @generated */
  final int casFeatCode_MFModal;

  /** @generated */
  public String getMFModal(int addr) {
    if (featOkTst && casFeat_MFModal == null) {
      jcas.throwFeatMissing("MFModal",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_MFModal);
  }

  /** @generated */
  public void setMFModal(int addr, String v) {
    if (featOkTst && casFeat_MFModal == null) {
      jcas.throwFeatMissing("MFModal",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_MFModal, v);
  }

  /**
   * initialize variables to correspond with Cas Type and Features
   * 
   * @generated
   */
  public DiscourseMetadata_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl) this.casType, getFSGenerator());

    casFeat_MFFontName =
        jcas.getRequiredFeatureDE(casType, "MFFontName", "uima.cas.String", featOkTst);
    casFeatCode_MFFontName = (null == casFeat_MFFontName) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_MFFontName).getCode();

    casFeat_MFFontSize =
        jcas.getRequiredFeatureDE(casType, "MFFontSize", "uima.cas.String", featOkTst);
    casFeatCode_MFFontSize = (null == casFeat_MFFontSize) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_MFFontSize).getCode();

    casFeat_MFFontItalic =
        jcas.getRequiredFeatureDE(casType, "MFFontItalic", "uima.cas.Boolean", featOkTst);
    casFeatCode_MFFontItalic = (null == casFeat_MFFontItalic) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_MFFontItalic).getCode();

    casFeat_MFFontBold =
        jcas.getRequiredFeatureDE(casType, "MFFontBold", "uima.cas.Boolean", featOkTst);
    casFeatCode_MFFontBold = (null == casFeat_MFFontBold) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_MFFontBold).getCode();

    casFeat_MFNP = jcas.getRequiredFeatureDE(casType, "MFNP", "uima.cas.String", featOkTst);
    casFeatCode_MFNP =
        (null == casFeat_MFNP) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl) casFeat_MFNP).getCode();

    casFeat_MFCategory =
        jcas.getRequiredFeatureDE(casType, "MFCategory", "uima.cas.String", featOkTst);
    casFeatCode_MFCategory = (null == casFeat_MFCategory) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_MFCategory).getCode();

    casFeat_hasIds = jcas.getRequiredFeatureDE(casType, "hasIds", "uima.cas.Boolean", featOkTst);
    casFeatCode_hasIds = (null == casFeat_hasIds) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_hasIds).getCode();

    casFeat_idPattern = jcas.getRequiredFeatureDE(casType, "idPattern",
        "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata", featOkTst);
    casFeatCode_idPattern = (null == casFeat_idPattern) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_idPattern).getCode();

    casFeat_MFModal = jcas.getRequiredFeatureDE(casType, "MFModal", "uima.cas.String", featOkTst);
    casFeatCode_MFModal = (null == casFeat_MFModal) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_MFModal).getCode();
  }

}
