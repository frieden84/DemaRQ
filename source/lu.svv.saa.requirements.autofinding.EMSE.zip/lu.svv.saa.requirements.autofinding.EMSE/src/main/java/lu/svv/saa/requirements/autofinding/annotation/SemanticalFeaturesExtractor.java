/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.annotation;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngine;
import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;
import static org.apache.uima.fit.util.JCasUtil.select;
import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import org.apache.uima.UIMAException;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_engine.AnalysisEngine;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.factory.JCasFactory;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;
import org.uimafit.component.JCasAnnotator_ImplBase;
import de.tudarmstadt.ukp.dkpro.core.api.lexmorph.type.pos.POS_ADV;
import de.tudarmstadt.ukp.dkpro.core.api.lexmorph.type.pos.POS_VERB;
import de.tudarmstadt.ukp.dkpro.core.languagetool.LanguageToolSegmenter;
import de.tudarmstadt.ukp.dkpro.core.opennlp.OpenNlpPosTagger;
import lu.svv.saa.requirements.autofinding.type.RequirementStatement;
import lu.svv.saa.requirements.autofinding.type.SemanticalFeatures;
import net.sf.extjwnl.JWNLException;
import net.sf.extjwnl.data.IndexWord;
import net.sf.extjwnl.data.POS;
import net.sf.extjwnl.data.Synset;
import net.sf.extjwnl.dictionary.Dictionary;

public class SemanticalFeaturesExtractor extends JCasAnnotator_ImplBase {

  private final Logger logger = Logger.getLogger(getClass());

  private Dictionary d;
  private AnalysisEngine postaggingPipeline;

  private static final String HAS_ACTION_VERB = "hasActionVerb";
  private static final String HAS_STATIVE_VERB = "hasStativeVerb";
  private static final String IS_EXPLANATION = "isExplanation";
  private static final String EXPRESSES_PROBABILITY = "expressesProbability";

  @Override
  public void initialize(final UimaContext context) throws ResourceInitializationException {
    super.initialize(context);
    postaggingPipeline =
        createEngine(createEngineDescription(createEngineDescription(LanguageToolSegmenter.class),
            createEngineDescription(OpenNlpPosTagger.class)));
    try {
      d = Dictionary.getDefaultResourceInstance();
    } catch (JWNLException e) {
      e.printStackTrace();
    }

  }

  @Override
  public void process(JCas jcas) throws AnalysisEngineProcessException {
    for (RequirementStatement reqSt : select(jcas, RequirementStatement.class)) {
      SemanticalFeatures semFeat = new SemanticalFeatures(jcas);
      semFeat.setBegin(reqSt.getBegin());
      semFeat.setEnd(reqSt.getEnd());
      Map<String, Boolean> results = getSemanticFeatures(reqSt);
      semFeat.setIsExplanation(results.get(IS_EXPLANATION));
      semFeat.setHasActionVerb(results.get(HAS_ACTION_VERB));
      semFeat.setHasStativeVerb(results.get(HAS_STATIVE_VERB));
      semFeat.setExpressesProbability(results.get(EXPRESSES_PROBABILITY));
      semFeat.addToIndexes();

    }
  }

//Applying the chunking pipeline
 public JCas posTagging(String text) {
   JCas tcas = null;
   try {
     tcas = JCasFactory.createJCas();
     tcas.setDocumentLanguage("en");
     tcas.setDocumentText(text);
     postaggingPipeline.process(tcas);
   } catch (UIMAException e) {
     e.printStackTrace();
   }
   return tcas;
 }
  private Map<String, Boolean> getSemanticFeatures(RequirementStatement reqSt) {
    JCas tcas = posTagging(reqSt.getText());
    Map<String, Boolean> results = new HashMap<String, Boolean>();
    results.put(EXPRESSES_PROBABILITY, false);
    results.put(IS_EXPLANATION, false);
    results.put(HAS_ACTION_VERB, false);
    results.put(HAS_STATIVE_VERB, false);
    
    for (POS_VERB verb : select(tcas, POS_VERB.class)) {
      IndexWord v;
      try {
        v = d.lookupIndexWord(POS.VERB, verb.getCoveredText());
        if (v != null && v.getSenses().size() > 0) {
          results.put(HAS_ACTION_VERB,
              results.get(HAS_ACTION_VERB)
                  || v.getSenses().get(0).getLexFileName().contains("motion")
                  || v.getSenses().get(0).getLexFileName().contains("change"));
          results.put(HAS_STATIVE_VERB, results.get(HAS_STATIVE_VERB)
              || v.getSenses().get(0).getLexFileName().contains("stative"));
          results.put(IS_EXPLANATION, results.get(IS_EXPLANATION)
              || v.getSenses().get(0).getLexFileName().contains("cognition"));
        }
      } catch (JWNLException e) {
        e.printStackTrace();
      }

    }

    String[] probability =
        new String[] {"probably", "likely", "in all likelihood", "in all probability", "belik",
            "possibly", "perchance", "perhaps", "maybe", "mayhap", "peradventure"};
    for (String p : probability) {
      if (reqSt.getText().toLowerCase().contains(p)) {
        results.put(EXPRESSES_PROBABILITY, true);
      }
    }
    for (POS_ADV adv : select(tcas, POS_ADV.class)) {
      IndexWord r;
      try {
        r = d.lookupIndexWord(POS.ADVERB, adv.getCoveredText());
        if (r != null && r.getSenses().size() > 0) {
          boolean prob = false;
          for (Synset s : r.getSenses()) {
            for (String p : probability) {
              if (s.containsWord(p)) {
                prob = true;
                break;
              }
            }
          }
          results.put(EXPRESSES_PROBABILITY, results.get(EXPRESSES_PROBABILITY) || prob);
        }
      } catch (JWNLException e) {
        e.printStackTrace();
      }

    }
    return results;
  }

  @Override
  public void collectionProcessComplete() {
    String message = String.format("%s has been processed successfully ..",
        "Semantic Feature Extraction");
    this.logger.info(message);
  }

}
