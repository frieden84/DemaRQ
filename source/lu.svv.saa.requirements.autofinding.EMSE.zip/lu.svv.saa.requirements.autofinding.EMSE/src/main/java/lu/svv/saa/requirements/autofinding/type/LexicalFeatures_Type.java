/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.cas.Feature;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.tcas.Annotation_Type;


public class LexicalFeatures_Type extends Annotation_Type {
  /** @generated */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  protected FSGenerator getFSGenerator() {
    return fsGenerator;
  }

  /** @generated */
  @SuppressWarnings("rawtypes")
  private final FSGenerator fsGenerator = new FSGenerator() {
    public FeatureStructure createFS(int addr, CASImpl cas) {
      if (LexicalFeatures_Type.this.useExistingInstance) {
        // Return eq fs instance if already created
        FeatureStructure fs = LexicalFeatures_Type.this.jcas.getJfsFromCaddr(addr);
        if (null == fs) {
          fs = new LexicalFeatures(addr, LexicalFeatures_Type.this);
          LexicalFeatures_Type.this.jcas.putJfsFromCaddr(addr, fs);
          return fs;
        }
        return fs;
      } else {
        return new LexicalFeatures(addr, LexicalFeatures_Type.this);
      }
    }
  };
  /** @generated */
  public final static int typeIndexID = LexicalFeatures.typeIndexID;
  /**
   * @generated
   * @modifiable
   */
  public final static boolean featOkTst =
      JCasRegistry.getFeatOkTst("lu.svv.saa.requirements.autofinding.type.LexicalFeatures");

  /**** Feature: numOneLetterTokens ****/
  /** @generated */
  final Feature casFeat_numOneLetterTokens;
  /** @generated */
  final int casFeatCode_numOneLetterTokens;

  /** @generated */
  public int getNumOneLetterTokens(int addr) {
    if (featOkTst && casFeat_numOneLetterTokens == null) {
      jcas.throwFeatMissing("numOneLetterTokens",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return ll_cas.ll_getIntValue(addr, casFeatCode_numTokens);
  }

  /** @generated */
  public void setNumOneLetterTokens(int addr, int v) {
    if (featOkTst && casFeat_numOneLetterTokens == null) {
      jcas.throwFeatMissing("numOneLetterTokens",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    ll_cas.ll_setIntValue(addr, casFeatCode_numOneLetterTokens, v);
  }

  /**** Feature: numTokens ****/
  /** @generated */
  final Feature casFeat_numTokens;
  /** @generated */
  final int casFeatCode_numTokens;

  /** @generated */
  public int getNumTokens(int addr) {
    if (featOkTst && casFeat_numTokens == null) {
      jcas.throwFeatMissing("numTokens",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return ll_cas.ll_getIntValue(addr, casFeatCode_numTokens);
  }

  /** @generated */
  public void setNumTokens(int addr, int v) {
    if (featOkTst && casFeat_numTokens == null) {
      jcas.throwFeatMissing("numTokens",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    ll_cas.ll_setIntValue(addr, casFeatCode_numTokens, v);
  }

  /**** Feature: numAlphabetics ***/
  /** @generated */
  final Feature casFeat_numAlphabetics;
  /** @generated */
  final int casFeatCode_numAlphabetics;

  /** @generated */
  public int getNumAlphabetics(int addr) {
    if (featOkTst && casFeat_numAlphabetics == null) {
      jcas.throwFeatMissing("numAlphabetics",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return ll_cas.ll_getIntValue(addr, casFeatCode_numAlphabetics);
  }

  /** @generated */
  public void setNumAlphabetics(int addr, int v) {
    if (featOkTst && casFeat_numAlphabetics == null) {
      jcas.throwFeatMissing("numAlphabetics",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    ll_cas.ll_setIntValue(addr, casFeatCode_numAlphabetics, v);
  }

  /**** Feature: startsWithIdLike ***/
  /** @generated */
  final Feature casFeat_startsWithIdLike;
  /** @generated */
  final int casFeatCode_startsWithIdLike;

  /** @generated */
  public boolean startsWithIdLike(int addr) {
    if (featOkTst && casFeat_startsWithIdLike == null) {
      jcas.throwFeatMissing("startsWithIdLike",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_startsWithIdLike);
  }

  /** @generated */
  public void setStartsWithIdLike(int addr, boolean v) {
    if (featOkTst && casFeat_startsWithIdLike == null) {
      jcas.throwFeatMissing("startsWithIdLike",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_startsWithIdLike, v);
  }

  /**** Feature: idPattern ****/
  /** @generated */
  final Feature casFeat_idPattern;
  /** @generated */
  final int casFeatCode_idPattern;

  /** @generated */
  public String getIdPattern(int addr) {
    if (featOkTst && casFeat_idPattern == null) {
      jcas.throwFeatMissing("idPattern",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_idPattern);
  }

  /** @generated */
  public void setIdPattern(int addr, String v) {
    if (featOkTst && casFeat_idPattern == null) {
      jcas.throwFeatMissing("idPattern",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_idPattern, v);
  }

  /**** Feature: idFrequencyCategory ****/
  /** @generated */
  final Feature casFeat_idFrequencyCategory;
  /** @generated */
  final int casFeatCode_idFrequencyCategory;

  /** @generated */
  public String getIdFrequencyCategory(int addr) {
    if (featOkTst && casFeat_idFrequencyCategory == null) {
      jcas.throwFeatMissing("idFrequencyCategory",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_idFrequencyCategory);
  }

  /** @generated */
  public void setIdFrequencyCategory(int addr, String v) {
    if (featOkTst && casFeat_idFrequencyCategory == null) {
      jcas.throwFeatMissing("idFrequencyCategory",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_idFrequencyCategory, v);
  }

  /**** Feature: isPartOfList ***/
  /** @generated */
  final Feature casFeat_isPartOfList;
  /** @generated */
  final int casFeatCode_isPartOfList;

  /** @generated */
  public boolean isPartOfList(int addr) {
    if (featOkTst && casFeat_isPartOfList == null) {
      jcas.throwFeatMissing("isPartOfList",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_isPartOfList);
  }

  /** @generated */
  public void setIsPartOfList(int addr, boolean v) {
    if (featOkTst && casFeat_isPartOfList == null) {
      jcas.throwFeatMissing("isPartOfList",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_isPartOfList, v);
  }

  /**** Feature: isHeaderOfList ***/
  /** @generated */
  final Feature casFeat_isHeaderOfList;
  /** @generated */
  final int casFeatCode_isHeaderOfList;

  /** @generated */
  public boolean isHeaderOfList(int addr) {
    if (featOkTst && casFeat_isHeaderOfList == null) {
      jcas.throwFeatMissing("isHeaderOfList",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_isHeaderOfList);
  }

  /** @generated */
  public void setIsHeaderOfList(int addr, boolean v) {
    if (featOkTst && casFeat_isHeaderOfList == null) {
      jcas.throwFeatMissing("isHeaderOfList",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_isHeaderOfList, v);
  }

  /**** Feature: listId ****/
  /** @generated */
  final Feature casFeat_listId;
  /** @generated */
  final int casFeatCode_listId;

  /** @generated */
  public int getListId(int addr) {
    if (featOkTst && casFeat_listId == null) {
      jcas.throwFeatMissing("listId", "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return ll_cas.ll_getIntValue(addr, casFeatCode_listId);
  }

  /** @generated */
  public void setListId(int addr, int v) {
    if (featOkTst && casFeat_listId == null) {
      jcas.throwFeatMissing("listId", "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    ll_cas.ll_setIntValue(addr, casFeatCode_listId, v);
  }


  /**** Feature: textSegmentId ****/
  /** @generated */
  final Feature casFeat_textSegmentId;
  /** @generated */
  final int casFeatCode_textSegmentId;

  /** @generated */
  public int getTextSegmentId(int addr) {
    if (featOkTst && casFeat_textSegmentId == null) {
      jcas.throwFeatMissing("textSegmentId",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return ll_cas.ll_getIntValue(addr, casFeatCode_textSegmentId);
  }

  /** @generated */
  public void setTextSegmentId(int addr, int v) {
    if (featOkTst && casFeat_textSegmentId == null) {
      jcas.throwFeatMissing("textSegmentId",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    ll_cas.ll_setIntValue(addr, casFeatCode_textSegmentId, v);
  }

  /**** Feature: startsWithTrigger ***/
  /** @generated */
  final Feature casFeat_startsWithTrigger;
  /** @generated */
  final int casFeatCode_startsWithTrigger;

  /** @generated */
  public boolean startsWithTrigger(int addr) {
    if (featOkTst && casFeat_startsWithTrigger == null) {
      jcas.throwFeatMissing("startsWithTrigger",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_startsWithTrigger);
  }

  /** @generated */
  public void setStartsWithTrigger(int addr, boolean v) {
    if (featOkTst && casFeat_startsWithTrigger == null) {
      jcas.throwFeatMissing("startsWithTrigger",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_startsWithTrigger, v);
  }

  /**** Feature: hasVagueWords ***/
  /** @generated */
  final Feature casFeat_hasVagueWords;
  /** @generated */
  final int casFeatCode_hasVagueWords;

  /** @generated */
  public boolean hasVagueWords(int addr) {
    if (featOkTst && casFeat_hasVagueWords == null) {
      jcas.throwFeatMissing("hasVagueWords",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_hasVagueWords);
  }

  /** @generated */
  public void setHasVagueWords(int addr, boolean v) {
    if (featOkTst && casFeat_hasVagueWords == null) {
      jcas.throwFeatMissing("hasVagueWords",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_hasVagueWords, v);
  }

  /**** Feature: hasUnits ***/
  /** @generated */
  final Feature casFeat_hasUnits;
  /** @generated */
  final int casFeatCode_hasUnits;

  /** @generated */
  public boolean hasUnits(int addr) {
    if (featOkTst && casFeat_hasUnits == null) {
      jcas.throwFeatMissing("hasUnits", "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_hasUnits);
  }

  /** @generated */
  public void setHasUnits(int addr, boolean v) {
    if (featOkTst && casFeat_hasUnits == null) {
      jcas.throwFeatMissing("hasUnits", "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_hasUnits, v);
  }

  /**
   * initialize variables to correspond with Cas Type and Features
   * 
   * @generated
   */
  public LexicalFeatures_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl) this.casType, getFSGenerator());

    casFeat_numOneLetterTokens =
        jcas.getRequiredFeatureDE(casType, "numOneLetterTokens", "uima.cas.Integer", featOkTst);
    casFeatCode_numOneLetterTokens =
        (null == casFeat_numOneLetterTokens) ? JCas.INVALID_FEATURE_CODE
            : ((FeatureImpl) casFeat_numOneLetterTokens).getCode();

    casFeat_numTokens =
        jcas.getRequiredFeatureDE(casType, "numTokens", "uima.cas.Integer", featOkTst);
    casFeatCode_numTokens = (null == casFeat_numTokens) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_numTokens).getCode();

    casFeat_numAlphabetics =
        jcas.getRequiredFeatureDE(casType, "numAlphabetics", "uima.cas.Integer", featOkTst);
    casFeatCode_numAlphabetics = (null == casFeat_numAlphabetics) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_numAlphabetics).getCode();

    casFeat_startsWithIdLike =
        jcas.getRequiredFeatureDE(casType, "startsWithIdLike", "uima.cas.Boolean", featOkTst);
    casFeatCode_startsWithIdLike = (null == casFeat_startsWithIdLike) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_startsWithIdLike).getCode();

    casFeat_idPattern =
        jcas.getRequiredFeatureDE(casType, "idPattern", "uima.cas.String", featOkTst);
    casFeatCode_idPattern = (null == casFeat_idPattern) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_idPattern).getCode();

    casFeat_idFrequencyCategory =
        jcas.getRequiredFeatureDE(casType, "idFrequencyCategory", "uima.cas.String", featOkTst);
    casFeatCode_idFrequencyCategory =
        (null == casFeat_idFrequencyCategory) ? JCas.INVALID_FEATURE_CODE
            : ((FeatureImpl) casFeat_idFrequencyCategory).getCode();

    casFeat_isPartOfList =
        jcas.getRequiredFeatureDE(casType, "isPartOfList", "uima.cas.Boolean", featOkTst);
    casFeatCode_isPartOfList = (null == casFeat_isPartOfList) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_isPartOfList).getCode();

    casFeat_isHeaderOfList =
        jcas.getRequiredFeatureDE(casType, "isHeaderOfList", "uima.cas.Boolean", featOkTst);
    casFeatCode_isHeaderOfList = (null == casFeat_isHeaderOfList) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_isHeaderOfList).getCode();

    casFeat_listId = jcas.getRequiredFeatureDE(casType, "listId", "uima.cas.Integer", featOkTst);
    casFeatCode_listId = (null == casFeat_listId) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_listId).getCode();

    casFeat_textSegmentId =
        jcas.getRequiredFeatureDE(casType, "textSegmentId", "uima.cas.Integer", featOkTst);
    casFeatCode_textSegmentId = (null == casFeat_textSegmentId) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_textSegmentId).getCode();

    casFeat_startsWithTrigger =
        jcas.getRequiredFeatureDE(casType, "startsWithTrigger", "uima.cas.Boolean", featOkTst);
    casFeatCode_startsWithTrigger = (null == casFeat_startsWithTrigger) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_startsWithTrigger).getCode();

    casFeat_hasVagueWords =
        jcas.getRequiredFeatureDE(casType, "hasVagueWords", "uima.cas.Boolean", featOkTst);
    casFeatCode_hasVagueWords = (null == casFeat_hasVagueWords) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_hasVagueWords).getCode();

    casFeat_hasUnits =
        jcas.getRequiredFeatureDE(casType, "hasUnits", "uima.cas.Boolean", featOkTst);
    casFeatCode_hasUnits = (null == casFeat_hasUnits) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_hasUnits).getCode();

  }

}
