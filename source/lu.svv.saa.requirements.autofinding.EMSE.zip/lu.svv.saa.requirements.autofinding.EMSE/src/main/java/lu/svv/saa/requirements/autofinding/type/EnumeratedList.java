package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;
import org.apache.uima.jcas.tcas.Annotation;

public class EnumeratedList extends Annotation {
  /**
   * @generated
   * @ordered
   */
  public final static int typeIndexID = JCasRegistry.register(EnumeratedList.class);
  /**
   * @generated
   * @ordered
   */
  public final static int type = typeIndexID;

  /** @generated */
  @Override
  public int getTypeIndexID() {
    return typeIndexID;
  }

  /**
   * Never called. Disable default constructor
   * 
   * @generated
   */
  public EnumeratedList() {}

  /**
   * Internal - constructor used by generator
   * 
   * @generated
   */
  public EnumeratedList(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  /** @generated */
  public EnumeratedList(JCas jCas) {
    super(jCas);
    readObject();
  }

  /** @generated */
  public EnumeratedList(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  /**
   * <!-- begin-user-doc --> Write your own initialization here <!-- end-user-doc -->
   * 
   * @generated modifiable
   */
  private void readObject() {}

  // *--------------*
  // * Feature: parent

  /**
   * getter for parent
   * 
   * @generated
   */
  public DocxSentence getParent() {
    if (EnumeratedList_Type.featOkTst && ((EnumeratedList_Type) jcasType).casFeat_parent == null)
      jcasType.jcas.throwFeatMissing("parent",
          "lu.svv.saa.requirements.autofinding.type.EnumeratedList");
    return (DocxSentence) (jcasType.ll_cas.ll_getFSForRef(
        jcasType.ll_cas.ll_getRefValue(addr, ((EnumeratedList_Type) jcasType).casFeatCode_parent)));
  }

  /**
   * setter for parent
   * 
   * @generated
   */
  public void setParent(DocxSentence v) {
    if (EnumeratedList_Type.featOkTst && ((EnumeratedList_Type) jcasType).casFeat_parent == null)
      jcasType.jcas.throwFeatMissing("parent",
          "lu.svv.saa.requirements.autofinding.type.EnumeratedList");
    jcasType.ll_cas.ll_setRefValue(addr, ((EnumeratedList_Type) jcasType).casFeatCode_parent,
        jcasType.ll_cas.ll_getFSRef(v));
  }

}
