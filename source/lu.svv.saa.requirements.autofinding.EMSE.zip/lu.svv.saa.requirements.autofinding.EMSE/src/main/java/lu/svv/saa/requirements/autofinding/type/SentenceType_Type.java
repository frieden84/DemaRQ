package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.cas.Feature;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.tcas.Annotation_Type;


public class SentenceType_Type extends Annotation_Type {
  /** @generated */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  protected FSGenerator getFSGenerator() {
    return fsGenerator;
  }

  /** @generated */
  @SuppressWarnings("rawtypes")
  private final FSGenerator fsGenerator = new FSGenerator() {
    public FeatureStructure createFS(int addr, CASImpl cas) {
      if (SentenceType_Type.this.useExistingInstance) {
        // Return eq fs instance if already created
        FeatureStructure fs = SentenceType_Type.this.jcas.getJfsFromCaddr(addr);
        if (null == fs) {
          fs = new SentenceType(addr, SentenceType_Type.this);
          SentenceType_Type.this.jcas.putJfsFromCaddr(addr, fs);
          return fs;
        }
        return fs;
      } else {
        return new SentenceType(addr, SentenceType_Type.this);
      }
    }
  };
  /** @generated */
  public final static int typeIndexID = SentenceType.typeIndexID;
  /**
   * @generated
   * @modifiable
   */
  public final static boolean featOkTst =
      JCasRegistry.getFeatOkTst("lu.svv.saa.requirements.autofinding.type.SentenceType");

  /**** Feature: isSimple ****/
  /** @generated */
  final Feature casFeat_isSimple;
  /** @generated */
  final int casFeatCode_isSimple;

  /** @generated */
  public boolean getIsSimple(int addr) {
    if (featOkTst && casFeat_isSimple == null) {
      jcas.throwFeatMissing("isSimple", "lu.svv.saa.requirements.autofinding.type.SentenceType");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_isSimple);
  }

  /** @generated */
  public void setIsSimple(int addr, boolean v) {
    if (featOkTst && casFeat_isSimple == null) {
      jcas.throwFeatMissing("isSimple", "lu.svv.saa.requirements.autofinding.type.SentenceType");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_isSimple, v);
  }

  /**** Feature: isCompound ****/
  /** @generated */
  final Feature casFeat_isCompound;
  /** @generated */
  final int casFeatCode_isCompound;

  /** @generated */
  public boolean getIsCompound(int addr) {
    if (featOkTst && casFeat_isCompound == null) {
      jcas.throwFeatMissing("isCompound", "lu.svv.saa.requirements.autofinding.type.SentenceType");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_isCompound);
  }

  /** @generated */
  public void setIsCompound(int addr, boolean v) {
    if (featOkTst && casFeat_isCompound == null) {
      jcas.throwFeatMissing("isCompound", "lu.svv.saa.requirements.autofinding.type.SentenceType");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_isCompound, v);
  }

  /**** Feature: isComplex ****/
  /** @generated */
  final Feature casFeat_isComplex;
  /** @generated */
  final int casFeatCode_isComplex;

  /** @generated */
  public boolean getIsComplex(int addr) {
    if (featOkTst && casFeat_isComplex == null) {
      jcas.throwFeatMissing("isComplex", "lu.svv.saa.requirements.autofinding.type.SentenceType");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_isComplex);
  }

  /** @generated */
  public void setIsComplex(int addr, boolean v) {
    if (featOkTst && casFeat_isComplex == null) {
      jcas.throwFeatMissing("isComplex", "lu.svv.saa.requirements.autofinding.type.SentenceType");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_isComplex, v);
  }

  /**** Feature: independentClauses ***/
  /** @generated */
  final Feature casFeat_independentClauses;
  /** @generated */
  final int casFeatCode_independentClauses;

  /** @generated */
  public int getIndependentClauses(int addr) {
    if (featOkTst && casFeat_independentClauses == null)
      jcas.throwFeatMissing("independentClauses",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    return ll_cas.ll_getRefValue(addr, casFeatCode_independentClauses);
  }

  /** @generated */
  public void setIndependentClauses(int addr, int v) {
    if (featOkTst && casFeat_independentClauses == null)
      jcas.throwFeatMissing("independentClauses",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    ll_cas.ll_setRefValue(addr, casFeatCode_independentClauses, v);
  }

  /** @generated */
  public int getIndependentClauses(int addr, int i) {
    if (featOkTst && casFeat_independentClauses == null)
      jcas.throwFeatMissing("independentClauses",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    if (lowLevelTypeChecks)
      return ll_cas.ll_getRefArrayValue(ll_cas.ll_getRefValue(addr, casFeatCode_independentClauses),
          i, true);
    jcas.checkArrayBounds(ll_cas.ll_getRefValue(addr, casFeatCode_independentClauses), i);
    return ll_cas.ll_getRefArrayValue(ll_cas.ll_getRefValue(addr, casFeatCode_independentClauses),
        i);
  }

  /** @generated */
  public void setIndependentClausess(int addr, int i, int v) {
    if (featOkTst && casFeat_independentClauses == null)
      jcas.throwFeatMissing("independentClauses",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    if (lowLevelTypeChecks)
      ll_cas.ll_setRefArrayValue(ll_cas.ll_getRefValue(addr, casFeatCode_independentClauses), i, v,
          true);
    jcas.checkArrayBounds(ll_cas.ll_getRefValue(addr, casFeatCode_independentClauses), i);
    ll_cas.ll_setRefArrayValue(ll_cas.ll_getRefValue(addr, casFeatCode_independentClauses), i, v);
  }

  /**** Feature: dependentClauses ***/
  /** @generated */
  final Feature casFeat_dependentClauses;
  /** @generated */
  final int casFeatCode_dependentClauses;

  /** @generated */
  public int getDependentClauses(int addr) {
    if (featOkTst && casFeat_dependentClauses == null)
      jcas.throwFeatMissing("dependentClauses",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    return ll_cas.ll_getRefValue(addr, casFeatCode_dependentClauses);
  }

  /** @generated */
  public void setDependentClauses(int addr, int v) {
    if (featOkTst && casFeat_dependentClauses == null)
      jcas.throwFeatMissing("dependentClauses",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    ll_cas.ll_setRefValue(addr, casFeatCode_dependentClauses, v);
  }

  /** @generated */
  public int getDependentClauses(int addr, int i) {
    if (featOkTst && casFeat_dependentClauses == null)
      jcas.throwFeatMissing("dependentClauses",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    if (lowLevelTypeChecks)
      return ll_cas.ll_getRefArrayValue(ll_cas.ll_getRefValue(addr, casFeatCode_dependentClauses),
          i, true);
    jcas.checkArrayBounds(ll_cas.ll_getRefValue(addr, casFeatCode_dependentClauses), i);
    return ll_cas.ll_getRefArrayValue(ll_cas.ll_getRefValue(addr, casFeatCode_dependentClauses), i);
  }

  /** @generated */
  public void setDependentClausess(int addr, int i, int v) {
    if (featOkTst && casFeat_dependentClauses == null)
      jcas.throwFeatMissing("dependentClauses",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    if (lowLevelTypeChecks)
      ll_cas.ll_setRefArrayValue(ll_cas.ll_getRefValue(addr, casFeatCode_dependentClauses), i, v,
          true);
    jcas.checkArrayBounds(ll_cas.ll_getRefValue(addr, casFeatCode_dependentClauses), i);
    ll_cas.ll_setRefArrayValue(ll_cas.ll_getRefValue(addr, casFeatCode_dependentClauses), i, v);
  }

  /**
   * initialize variables to correspond with Cas Type and Features
   * 
   * @generated
   */
  public SentenceType_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl) this.casType, getFSGenerator());

    casFeat_isSimple =
        jcas.getRequiredFeatureDE(casType, "isSimple", "uima.cas.Boolean", featOkTst);
    casFeatCode_isSimple = (null == casFeat_isSimple) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_isSimple).getCode();

    casFeat_isCompound =
        jcas.getRequiredFeatureDE(casType, "isCompound", "uima.cas.Boolean", featOkTst);
    casFeatCode_isCompound = (null == casFeat_isCompound) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_isCompound).getCode();

    casFeat_isComplex =
        jcas.getRequiredFeatureDE(casType, "isComplex", "uima.cas.Boolean", featOkTst);
    casFeatCode_isComplex = (null == casFeat_isComplex) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_isComplex).getCode();

    casFeat_independentClauses =
        jcas.getRequiredFeatureDE(casType, "independentClauses", "uima.cas.StringList", featOkTst);
    casFeatCode_independentClauses =
        (null == casFeat_independentClauses) ? JCas.INVALID_FEATURE_CODE
            : ((FeatureImpl) casFeat_independentClauses).getCode();

    casFeat_dependentClauses =
        jcas.getRequiredFeatureDE(casType, "dependentClauses", "uima.cas.StringList", featOkTst);
    casFeatCode_dependentClauses = (null == casFeat_dependentClauses) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_dependentClauses).getCode();
  }

}
