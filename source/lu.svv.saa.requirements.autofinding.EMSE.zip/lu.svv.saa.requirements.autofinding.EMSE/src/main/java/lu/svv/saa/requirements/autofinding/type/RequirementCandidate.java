/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;
import org.apache.uima.jcas.tcas.Annotation;

public class RequirementCandidate extends Annotation {
  /**
   * @generated
   * @ordered
   */
  public final static int typeIndexID = JCasRegistry.register(RequirementCandidate.class);
  /**
   * @generated
   * @ordered
   */
  public final static int type = typeIndexID;

  /** @generated */
  @Override
  public int getTypeIndexID() {
    return typeIndexID;
  }

  /**
   * Never called. Disable default constructor
   * 
   * @generated
   */
  public RequirementCandidate() {}

  /**
   * Internal - constructor used by generator
   * 
   * @generated
   */
  public RequirementCandidate(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  /** @generated */
  public RequirementCandidate(JCas jCas) {
    super(jCas);
    readObject();
  }

  /** @generated */
  public RequirementCandidate(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  /**
   * <!-- begin-user-doc --> Write your own initialization here <!-- end-user-doc -->
   * 
   * @generated modifiable
   */
  private void readObject() {}

  // *--------------*
  // * Feature: ID

  /**
   * getter for ID
   * 
   * @generated
   */
  public String getID() {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_ID == null) {
      jcasType.jcas.throwFeatMissing("ID",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((RequirementCandidate_Type) jcasType).casFeatCode_ID);
  }

  /**
   * setter for ID
   * 
   * @generated
   */
  public void setID(String v) {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_ID == null) {
      jcasType.jcas.throwFeatMissing("ID",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    }
    jcasType.ll_cas.ll_setStringValue(addr, ((RequirementCandidate_Type) jcasType).casFeatCode_ID,
        v);
  }


  // *--------------*
  // * Feature: requirement

  /**
   * getter for requirement
   * 
   * @generated
   */
  public RequirementStatement getRequirement() {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_requirement == null)
      jcasType.jcas.throwFeatMissing("requirement",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    return (RequirementStatement) (jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas
        .ll_getRefValue(addr, ((RequirementCandidate_Type) jcasType).casFeatCode_requirement)));
  }

  /**
   * setter for requirement
   * 
   * @generated
   */
  public void setRequirement(RequirementStatement v) {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_requirement == null)
      jcasType.jcas.throwFeatMissing("requirement",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    jcasType.ll_cas.ll_setRefValue(addr,
        ((RequirementCandidate_Type) jcasType).casFeatCode_requirement,
        jcasType.ll_cas.ll_getFSRef(v));
  }

  // *--------------*
  // * Feature: lexFeatures

  /**
   * getter for lexFeatures
   * 
   * @generated
   */
  public LexicalFeatures getLexFeatures() {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_lexFeatures == null)
      jcasType.jcas.throwFeatMissing("lexFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    return (LexicalFeatures) (jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefValue(addr,
        ((RequirementCandidate_Type) jcasType).casFeatCode_lexFeatures)));
  }

  /**
   * setter for lexFeatures
   * 
   * @generated
   */
  public void setLexFeatures(LexicalFeatures v) {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_lexFeatures == null)
      jcasType.jcas.throwFeatMissing("lexFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    jcasType.ll_cas.ll_setRefValue(addr,
        ((RequirementCandidate_Type) jcasType).casFeatCode_lexFeatures,
        jcasType.ll_cas.ll_getFSRef(v));
  }

  // *--------------*
  // * Feature: synFeatures

  /**
   * getter for synFeatures
   * 
   * @generated
   */
  public SyntacticalFeatures getSynFeatures() {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_synFeatures == null)
      jcasType.jcas.throwFeatMissing("synFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    return (SyntacticalFeatures) (jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas
        .ll_getRefValue(addr, ((RequirementCandidate_Type) jcasType).casFeatCode_synFeatures)));
  }

  /**
   * setter for synFeatures
   * 
   * @generated
   */
  public void setSynFeatures(SyntacticalFeatures v) {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_synFeatures == null)
      jcasType.jcas.throwFeatMissing("synFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    jcasType.ll_cas.ll_setRefValue(addr,
        ((RequirementCandidate_Type) jcasType).casFeatCode_synFeatures,
        jcasType.ll_cas.ll_getFSRef(v));
  }

  // *--------------*
  // * Feature: semFeatures

  /**
   * getter for semFeatures
   * 
   * @generated
   */
  public SemanticalFeatures getSemFeatures() {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_semFeatures == null)
      jcasType.jcas.throwFeatMissing("semFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    return (SemanticalFeatures) (jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefValue(addr,
        ((RequirementCandidate_Type) jcasType).casFeatCode_semFeatures)));
  }

  /**
   * setter for semFeatures
   * 
   * @generated
   */
  public void setSemFeatures(SemanticalFeatures v) {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_semFeatures == null)
      jcasType.jcas.throwFeatMissing("semFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    jcasType.ll_cas.ll_setRefValue(addr,
        ((RequirementCandidate_Type) jcasType).casFeatCode_semFeatures,
        jcasType.ll_cas.ll_getFSRef(v));
  }

  // *--------------*
  // * Feature: discourseFeatures

  /**
   * getter for discourseFeatures
   * 
   * @generated
   */
  public DiscourseFeatures getDiscourseFeatures() {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_discourseFeatures == null)
      jcasType.jcas.throwFeatMissing("discourseFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    return (DiscourseFeatures) (jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefValue(addr,
        ((RequirementCandidate_Type) jcasType).casFeatCode_discourseFeatures)));
  }

  /**
   * setter for discourseFeatures
   * 
   * @generated
   */
  public void setDiscourseFeatures(DiscourseFeatures v) {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_discourseFeatures == null)
      jcasType.jcas.throwFeatMissing("discourseFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    jcasType.ll_cas.ll_setRefValue(addr,
        ((RequirementCandidate_Type) jcasType).casFeatCode_discourseFeatures,
        jcasType.ll_cas.ll_getFSRef(v));
  }


  // *--------------*
  // * Feature: isRequirement

  /**
   * getter for isRequirement
   * 
   * @generated
   */
  public boolean isRequirement() {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_isRequirement == null) {
      jcasType.jcas.throwFeatMissing("isRequirement",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((RequirementCandidate_Type) jcasType).casFeatCode_isRequirement);
  }

  /**
   * setter for isRequirement
   * 
   * @generated
   */
  public void setIsRequirement(boolean v) {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_isRequirement == null) {
      jcasType.jcas.throwFeatMissing("isRequirement",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((RequirementCandidate_Type) jcasType).casFeatCode_isRequirement, v);
  }

  // *--------------*
  // * Feature: confidence

  /**
   * getter for confidence
   * 
   * @generated
   */
  public double getConfidence() {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_confidence == null) {
      jcasType.jcas.throwFeatMissing("confidence",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    }
    return jcasType.ll_cas.ll_getDoubleValue(addr,
        ((RequirementCandidate_Type) jcasType).casFeatCode_confidence);
  }

  /**
   * setter for confidence
   * 
   * @generated
   */
  public void setConfidence(double v) {
    if (RequirementCandidate_Type.featOkTst
        && ((RequirementCandidate_Type) jcasType).casFeat_confidence == null) {
      jcasType.jcas.throwFeatMissing("confidence",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    }
    jcasType.ll_cas.ll_setDoubleValue(addr,
        ((RequirementCandidate_Type) jcasType).casFeatCode_confidence, v);
  }

}
