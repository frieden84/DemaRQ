/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.analysis;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngine;
import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.math3.stat.Frequency;
import org.apache.log4j.Logger;
import org.apache.uima.UIMAException;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_engine.AnalysisEngine;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.factory.JCasFactory;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;
import org.uimafit.component.JCasAnnotator_ImplBase;
import org.uimafit.descriptor.ConfigurationParameter;
import org.uimafit.util.JCasUtil;
import de.tudarmstadt.ukp.dkpro.core.api.lexmorph.type.pos.POS_NOUN;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.core.api.syntax.type.chunk.NC;
import de.tudarmstadt.ukp.dkpro.core.languagetool.LanguageToolSegmenter;
import de.tudarmstadt.ukp.dkpro.core.opennlp.OpenNlpChunker;
import de.tudarmstadt.ukp.dkpro.core.opennlp.OpenNlpPosTagger;
import lu.svv.saa.requirements.autofinding.type.DiscourseMetadata;
import lu.svv.saa.requirements.autofinding.type.DocxSentence;
import lu.svv.saa.requirements.autofinding.type.IdPatternMetadata;
import lu.svv.saa.requirements.autofinding.type.RequirementStatement;
import net.sf.extjwnl.JWNLException;
import net.sf.extjwnl.data.IndexWord;
import net.sf.extjwnl.data.POS;
import net.sf.extjwnl.data.Pointer;
import net.sf.extjwnl.data.PointerType;
import net.sf.extjwnl.data.Word;
import net.sf.extjwnl.dictionary.Dictionary;

public class DiscourseMetadataAnnotator extends JCasAnnotator_ImplBase {
  public static final String PARAM_DEMARCATION = "demarcation";
  @ConfigurationParameter(name = PARAM_DEMARCATION, mandatory = true,
      description = "A boolean if the IDs are well demarcated", defaultValue = "true")
  private boolean demarcation;

  private final Logger logger = Logger.getLogger(getClass());

  private Frequency frequencyDistributionOfFontName;
  private Frequency frequencyDistributionOfFontSize;
  private Frequency frequencyDistributionOfItalic;
  private Frequency frequencyDistributionOfBold;
  private Frequency frequencyDistributionOfIdPatterns;
  private Frequency frequencyDistributionOfNPs;
  private Frequency frequencyDistributionOfModals;
  private Frequency frequencyDistributionOfCategories;
  private Dictionary dic;
  private AnalysisEngine chunking;

  @Override
  public void initialize(final UimaContext context) throws ResourceInitializationException {
    super.initialize(context);

    this.frequencyDistributionOfFontName = new Frequency();
    this.frequencyDistributionOfFontSize = new Frequency();
    this.frequencyDistributionOfItalic = new Frequency();
    this.frequencyDistributionOfBold = new Frequency();
    this.frequencyDistributionOfIdPatterns = new Frequency();
    this.frequencyDistributionOfNPs = new Frequency();
    this.frequencyDistributionOfModals = new Frequency();
    this.frequencyDistributionOfCategories = new Frequency();

    try {
      dic = Dictionary.getDefaultResourceInstance();
    } catch (JWNLException e) {
      e.printStackTrace();
    }

    chunking =
        createEngine(createEngineDescription(createEngineDescription(LanguageToolSegmenter.class),
            createEngineDescription(OpenNlpPosTagger.class),
            createEngineDescription(OpenNlpChunker.class)));
  }

  @Override
  public void process(JCas aJCas) throws AnalysisEngineProcessException {
    // Get formatting style frequency distribution
    for (final DocxSentence sent : JCasUtil.select(aJCas, DocxSentence.class)) {
      // Get formatting frequency information
      if (sent.getFontName() != null)
        this.frequencyDistributionOfFontName.addValue(sent.getFontName());
      if (sent.getFontSize() != -1 && sent.getFontSize() > 0)
        this.frequencyDistributionOfFontSize.addValue(Integer.toString(sent.getFontSize()));
      this.frequencyDistributionOfBold.addValue(sent.getIsBold());
      this.frequencyDistributionOfItalic.addValue(sent.getIsItalic());

      // Get syntactic global information
      String sentText = sent.getCoveredText();
      JCas tcas;
      try {
        tcas = chunking(sentText);
        // Get NP frequency distribution
        for (final NC np : JCasUtil.select(tcas, NC.class)) {
          this.frequencyDistributionOfNPs.addValue(np.getCoveredText().toLowerCase());
        }
        // Get modal verbs frequency distribution
        for (final Token token : JCasUtil.select(tcas, Token.class)) {
          if (token.getPosValue().equalsIgnoreCase("md"))
            this.frequencyDistributionOfModals.addValue(token.getCoveredText().toLowerCase());
        }
        // Get noun categories frequency distribution
        for (POS_NOUN noun : JCasUtil.select(tcas, POS_NOUN.class)) {
          IndexWord word = dic.lookupIndexWord(POS.NOUN, noun.getCoveredText());
          if (word != null && word.getSenses().size() > 0) {
            List<Pointer> categories = word.getSenses().get(0).getPointers(PointerType.CATEGORY);
            if (categories.size() > 0)
              for (Word w : categories.get(0).getTarget().getSynset().getWords()) {
                this.frequencyDistributionOfCategories.addValue(w.getLemma());
              }
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
   
    // Get Id Patterns Frequency Distribution
    if (demarcation) {
      for (RequirementStatement reqSt : JCasUtil.select(aJCas, RequirementStatement.class)) {
        // get the id pattern c->a-z, C->A-Z, d->0-9
        String pattern = findIdPattern(reqSt);
        if (pattern.length() > 0)
          this.frequencyDistributionOfIdPatterns.addValue(pattern);
      }
    }
    setDiscourseMetadata(aJCas);
  }

  private void setDiscourseMetadata(JCas aJCas) {
    DiscourseMetadata disMetadata = new DiscourseMetadata(aJCas);
    disMetadata.setBegin(0);
    disMetadata.setEnd(aJCas.getDocumentText().length());
    // Formatting Issues
    disMetadata.setMFFontName(this.frequencyDistributionOfFontName.getUniqueCount() > 0
        ? (String) frequencyDistributionOfFontName.getMode().get(0)
        : "");
    disMetadata.setMFFontSize(this.frequencyDistributionOfFontSize.getUniqueCount() > 0
        ? (String) frequencyDistributionOfFontSize.getMode().get(0)
        : "-1");
    disMetadata.setMFFontItalic((Boolean) (this.frequencyDistributionOfItalic.getUniqueCount() > 0
        ? frequencyDistributionOfItalic.getMode().get(0)
        : false));
    disMetadata.setMFFontBold((Boolean) (this.frequencyDistributionOfBold.getUniqueCount() > 0
        ? frequencyDistributionOfBold.getMode().get(0)
        : false));

    // NP
    disMetadata.setMFNP(this.frequencyDistributionOfNPs.getUniqueCount() > 0
        ? (String) frequencyDistributionOfNPs.getMode().get(0)
        : "");

    // modal
    disMetadata.setMFModal(this.frequencyDistributionOfModals.getUniqueCount() > 0
        ? (String) frequencyDistributionOfModals.getMode().get(0)
        : "");

    // Category
    if (this.frequencyDistributionOfCategories.getUniqueCount() > 0) {
      String cat = "";
      for (Comparable<?> mode : frequencyDistributionOfCategories.getMode())
        cat += (String) mode + " ";
      disMetadata.setMFCategory(cat.trim());
    } else {
      disMetadata.setMFCategory("");
    }

    // hasIds
    disMetadata.sethasIds(demarcation);
    // Id pattern info
    if (demarcation) {
      IdPatternMetadata idPattern = new IdPatternMetadata(aJCas);
      idPattern.setMFIdPattern(this.frequencyDistributionOfIdPatterns.getUniqueCount() > 0
          ? (String) frequencyDistributionOfIdPatterns.getMode().get(0)
          : "");
      idPattern.setMFIdPatternFrequency(this.frequencyDistributionOfIdPatterns.getUniqueCount() > 0
          && idPattern.getMFIdPattern().length() > 0
              ? frequencyDistributionOfIdPatterns
                  .getCount(frequencyDistributionOfIdPatterns.getMode().get(0))
              : -1);
      idPattern.setMFIdPatternPct(this.frequencyDistributionOfIdPatterns.getUniqueCount() > 0
          && idPattern.getMFIdPattern().length() > 0
              ? frequencyDistributionOfIdPatterns
                  .getPct(frequencyDistributionOfIdPatterns.getMode().get(0))
              : -1);
      idPattern.setTotalIdPatterns(this.frequencyDistributionOfIdPatterns.getUniqueCount());

      if (this.frequencyDistributionOfIdPatterns.getUniqueCount() > 0) {
        Iterator<Map.Entry<Comparable<?>, Long>> iterate =
            this.frequencyDistributionOfIdPatterns.entrySetIterator();
        long min = idPattern.getMFIdPatternFrequency();
        while (iterate.hasNext()) {
          Entry<Comparable<?>, Long> next = iterate.next();
          if (next.getValue() < min) {
            min = next.getValue();
          }
        }
        idPattern.setMinimumFrequency(min);
      } else {
        idPattern.setMinimumFrequency(-1);
      }
      disMetadata.setIdPattern(idPattern);
    }
    disMetadata.addToIndexes();
  }

  private String findIdPattern(RequirementStatement reqSt) {
    String pattern = "";
    String id = reqSt.getId();
    for (char c : id.toCharArray()) {
      if ((int) c >= 65 && c <= 90) { // A:65 - Z:90
        pattern += "C";
      } else if ((int) c >= 97 && c <= 122) { // a:97 - z:122
        pattern += "c";
      } else if ((int) c >= 48 && c <= 57) { // 0:48 - 9:57
        pattern += "d";
      } else {
        pattern += c;
      }
    }
    return pattern;
  }

  // Chunking on the sentence level, input: any text
  public JCas chunking(String text) throws Exception {
    JCas tcas = null;
    try {
      tcas = JCasFactory.createJCas();
      tcas.setDocumentLanguage("en");
      tcas.setDocumentText(text);
      chunking.process(tcas);
    } catch (UIMAException e) {
      e.printStackTrace();
    }
    return tcas;
  }

  @Override
  public void collectionProcessComplete() {
    String message = String.format("%s has been processed successfully ..",
        "Discourse Metadata Task");
    this.logger.info(message);
  }

}
