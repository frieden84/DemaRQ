package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.cas.Feature;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.tcas.Annotation_Type;


public class WordDocFeatures_Type extends Annotation_Type {
  /** @generated */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  protected FSGenerator getFSGenerator() {
    return fsGenerator;
  }

  /** @generated */
  @SuppressWarnings("rawtypes")
  private final FSGenerator fsGenerator = new FSGenerator() {
    public FeatureStructure createFS(int addr, CASImpl cas) {
      if (WordDocFeatures_Type.this.useExistingInstance) {
        // Return eq fs instance if already created
        FeatureStructure fs = WordDocFeatures_Type.this.jcas.getJfsFromCaddr(addr);
        if (null == fs) {
          fs = new WordDocFeatures(addr, WordDocFeatures_Type.this);
          WordDocFeatures_Type.this.jcas.putJfsFromCaddr(addr, fs);
          return fs;
        }
        return fs;
      } else {
        return new WordDocFeatures(addr, WordDocFeatures_Type.this);
      }
    }
  };
  /** @generated */
  public final static int typeIndexID = WordDocFeatures.typeIndexID;
  /**
   * @generated
   * @modifiable
   */
  public final static boolean featOkTst =
      JCasRegistry.getFeatOkTst("lu.svv.saa.requirements.autofinding.type.WordDocFeatures");

  /**** Feature: fontName ****/
  /** @generated */
  final Feature casFeat_fontName;
  /** @generated */
  final int casFeatCode_fontName;

  /** @generated */
  public String getFontName(int addr) {
    if (featOkTst && casFeat_fontName == null) {
      jcas.throwFeatMissing("fontName", "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_fontName);
  }

  /** @generated */
  public void setFontName(int addr, String v) {
    if (featOkTst && casFeat_fontName == null) {
      jcas.throwFeatMissing("fontName", "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_fontName, v);
  }

  /**** Feature: fontSize ****/
  /** @generated */
  final Feature casFeat_fontSize;
  /** @generated */
  final int casFeatCode_fontSize;

  /** @generated */
  public int getFontSize(int addr) {
    if (featOkTst && casFeat_fontSize == null) {
      jcas.throwFeatMissing("fontSize", "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    return ll_cas.ll_getIntValue(addr, casFeatCode_fontSize);
  }

  /** @generated */
  public void setFontSize(int addr, int v) {
    if (featOkTst && casFeat_fontSize == null) {
      jcas.throwFeatMissing("fontSize", "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    ll_cas.ll_setIntValue(addr, casFeatCode_fontSize, v);
  }

  /**** Feature: isItalic ****/
  /** @generated */
  final Feature casFeat_isItalic;
  /** @generated */
  final int casFeatCode_isItalic;

  /** @generated */
  public boolean getIsItalic(int addr) {
    if (featOkTst && casFeat_isItalic == null) {
      jcas.throwFeatMissing("isItalic", "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_isItalic);
  }

  /** @generated */
  public void seIisItalic(int addr, boolean v) {
    if (featOkTst && casFeat_isItalic == null) {
      jcas.throwFeatMissing("isItalic", "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_isItalic, v);
  }

  /**** Feature: isBold ****/
  /** @generated */
  final Feature casFeat_isBold;
  /** @generated */
  final int casFeatCode_isBold;

  /** @generated */
  public boolean getIsBold(int addr) {
    if (featOkTst && casFeat_isBold == null) {
      jcas.throwFeatMissing("isBold", "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_isBold);
  }

  /** @generated */
  public void seIisBold(int addr, boolean v) {
    if (featOkTst && casFeat_isBold == null) {
      jcas.throwFeatMissing("isBold", "lu.svv.saa.requirements.autofinding.type.WordDocFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_isBold, v);
  }

  /**
   * initialize variables to correspond with Cas Type and Features
   * 
   * @generated
   */
  public WordDocFeatures_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl) this.casType, getFSGenerator());

    casFeat_fontName = jcas.getRequiredFeatureDE(casType, "fontName", "uima.cas.String", featOkTst);
    casFeatCode_fontName = (null == casFeat_fontName) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_fontName).getCode();

    casFeat_fontSize =
        jcas.getRequiredFeatureDE(casType, "fontSize", "uima.cas.Integer", featOkTst);
    casFeatCode_fontSize = (null == casFeat_fontSize) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_fontSize).getCode();

    casFeat_isItalic =
        jcas.getRequiredFeatureDE(casType, "isItalic", "uima.cas.Boolean", featOkTst);
    casFeatCode_isItalic = (null == casFeat_isItalic) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_isItalic).getCode();

    casFeat_isBold = jcas.getRequiredFeatureDE(casType, "isBold", "uima.cas.Boolean", featOkTst);
    casFeatCode_isBold = (null == casFeat_isBold) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_isBold).getCode();

  }

}
