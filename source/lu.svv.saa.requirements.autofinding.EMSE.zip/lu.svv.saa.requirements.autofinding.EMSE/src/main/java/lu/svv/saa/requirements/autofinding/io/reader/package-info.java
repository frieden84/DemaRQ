/**
 * Reading from a word document
 */
/**
 * @author sallam.abualhaija
 *
 */
package lu.svv.saa.requirements.autofinding.io.reader;
