/**
 * Reading from a word document
 */
/**
 * @author <a href="mailto:sallam.abualhaija@uni.lu">Sallam Abualhaija</a> 
 *
 */
package lu.svv.saa.requirements.autofinding.io.reader;
