package lu.svv.saa.requirements.autofinding.annotation;

import static org.apache.uima.fit.util.JCasUtil.select;
import static org.apache.uima.fit.util.JCasUtil.selectCovered;
import org.apache.log4j.Logger;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.jcas.JCas;
import org.uimafit.component.JCasAnnotator_ImplBase;
import org.uimafit.descriptor.ConfigurationParameter;
import lu.svv.saa.requirements.autofinding.type.DiscourseFeatures;
import lu.svv.saa.requirements.autofinding.type.LexicalFeatures;
import lu.svv.saa.requirements.autofinding.type.RequirementCandidate;
import lu.svv.saa.requirements.autofinding.type.RequirementStatement;
import lu.svv.saa.requirements.autofinding.type.SemanticalFeatures;
import lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures;

public class RequirementCandidateAnnotator extends JCasAnnotator_ImplBase {

  public static final String PARAM_DOC_ABB = "docAbb";
  @ConfigurationParameter(name = PARAM_DOC_ABB, mandatory = true,
      description = "document abbreviation for ID", defaultValue = "XX")
  private String docAbb;

  private final Logger logger = Logger.getLogger(getClass());

  @Override
  public void process(JCas jcas) throws AnalysisEngineProcessException {
    int index = 1;
    for (RequirementStatement reqSt : select(jcas, RequirementStatement.class)) {
      // Annotating Requirement Candidates
      RequirementCandidate rcAnnotation = new RequirementCandidate(jcas);

      rcAnnotation.setID(docAbb + "-" + Integer.toString(index));
      rcAnnotation.setIsRequirement(false);
      rcAnnotation.setConfidence(1.0);
      rcAnnotation.setRequirement(reqSt);
      rcAnnotation.setBegin(reqSt.getBegin());
      rcAnnotation.setEnd(reqSt.getEnd());
      rcAnnotation.setLexFeatures((selectCovered(LexicalFeatures.class, reqSt).size() > 0
          ? selectCovered(LexicalFeatures.class, reqSt).get(0)
          : null));
      rcAnnotation.setSynFeatures((selectCovered(SyntacticalFeatures.class, reqSt).size() > 0
          ? selectCovered(SyntacticalFeatures.class, reqSt).get(0)
          : null));
      rcAnnotation.setSemFeatures((selectCovered(SemanticalFeatures.class, reqSt).size() > 0
          ? selectCovered(SemanticalFeatures.class, reqSt).get(0)
          : null));
      rcAnnotation.setDiscourseFeatures((selectCovered(DiscourseFeatures.class, reqSt).size() > 0
          ? selectCovered(DiscourseFeatures.class, reqSt).get(0)
          : null));
      rcAnnotation.addToIndexes();

      ++index;
    }
  }

  @Override
  public void collectionProcessComplete() {
    String message = String.format("%s has been processed successfully ..",
        "Creating Requirement Candidate");
    this.logger.info(message);
  }

}
