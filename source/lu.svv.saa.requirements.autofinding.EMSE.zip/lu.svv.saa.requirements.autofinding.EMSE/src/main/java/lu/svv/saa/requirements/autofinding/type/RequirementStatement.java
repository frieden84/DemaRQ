/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;
import org.apache.uima.jcas.tcas.Annotation;

public class RequirementStatement extends Annotation {
  /**
   * @generated
   * @ordered
   */
  public final static int typeIndexID = JCasRegistry.register(RequirementStatement.class);
  /**
   * @generated
   * @ordered
   */
  public final static int type = typeIndexID;

  /** @generated */
  @Override
  public int getTypeIndexID() {
    return typeIndexID;
  }

  /**
   * Never called. Disable default constructor
   * 
   * @generated
   */
  public RequirementStatement() {}

  /**
   * Internal - constructor used by generator
   * 
   * @generated
   */
  public RequirementStatement(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  /** @generated */
  public RequirementStatement(JCas jCas) {
    super(jCas);
    readObject();
  }

  /** @generated */
  public RequirementStatement(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  /**
   * <!-- begin-user-doc --> Write your own initialization here <!-- end-user-doc -->
   * 
   * @generated modifiable
   */
  private void readObject() {}

  // *--------------*
  // * Feature: id

  /**
   * getter for RequirementStatement id
   * 
   * @generated
   */
  public String getId() {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_id == null) {
      jcasType.jcas.throwFeatMissing("id",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((RequirementStatement_Type) jcasType).casFeatCode_id);
  }

  /**
   * setter for requirement id
   * 
   * @generated
   */
  public void setId(String v) {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_id == null) {
      jcasType.jcas.throwFeatMissing("id",
          "lu.svv.saa.statements.autofinding.type.RequirementStatement");
    }
    jcasType.ll_cas.ll_setStringValue(addr, ((RequirementStatement_Type) jcasType).casFeatCode_id,
        v);
  }

  // *--------------*
  // * Feature: idBegin

  /**
   * getter for statement id beginning
   * 
   * @generated
   */
  public int getIdBegin() {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_idBegin == null) {
      jcasType.jcas.throwFeatMissing("idBegin",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((RequirementStatement_Type) jcasType).casFeatCode_idBegin);
  }

  /**
   * setter for statement id begin
   * 
   * @generated
   */
  public void setIdBegin(int v) {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_idBegin == null) {
      jcasType.jcas.throwFeatMissing("idBegin",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    jcasType.ll_cas.ll_setIntValue(addr, ((RequirementStatement_Type) jcasType).casFeatCode_idBegin,
        v);
  }

  // *--------------*
  // * Feature: idEnd

  /**
   * getter for statement id End
   * 
   * @generated
   */
  public int getIdEnd() {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_idEnd == null) {
      jcasType.jcas.throwFeatMissing("idEnd",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((RequirementStatement_Type) jcasType).casFeatCode_idEnd);
  }

  /**
   * setter for statement id End
   * 
   * @generated
   */
  public void setIdEnd(int v) {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_idEnd == null) {
      jcasType.jcas.throwFeatMissing("idEnd",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    jcasType.ll_cas.ll_setIntValue(addr, ((RequirementStatement_Type) jcasType).casFeatCode_idEnd,
        v);
  }

  // *--------------*
  // * Feature: title

  /**
   * getter for statement title
   * 
   * @generated
   */
  public String getTitle() {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_title == null) {
      jcasType.jcas.throwFeatMissing("title",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((RequirementStatement_Type) jcasType).casFeatCode_title);
  }

  /**
   * setter for statement title
   * 
   * @generated
   */
  public void setTitle(String v) {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_title == null) {
      jcasType.jcas.throwFeatMissing("title",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    jcasType.ll_cas.ll_setStringValue(addr,
        ((RequirementStatement_Type) jcasType).casFeatCode_title, v);
  }


  // *--------------*
  // * Feature: titleBegin

  /**
   * getter for statement title beginning
   * 
   * @generated
   */
  public int getTitleBegin() {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_titleBegin == null) {
      jcasType.jcas.throwFeatMissing("titleBegin",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((RequirementStatement_Type) jcasType).casFeatCode_titleBegin);
  }

  /**
   * setter for statement title begin
   * 
   * @generated
   */
  public void setTitleBegin(int v) {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_titleBegin == null) {
      jcasType.jcas.throwFeatMissing("titleBegin",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    jcasType.ll_cas.ll_setIntValue(addr,
        ((RequirementStatement_Type) jcasType).casFeatCode_titleBegin, v);
  }

  // *--------------*
  // * Feature: titleEnd

  /**
   * getter for statement title End
   * 
   * @generated
   */
  public int getTitleEnd() {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_titleEnd == null) {
      jcasType.jcas.throwFeatMissing("titleEnd",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((RequirementStatement_Type) jcasType).casFeatCode_titleEnd);
  }

  /**
   * setter for statement title End
   * 
   * @generated
   */
  public void setTitleEnd(int v) {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_titleEnd == null) {
      jcasType.jcas.throwFeatMissing("titleEnd",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    jcasType.ll_cas.ll_setIntValue(addr,
        ((RequirementStatement_Type) jcasType).casFeatCode_titleEnd, v);
  }


  // *--------------*
  // * Feature: text

  /**
   * getter for text - gets the text of a line
   * 
   * @generated
   */
  public String getText() {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_text == null) {
      jcasType.jcas.throwFeatMissing("text",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((RequirementStatement_Type) jcasType).casFeatCode_text);
  }

  /**
   * setter for text - sets the text of line
   * 
   * @generated
   */
  public void setText(String v) {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_text == null) {
      jcasType.jcas.throwFeatMissing("text",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    jcasType.ll_cas.ll_setStringValue(addr, ((RequirementStatement_Type) jcasType).casFeatCode_text,
        v);
  }



  // *--------------*
  // * Feature: textBegin

  /**
   * getter for statement text beginning
   * 
   * @generated
   */
  public int getTextBegin() {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_textBegin == null) {
      jcasType.jcas.throwFeatMissing("textBegin",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((RequirementStatement_Type) jcasType).casFeatCode_textBegin);
  }

  /**
   * setter for statement text begin
   * 
   * @generated
   */
  public void setTextBegin(int v) {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_textBegin == null) {
      jcasType.jcas.throwFeatMissing("textBegin",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    jcasType.ll_cas.ll_setIntValue(addr,
        ((RequirementStatement_Type) jcasType).casFeatCode_textBegin, v);
  }

  // *--------------*
  // * Feature: textEnd

  /**
   * getter for statement text End
   * 
   * @generated
   */
  public int getTextEnd() {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_textEnd == null) {
      jcasType.jcas.throwFeatMissing("textEnd",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((RequirementStatement_Type) jcasType).casFeatCode_textEnd);
  }

  /**
   * setter for statement text End
   * 
   * @generated
   */
  public void setTextEnd(int v) {
    if (RequirementStatement_Type.featOkTst
        && ((RequirementStatement_Type) jcasType).casFeat_textEnd == null) {
      jcasType.jcas.throwFeatMissing("textEnd",
          "lu.svv.saa.requirements.autofinding.type.RequirementStatement");
    }
    jcasType.ll_cas.ll_setIntValue(addr, ((RequirementStatement_Type) jcasType).casFeatCode_textEnd,
        v);
  }

}
