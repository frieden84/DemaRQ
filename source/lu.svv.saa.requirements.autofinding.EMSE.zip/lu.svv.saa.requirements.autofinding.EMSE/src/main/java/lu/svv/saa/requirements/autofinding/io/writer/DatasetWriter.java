package lu.svv.saa.requirements.autofinding.io.writer;

import static org.apache.uima.fit.util.JCasUtil.select;
import static org.apache.uima.fit.util.JCasUtil.selectCovered;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.Feature;
import org.apache.uima.cas.text.AnnotationIndex;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;
import org.uimafit.component.JCasAnnotator_ImplBase;
import org.uimafit.descriptor.ConfigurationParameter;
import de.tudarmstadt.ukp.dkpro.core.api.metadata.type.DocumentMetaData;
import lu.svv.saa.requirements.autofinding.type.DiscourseFeatures;
import lu.svv.saa.requirements.autofinding.type.LexicalFeatures;
import lu.svv.saa.requirements.autofinding.type.RequirementCandidate;
import lu.svv.saa.requirements.autofinding.type.SemanticalFeatures;
import lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures;

public class DatasetWriter extends JCasAnnotator_ImplBase {

  public static final String PARAM_FILE_PATH = "filePath";
  @ConfigurationParameter(name = PARAM_FILE_PATH, mandatory = true,
      description = "The path to save the output file")
  private String filePath;

  public static final String PARAM_UPDATE = "update";
  @ConfigurationParameter(name = PARAM_UPDATE, mandatory = true,
      description = "the updates to be included in the \"readme.info\" file",
      defaultValue = "creating the arff file")
  private String update;

  public static final String PARAM_ADD_IDS = "addIds";
  @ConfigurationParameter(name = PARAM_ADD_IDS, mandatory = true, defaultValue = "true",
      description = "set True, if the candidate id should be added")
  private boolean addIds;

  public static final String PARAM_UPDATE_FILES = "updateFiles";
  @ConfigurationParameter(name = PARAM_UPDATE_FILES, mandatory = true, defaultValue = "true",
      description = "set True, if the the files should be updated and written newly")
  private boolean updateFiles;

  private String docName;
  private List<Feature> features;
  private List<Feature> lexFeatures;
  private List<Feature> synFeatures;
  private List<Feature> semFeatures;
  private List<Feature> disFeatures;
  private StringBuilder candidates;
  private StringBuilder featureVectors;
  private StringBuilder arffHeader;
  private BufferedWriter writer;

  private final Logger logger = Logger.getLogger(getClass());

  @Override
  public void initialize(UimaContext context) throws ResourceInitializationException {
    super.initialize(context);
    this.features = new ArrayList<Feature>();
    this.lexFeatures = new ArrayList<Feature>();
    this.synFeatures = new ArrayList<Feature>();
    this.semFeatures = new ArrayList<Feature>();
    this.disFeatures = new ArrayList<Feature>();
    this.featureVectors = new StringBuilder();
    this.arffHeader = new StringBuilder();
    this.candidates = new StringBuilder();
    this.docName = "";
    this.writer = null;

  }

  @Override
  public void process(JCas jcas) throws AnalysisEngineProcessException {
    DocumentMetaData d = DocumentMetaData.get(jcas);
    this.docName = d.getDocumentTitle();

    this.features = new ArrayList<Feature>();
    this.lexFeatures = new ArrayList<Feature>();
    this.synFeatures = new ArrayList<Feature>();
    this.semFeatures = new ArrayList<Feature>();
    this.disFeatures = new ArrayList<Feature>();
    this.arffHeader = new StringBuilder();
    this.featureVectors = new StringBuilder();
    this.candidates = new StringBuilder();

    getFeatures(jcas);
    getArffHeader();

    for (RequirementCandidate rc : select(jcas, RequirementCandidate.class)) {
      candidates.append(String.format("%s, %s%n", rc.getID(), rc.getCoveredText()));
      // Add requirement candidate Ids
      if (addIds)
        featureVectors.append(String.format("%s,", rc.getID()));
      for (LexicalFeatures lex : selectCovered(LexicalFeatures.class, rc)) {
        for (Feature f : lexFeatures) {
          if (f.getRange().getShortName().equalsIgnoreCase("boolean")) {
            featureVectors.append(String.format("%s,",
                (lex.getFeatureValueAsString(f).equalsIgnoreCase("true") ? 1 : 0)));
          } else {
            featureVectors.append(String.format("%s,", lex.getFeatureValueAsString(f)));
          }
        }
        break;
      }

      for (SyntacticalFeatures syn : selectCovered(SyntacticalFeatures.class, rc)) {
        for (Feature f : synFeatures) {
          if (f.getRange().getShortName().equalsIgnoreCase("boolean")) {
            featureVectors.append(String.format("%s,",
                (syn.getFeatureValueAsString(f).equalsIgnoreCase("true") ? 1 : 0)));
          } else {
            featureVectors.append(String.format("%s,", syn.getFeatureValueAsString(f)));
          }
        }
        break;
      }

      for (SemanticalFeatures sem : selectCovered(SemanticalFeatures.class, rc)) {
        for (Feature f : semFeatures) {
          if (f.getRange().getShortName().equalsIgnoreCase("boolean")) {
            featureVectors.append(String.format("%s,",
                (sem.getFeatureValueAsString(f).equalsIgnoreCase("true") ? 1 : 0)));
          } else {
            featureVectors.append(String.format("%s,", sem.getFeatureValueAsString(f)));
          }
        }
        break;
      }

      for (DiscourseFeatures dis : selectCovered(DiscourseFeatures.class, rc)) {
        for (Feature f : disFeatures) {
          if (f.getRange().getShortName().equalsIgnoreCase("boolean")) {
            featureVectors.append(String.format("%s,",
                (dis.getFeatureValueAsString(f).equalsIgnoreCase("true") ? 1 : 0)));
          } else {
            featureVectors.append(String.format("%s,", dis.getFeatureValueAsString(f)));
          }
        }
        break;
      }
      featureVectors.append(String.format("%s", "?"));
      featureVectors.append(String.format("%n"));
    }

    if (updateFiles) {
      writeToFile(filePath, ".testset.arff", arffHeader.toString(), featureVectors.toString());
      writeToFile(filePath, ".sentences.info", String.format("%s, %s%n", "ID", "candidate"),
          candidates.toString());
      
    }
  }

  private void getFeatures(JCas jcas) {
    AnnotationIndex<LexicalFeatures> lexAnn = jcas.getAnnotationIndex(LexicalFeatures.class);
    for (Feature f : lexAnn.getType().getFeatures()) {
      if (f.getDomain().getShortName().equalsIgnoreCase("lexicalfeatures")
          && !f.getShortName().equalsIgnoreCase("idpattern")
          && !f.getShortName().equalsIgnoreCase("idFrequencyCategory")
          && !f.getShortName().equalsIgnoreCase("listId")
          && !f.getShortName().equalsIgnoreCase("textSegmentId")) {
        lexFeatures.add(f);
        features.add(f);
      }
    }
    AnnotationIndex<SyntacticalFeatures> synAnn =
        jcas.getAnnotationIndex(SyntacticalFeatures.class);
    for (Feature f : synAnn.getType().getFeatures()) {
      if (f.getDomain().getShortName().equalsIgnoreCase("syntacticalfeatures")
          && !f.getShortName().equalsIgnoreCase("sentencetype")
          && !f.getShortName().equalsIgnoreCase("whichModals")) {
        synFeatures.add(f);
        features.add(f);
      }
    }
    AnnotationIndex<SemanticalFeatures> semAnn = jcas.getAnnotationIndex(SemanticalFeatures.class);
    for (Feature f : semAnn.getType().getFeatures()) {
      if (f.getDomain().getShortName().equalsIgnoreCase("semanticalfeatures")) {
        semFeatures.add(f);
        features.add(f);
      }
    }
    AnnotationIndex<DiscourseFeatures> disAnn = jcas.getAnnotationIndex(DiscourseFeatures.class);
    for (Feature f : disAnn.getType().getFeatures()) {
      if (f.getDomain().getShortName().equalsIgnoreCase("discoursefeatures")) {
        disFeatures.add(f);
        features.add(f);
      }
    }
  }

  private void getArffHeader() {
    int at = 64;
    int percentage = 37;
    arffHeader.append((char)percentage+String.format("%s%s%n%n", "1. Title: ", docName));
    arffHeader.append((char)percentage+
        String.format("%s%s%s%s%n%n", 
            "2. Creator: ", "S. Abualhaija", 
            "      3. Date: ", new Date().toString()));
    arffHeader.append(String.format((char)at+"relation %s%n%n", docName));
    if (addIds)
      arffHeader.append(String.format((char)at+"attribute  %-20s %-20s%n", "docAbb-reqID", "STRING"));
    String idPatternCat = "{LOW, MED, HIGH, MISSING}"; 
    for (Feature f : features) {
      arffHeader.append(String.format((char)at+"attribute  %-20s %-20s%n", f.getShortName(),
          (f.getRange().getShortName().equalsIgnoreCase("String") ? idPatternCat : "NUMERIC")));
    }
    arffHeader.append(
        String.format((char)at+"attribute  %-20s %-20s%n", "class", "{REQUIREMENT, NONREQUIREMENT}"));
    arffHeader.append(String.format("%n%s%n", (char)at+"data"));
  }

  private void writeToFile(String path, String fileName, String header, String data) {
    try {
      File newDir = new File(path + "/");//results
      // if the directory does not exist, create it
      if (!newDir.exists()) {
        try {
          newDir.mkdir();
        } catch (SecurityException se) {
        }
      }
      writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(
          newDir.getAbsolutePath() + "/" + fileName), "UTF-8"));
      writer.write(header);
      writer.write(data);
      writer.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  @Override
  public void collectionProcessComplete() {
    String message = String.format("%s has been processed successfully ..",
        "Feature Extraction Pipeline");
    this.logger.info(message);
  }

}
