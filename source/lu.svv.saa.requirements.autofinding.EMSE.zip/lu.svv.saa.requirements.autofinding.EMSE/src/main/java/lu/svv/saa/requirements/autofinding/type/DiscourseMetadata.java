package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;
import org.apache.uima.jcas.tcas.Annotation;

public class DiscourseMetadata extends Annotation {
  /**
   * @generated
   * @ordered
   */
  public final static int typeIndexID = JCasRegistry.register(DiscourseMetadata.class);
  /**
   * @generated
   * @ordered
   */
  public final static int type = typeIndexID;

  /** @generated */
  @Override
  public int getTypeIndexID() {
    return typeIndexID;
  }

  /**
   * Never called. Disable default constructor
   * 
   * @generated
   */
  public DiscourseMetadata() {}

  /**
   * Internal - constructor used by generator
   * 
   * @generated
   */
  public DiscourseMetadata(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  /** @generated */
  public DiscourseMetadata(JCas jCas) {
    super(jCas);
    readObject();
  }

  /** @generated */
  public DiscourseMetadata(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  /**
   * <!-- begin-user-doc --> Write your own initialization here <!-- end-user-doc -->
   * 
   * @generated modifiable
   */
  private void readObject() {}

  // *--------------*
  // * Feature: MFFontName
  /**
   * getter for MFFontName
   * 
   * @generated
   */
  public String getMFFontName() {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFFontName == null) {
      jcasType.jcas.throwFeatMissing("MFFontName",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_MFFontName);
  }

  /**
   * setter for MFFontName
   * 
   * @generated
   */
  public void setMFFontName(String v) {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFFontName == null) {
      jcasType.jcas.throwFeatMissing("MFFontName",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    jcasType.ll_cas.ll_setStringValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_MFFontName, v);
  }

  // *--------------*
  // * Feature: MFFontSize
  /**
   * getter for MFFontSize
   * 
   * @generated
   */
  public String getMFFontSize() {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFFontSize == null) {
      jcasType.jcas.throwFeatMissing("MFFontSize",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_MFFontSize);
  }

  /**
   * setter for MFFontSize
   * 
   * @generated
   */
  public void setMFFontSize(String v) {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFFontSize == null) {
      jcasType.jcas.throwFeatMissing("MFFontSize",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    jcasType.ll_cas.ll_setStringValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_MFFontSize, v);
  }

  // *--------------*
  // * Feature: MFFontItalic
  /**
   * getter for MFFontItalic
   * 
   * @generated
   */
  public boolean getMFFontItalic() {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFFontItalic == null) {
      jcasType.jcas.throwFeatMissing("MFFontItalic",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_MFFontItalic);
  }

  /**
   * setter for MFFontItalic
   * 
   * @generated
   */
  public void setMFFontItalic(boolean v) {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFFontItalic == null) {
      jcasType.jcas.throwFeatMissing("MFFontItalic",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_MFFontItalic, v);
  }

  // *--------------*
  // * Feature: MFFontBold
  /**
   * getter for MFFontBold
   * 
   * @generated
   */
  public boolean getMFFontBold() {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFFontBold == null) {
      jcasType.jcas.throwFeatMissing("MFFontBold",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_MFFontBold);
  }

  /**
   * setter for MFFontBold
   * 
   * @generated
   */
  public void setMFFontBold(boolean v) {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFFontBold == null) {
      jcasType.jcas.throwFeatMissing("MFFontBold",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_MFFontBold, v);
  }

  // *--------------*
  // * Feature: MFNP
  /**
   * getter for MFNP
   * 
   * @generated
   */
  public String getMFNP() {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFNP == null) {
      jcasType.jcas.throwFeatMissing("MFNP",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_MFNP);
  }

  /**
   * setter for MFNP
   * 
   * @generated
   */
  public void setMFNP(String v) {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFNP == null) {
      jcasType.jcas.throwFeatMissing("MFNP",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    jcasType.ll_cas.ll_setStringValue(addr, ((DiscourseMetadata_Type) jcasType).casFeatCode_MFNP,
        v);
  }

  // *--------------*
  // * Feature: MFCategory
  /**
   * getter for MFCategory
   * 
   * @generated
   */
  public String getMFCategory() {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFCategory == null) {
      jcasType.jcas.throwFeatMissing("MFCategory",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_MFCategory);
  }

  /**
   * setter for MFCategory
   * 
   * @generated
   */
  public void setMFCategory(String v) {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFCategory == null) {
      jcasType.jcas.throwFeatMissing("MFCategory",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    jcasType.ll_cas.ll_setStringValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_MFCategory, v);
  }

  // *--------------*
  // * Feature: hasIds
  /**
   * getter for hasIds
   * 
   * @generated
   */
  public boolean gethasIds() {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_hasIds == null) {
      jcasType.jcas.throwFeatMissing("hasIds",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_hasIds);
  }

  /**
   * setter for hasIds
   * 
   * @generated
   */
  public void sethasIds(boolean v) {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_hasIds == null) {
      jcasType.jcas.throwFeatMissing("hasIds",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr, ((DiscourseMetadata_Type) jcasType).casFeatCode_hasIds,
        v);
  }


  // *--------------*
  // * Feature: idPattern
  /**
   * getter for idPattern
   * 
   * @generated
   * @return value of the feature
   */
  public IdPatternMetadata getIdPattern() {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_idPattern == null)
      jcasType.jcas.throwFeatMissing("idPattern",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    return (IdPatternMetadata) (jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_idPattern)));
  }

  /**
   * setter for idPattern
   * 
   * @generated
   * @param v value to set into the feature
   */
  public void setIdPattern(IdPatternMetadata v) {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_idPattern == null)
      jcasType.jcas.throwFeatMissing("idPattern",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    jcasType.ll_cas.ll_setRefValue(addr, ((DiscourseMetadata_Type) jcasType).casFeatCode_idPattern,
        jcasType.ll_cas.ll_getFSRef(v));
  }

  // *--------------*
  // * Feature: MFModal
  /**
   * getter for MFModal
   * 
   * @generated
   */
  public String getMFModal() {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFModal == null) {
      jcasType.jcas.throwFeatMissing("MFModal",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((DiscourseMetadata_Type) jcasType).casFeatCode_MFModal);
  }

  /**
   * setter for MFModal
   * 
   * @generated
   */
  public void setMFModal(String v) {
    if (DiscourseMetadata_Type.featOkTst
        && ((DiscourseMetadata_Type) jcasType).casFeat_MFModal == null) {
      jcasType.jcas.throwFeatMissing("MFModal",
          "lu.svv.saa.requirements.autofinding.type.DiscourseMetadata");
    }
    jcasType.ll_cas.ll_setStringValue(addr, ((DiscourseMetadata_Type) jcasType).casFeatCode_MFModal,
        v);
  }

}
