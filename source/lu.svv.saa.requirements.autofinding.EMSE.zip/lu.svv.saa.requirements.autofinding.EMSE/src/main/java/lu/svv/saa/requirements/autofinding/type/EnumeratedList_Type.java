/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.cas.Feature;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.tcas.Annotation_Type;


public class EnumeratedList_Type extends Annotation_Type {
  /** @generated */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  protected FSGenerator getFSGenerator() {
    return fsGenerator;
  }

  /** @generated */
  @SuppressWarnings("rawtypes")
  private final FSGenerator fsGenerator = new FSGenerator() {
    public FeatureStructure createFS(int addr, CASImpl cas) {
      if (EnumeratedList_Type.this.useExistingInstance) {
        // Return eq fs instance if already created
        FeatureStructure fs = EnumeratedList_Type.this.jcas.getJfsFromCaddr(addr);
        if (null == fs) {
          fs = new DocxSentence(addr, EnumeratedList_Type.this);
          EnumeratedList_Type.this.jcas.putJfsFromCaddr(addr, fs);
          return fs;
        }
        return fs;
      } else {
        return new EnumeratedList(addr, EnumeratedList_Type.this);
      }
    }
  };
  /** @generated */
  public final static int typeIndexID = EnumeratedList.typeIndexID;
  /**
   * @generated
   * @modifiable
   */
  public final static boolean featOkTst =
      JCasRegistry.getFeatOkTst("lu.svv.saa.requirements.autofinding.type.EnumeratedList");

  /**** Feature: parent ****/

  /** @generated */
  final Feature casFeat_parent;
  /** @generated */
  final int casFeatCode_parent;

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @return the feature value
   */
  public int getParent(int addr) {
    if (featOkTst && casFeat_parent == null)
      jcas.throwFeatMissing("parent", "lu.svv.saa.requirements.autofinding.type.EnumeratedList");
    return ll_cas.ll_getRefValue(addr, casFeatCode_parent);
  }

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @param v value to set
   */
  public void setParent(int addr, int v) {
    if (featOkTst && casFeat_parent == null)
      jcas.throwFeatMissing("parent", "lu.svv.saa.requirements.autofinding.type.EnumeratedList");
    ll_cas.ll_setRefValue(addr, casFeatCode_parent, v);
  }

  /**
   * initialize variables to correspond with Cas Type and Features
   * 
   * @generated
   */
  public EnumeratedList_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl) this.casType, getFSGenerator());

    casFeat_parent = jcas.getRequiredFeatureDE(casType, "parent",
        "lu.svv.saa.requirements.autofinding.type.DocxSentence", featOkTst);
    casFeatCode_parent = (null == casFeat_parent) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_parent).getCode();

  }

}
