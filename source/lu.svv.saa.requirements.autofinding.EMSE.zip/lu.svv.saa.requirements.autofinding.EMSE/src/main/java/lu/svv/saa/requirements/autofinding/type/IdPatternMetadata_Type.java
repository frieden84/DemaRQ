/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.cas.Feature;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.tcas.Annotation_Type;


public class IdPatternMetadata_Type extends Annotation_Type {
  /** @generated */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  protected FSGenerator getFSGenerator() {
    return fsGenerator;
  }

  /** @generated */
  @SuppressWarnings("rawtypes")
  private final FSGenerator fsGenerator = new FSGenerator() {
    public FeatureStructure createFS(int addr, CASImpl cas) {
      if (IdPatternMetadata_Type.this.useExistingInstance) {
        // Return eq fs instance if already created
        FeatureStructure fs = IdPatternMetadata_Type.this.jcas.getJfsFromCaddr(addr);
        if (null == fs) {
          fs = new IdPatternMetadata(addr, IdPatternMetadata_Type.this);
          IdPatternMetadata_Type.this.jcas.putJfsFromCaddr(addr, fs);
          return fs;
        }
        return fs;
      } else {
        return new IdPatternMetadata(addr, IdPatternMetadata_Type.this);
      }
    }
  };
  /** @generated */
  public final static int typeIndexID = IdPatternMetadata.typeIndexID;
  /**
   * @generated
   * @modifiable
   */
  public final static boolean featOkTst =
      JCasRegistry.getFeatOkTst("lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");

  /**** Feature: MFIdPattern ****/
  /** @generated */
  final Feature casFeat_MFIdPattern;
  /** @generated */
  final int casFeatCode_MFIdPattern;

  /** @generated */
  public String getMFIdPattern(int addr) {
    if (featOkTst && casFeat_MFIdPattern == null) {
      jcas.throwFeatMissing("MFIdPattern",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_MFIdPattern);
  }

  /** @generated */
  public void setMFIdPattern(int addr, String v) {
    if (featOkTst && casFeat_MFIdPattern == null) {
      jcas.throwFeatMissing("MFIdPattern",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_MFIdPattern, v);
  }

  /**** Feature: MFIdPatternFrequency ****/
  /** @generated */
  final Feature casFeat_MFIdPatternFrequency;
  /** @generated */
  final int casFeatCode_MFIdPatternFrequency;

  /** @generated */
  public long getMFIdPatternFrequency(int addr) {
    if (featOkTst && casFeat_MFIdPatternFrequency == null) {
      jcas.throwFeatMissing("MFIdPatternFrequency",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    return ll_cas.ll_getLongValue(addr, casFeatCode_MFIdPatternFrequency);
  }

  /** @generated */
  public void setMFIdPatternFrequency(int addr, long v) {
    if (featOkTst && casFeat_MFIdPatternFrequency == null) {
      jcas.throwFeatMissing("MFIdPatternFrequency",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    ll_cas.ll_setLongValue(addr, casFeatCode_MFIdPatternFrequency, v);
  }

  /**** Feature: MFIdPatternPct ****/
  /** @generated */
  final Feature casFeat_MFIdPatternPct;
  /** @generated */
  final int casFeatCode_MFIdPatternPct;

  /** @generated */
  public double getMFIdPatternPct(int addr) {
    if (featOkTst && casFeat_MFIdPatternPct == null) {
      jcas.throwFeatMissing("MFIdPatternPct",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    return ll_cas.ll_getDoubleValue(addr, casFeatCode_MFIdPatternPct);
  }

  /** @generated */
  public void setMFIdPatternPct(int addr, double v) {
    if (featOkTst && casFeat_MFIdPatternPct == null) {
      jcas.throwFeatMissing("MFIdPatternPct",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    ll_cas.ll_setDoubleValue(addr, casFeatCode_MFIdPatternPct, v);
  }

  /**** Feature: minimumFrequency ****/
  /** @generated */
  final Feature casFeat_minimumFrequency;
  /** @generated */
  final int casFeatCode_minimumFrequency;

  /** @generated */
  public long getMinimumFrequency(int addr) {
    if (featOkTst && casFeat_minimumFrequency == null) {
      jcas.throwFeatMissing("minimumFrequency",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    return ll_cas.ll_getLongValue(addr, casFeatCode_minimumFrequency);
  }

  /** @generated */
  public void setMinimumFrequency(int addr, long v) {
    if (featOkTst && casFeat_minimumFrequency == null) {
      jcas.throwFeatMissing("minimumFrequency",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    ll_cas.ll_setLongValue(addr, casFeatCode_minimumFrequency, v);
  }

  /**** Feature: totalIdPatterns ****/
  /** @generated */
  final Feature casFeat_totalIdPatterns;
  /** @generated */
  final int casFeatCode_totalIdPatterns;

  /** @generated */
  public int getTotalIdPatterns(int addr) {
    if (featOkTst && casFeat_totalIdPatterns == null) {
      jcas.throwFeatMissing("totalIdPatterns",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    return ll_cas.ll_getIntValue(addr, casFeatCode_totalIdPatterns);
  }

  /** @generated */
  public void setTotalIdPatterns(int addr, int v) {
    if (featOkTst && casFeat_totalIdPatterns == null) {
      jcas.throwFeatMissing("totalIdPatterns",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    ll_cas.ll_setIntValue(addr, casFeatCode_totalIdPatterns, v);
  }

  /**
   * initialize variables to correspond with Cas Type and Features
   * 
   * @generated
   */
  public IdPatternMetadata_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl) this.casType, getFSGenerator());

    casFeat_MFIdPattern =
        jcas.getRequiredFeatureDE(casType, "MFIdPattern", "uima.cas.String", featOkTst);
    casFeatCode_MFIdPattern = (null == casFeat_MFIdPattern) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_MFIdPattern).getCode();

    casFeat_MFIdPatternFrequency =
        jcas.getRequiredFeatureDE(casType, "MFIdPatternFrequency", "uima.cas.Long", featOkTst);
    casFeatCode_MFIdPatternFrequency =
        (null == casFeat_MFIdPatternFrequency) ? JCas.INVALID_FEATURE_CODE
            : ((FeatureImpl) casFeat_MFIdPatternFrequency).getCode();

    casFeat_MFIdPatternPct =
        jcas.getRequiredFeatureDE(casType, "MFIdPatternPct", "uima.cas.Double", featOkTst);
    casFeatCode_MFIdPatternPct = (null == casFeat_MFIdPatternPct) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_MFIdPatternPct).getCode();

    casFeat_minimumFrequency =
        jcas.getRequiredFeatureDE(casType, "minimumFrequency", "uima.cas.Long", featOkTst);
    casFeatCode_minimumFrequency = (null == casFeat_minimumFrequency) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_minimumFrequency).getCode();

    casFeat_totalIdPatterns =
        jcas.getRequiredFeatureDE(casType, "totalIdPatterns", "uima.cas.Integer", featOkTst);
    casFeatCode_totalIdPatterns = (null == casFeat_totalIdPatterns) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_totalIdPatterns).getCode();

  }

}
