package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;
import org.apache.uima.jcas.tcas.Annotation;

public class LexicalFeatures extends Annotation {
  /**
   * @generated
   * @ordered
   */
  public final static int typeIndexID = JCasRegistry.register(LexicalFeatures.class);
  /**
   * @generated
   * @ordered
   */
  public final static int type = typeIndexID;

  /** @generated */
  @Override
  public int getTypeIndexID() {
    return typeIndexID;
  }

  /**
   * Never called. Disable default constructor
   * 
   * @generated
   */
  public LexicalFeatures() {}

  /**
   * Internal - constructor used by generator
   * 
   * @generated
   */
  public LexicalFeatures(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  /** @generated */
  public LexicalFeatures(JCas jCas) {
    super(jCas);
    readObject();
  }

  /** @generated */
  public LexicalFeatures(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  /**
   * <!-- begin-user-doc --> Write your own initialization here <!-- end-user-doc -->
   * 
   * @generated modifiable
   */
  private void readObject() {}

  // *--------------*
  // * Feature: numOneLetterTokens

  /**
   * getter for number of OneLetter tokens
   * 
   * @generated
   */
  public int getNumOneLetterTokens() {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_numOneLetterTokens == null) {
      jcasType.jcas.throwFeatMissing("numOneLetterTokens",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_numOneLetterTokens);
  }

  /**
   * setter for number of OneLetter tokens
   * 
   * @generated
   */
  public void setNumOneLetterTokens(int v) {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_numOneLetterTokens == null) {
      jcasType.jcas.throwFeatMissing("numOneLetterTokens",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    jcasType.ll_cas.ll_setIntValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_numOneLetterTokens, v);
  }

  // *--------------*
  // * Feature: numTokens

  /**
   * getter for number of tokens
   * 
   * @generated
   */
  public int getNumTokens() {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_numTokens == null) {
      jcasType.jcas.throwFeatMissing("numTokens",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_numTokens);
  }

  /**
   * setter for number of tokens
   * 
   * @generated
   */
  public void setNumTokens(int v) {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_numTokens == null) {
      jcasType.jcas.throwFeatMissing("numTokens",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    jcasType.ll_cas.ll_setIntValue(addr, ((LexicalFeatures_Type) jcasType).casFeatCode_numTokens,
        v);
  }

  // *--------------*
  // * Feature: numAlphabetics

  /**
   * getter for number of alphabetics words
   * 
   * @generated
   */
  public int getNumAlphabetics() {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_numAlphabetics == null) {
      jcasType.jcas.throwFeatMissing("numAlphabetics",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_numAlphabetics);
  }

  /**
   * setter for number of words
   * 
   * @generated
   */
  public void setNumAlphabetics(int v) {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_numAlphabetics == null) {
      jcasType.jcas.throwFeatMissing("numAlphabetics",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    jcasType.ll_cas.ll_setIntValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_numAlphabetics, v);
  }

  // *--------------*
  // * Feature: startsWithIdLike

  /**
   * getter for startsWithIdLike
   * 
   * @generated
   */
  public boolean startsWithIdLike() {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_startsWithIdLike == null) {
      jcasType.jcas.throwFeatMissing("startsWithIdLike",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_startsWithIdLike);
  }

  /**
   * setter for startsWithIdLike
   * 
   * @generated
   */
  public void setStartsWithIdLike(boolean v) {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_startsWithIdLike == null) {
      jcasType.jcas.throwFeatMissing("startsWithIdLike",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_startsWithIdLike, v);
  }

  // *--------------*
  // * Feature: idPattern

  /**
   * getter for the idPattern
   * 
   * @generated
   */
  public String getIdPattern() {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_idPattern == null) {
      jcasType.jcas.throwFeatMissing("idPattern",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_idPattern);
  }

  /**
   * setter for idPattern
   * 
   * @generated
   */
  public void setIdPattern(String v) {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_idPattern == null) {
      jcasType.jcas.throwFeatMissing("idPattern",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    jcasType.ll_cas.ll_setStringValue(addr, ((LexicalFeatures_Type) jcasType).casFeatCode_idPattern,
        v);
  }

  // *--------------*
  // * Feature: idFrequencyCategory

  /**
   * getter for the idFrequencyCategory
   * 
   * @generated
   */
  public String getIdFrequencyCategory() {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_idFrequencyCategory == null) {
      jcasType.jcas.throwFeatMissing("idFrequencyCategory",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_idFrequencyCategory);
  }

  /**
   * setter for idFrequencyCategory
   * 
   * @generated
   */
  public void setIdFrequencyCategory(String v) {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_idFrequencyCategory == null) {
      jcasType.jcas.throwFeatMissing("idFrequencyCategory",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    jcasType.ll_cas.ll_setStringValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_idFrequencyCategory, v);
  }

  // *--------------*
  // * Feature: isPartOfList

  /**
   * getter for isPartOfList
   * 
   * @generated
   */
  public boolean isPartOfList() {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_isPartOfList == null) {
      jcasType.jcas.throwFeatMissing("isPartOfList",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_isPartOfList);
  }

  /**
   * setter for isPartOfList
   * 
   * @generated
   */
  public void setIsPartOfList(boolean v) {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_isPartOfList == null) {
      jcasType.jcas.throwFeatMissing("isPartOfList",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_isPartOfList, v);
  }

  // *--------------*
  // * Feature: isHeaderOfList

  /**
   * getter for isHeaderOfList
   * 
   * @generated
   */
  public boolean isHeaderOfList() {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_isHeaderOfList == null) {
      jcasType.jcas.throwFeatMissing("isHeaderOfList",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_isHeaderOfList);
  }

  /**
   * setter for isHeaderOfList
   * 
   * @generated
   */
  public void setIsHeaderOfList(boolean v) {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_isHeaderOfList == null) {
      jcasType.jcas.throwFeatMissing("isHeaderOfList",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_isHeaderOfList, v);
  }

  // *--------------*
  // * Feature: listId

  /**
   * getter for listId
   * 
   * @generated
   */
  public int getListId() {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_listId == null) {
      jcasType.jcas.throwFeatMissing("listId",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_listId);
  }

  /**
   * setter for listId
   * 
   * @generated
   */
  public void setListId(int v) {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_listId == null) {
      jcasType.jcas.throwFeatMissing("listId",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    jcasType.ll_cas.ll_setIntValue(addr, ((LexicalFeatures_Type) jcasType).casFeatCode_listId, v);
  }

  // *--------------*
  // * Feature: textSegmentId

  /**
   * getter for textSegmentId
   * 
   * @generated
   */
  public int getTextSegmentId() {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_textSegmentId == null) {
      jcasType.jcas.throwFeatMissing("textSegmentId",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_textSegmentId);
  }

  /**
   * setter for textSegmentId
   * 
   * @generated
   */
  public void setTextSegmentId(int v) {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_textSegmentId == null) {
      jcasType.jcas.throwFeatMissing("textSegmentId",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    jcasType.ll_cas.ll_setIntValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_textSegmentId, v);
  }

  // *--------------*
  // * Feature: startsWithTrigger

  /**
   * getter for startsWithTrigger
   * 
   * @generated
   */
  public boolean getStartsWithTrigger() {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_startsWithTrigger == null) {
      jcasType.jcas.throwFeatMissing("startsWithTrigger",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_startsWithTrigger);
  }

  /**
   * setter for startsWithTrigger
   * 
   * @generated
   */
  public void setStartsWithTrigger(boolean v) {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_startsWithTrigger == null) {
      jcasType.jcas.throwFeatMissing("startsWithTrigger",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_startsWithTrigger, v);
  }

  // *--------------*
  // * Feature: hasVagueWords

  /**
   * getter for hasVagueWords
   * 
   * @generated
   */
  public boolean getHasVagueWords() {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_hasVagueWords == null) {
      jcasType.jcas.throwFeatMissing("hasVagueWords",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_hasVagueWords);
  }

  /**
   * setter for hasVagueWords
   * 
   * @generated
   */
  public void setHasVagueWords(boolean v) {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_hasVagueWords == null) {
      jcasType.jcas.throwFeatMissing("hasVagueWords",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_hasVagueWords, v);
  }

  // *--------------*
  // * Feature: hasUnits

  /**
   * getter for hasUnits
   * 
   * @generated
   */
  public boolean getHasUnits() {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_hasUnits == null) {
      jcasType.jcas.throwFeatMissing("hasUnits",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((LexicalFeatures_Type) jcasType).casFeatCode_hasUnits);
  }

  /**
   * setter for hasUnits
   * 
   * @generated
   */
  public void setHasUnits(boolean v) {
    if (LexicalFeatures_Type.featOkTst
        && ((LexicalFeatures_Type) jcasType).casFeat_hasUnits == null) {
      jcasType.jcas.throwFeatMissing("hasUnits",
          "lu.svv.saa.requirements.autofinding.type.LexicalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr, ((LexicalFeatures_Type) jcasType).casFeatCode_hasUnits,
        v);
  }
}
