/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.annotation;

import static org.apache.uima.fit.util.JCasUtil.select;
import static org.apache.uima.fit.util.JCasUtil.selectCovered;
import java.util.HashSet;
import java.util.Set;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.component.JCasAnnotator_ImplBase;
import org.apache.uima.jcas.JCas;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.NGram;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import lu.svv.saa.requirements.autofinding.type.DocxSentence;
import lu.svv.saa.requirements.autofinding.type.EnumeratedList;
import lu.svv.saa.requirements.autofinding.type.LexicalFeatures;
import lu.svv.saa.requirements.autofinding.type.RequirementStatement;

public class LexicalFeaturesExtractor extends JCasAnnotator_ImplBase {

  private final Logger logger = Logger.getLogger(getClass());
  private int listID = 1;
  private int segmentID = 0;

  private static final String COMMENT = "comment";
  private static final String RATIONALE = "rationale";
  private static final String NOTE = "note";

  @Override
  public void process(JCas jcas) throws AnalysisEngineProcessException {
    int foundList = -1;
    int foundSegment = -1;

    for (RequirementStatement reqSt : select(jcas, RequirementStatement.class)) {
      LexicalFeatures lexFeat = new LexicalFeatures(jcas);
      lexFeat.setBegin(reqSt.getBegin());
      lexFeat.setEnd(reqSt.getEnd());
      lexFeat.setNumOneLetterTokens(oneLetterToken(reqSt));
      lexFeat.setNumTokens(selectCovered(Token.class, reqSt).size());
      lexFeat.setNumAlphabetics(numAlphabetics(reqSt));
      lexFeat.setStartsWithIdLike(!reqSt.getId().isEmpty()); // a) or 1) are also id like - TODO
                                                             // adapt to Chetan's work
      // get the id pattern c->a-z, C->A-Z, d->0-9
      String pattern = findIdPattern(reqSt);
      lexFeat.setIdPattern(pattern);

      if (findList(jcas, reqSt) != -1) {
        foundList = findList(jcas, reqSt);
      }
      if (foundList != findList(jcas, reqSt)) {
        ++listID;
      }
      lexFeat.setIsPartOfList(findList(jcas, reqSt) != -1);
      lexFeat.setListId((findList(jcas, reqSt) != -1 ? listID : findList(jcas, reqSt)));
      lexFeat.setIsHeaderOfList(isParent(jcas, reqSt)); 
      if (findTextSegment(jcas, reqSt) != foundSegment) {
        foundSegment = findTextSegment(jcas, reqSt);
        segmentID++;
      }
      lexFeat.setTextSegmentId(segmentID);
      lexFeat.setStartsWithTrigger(verifyTriggers(reqSt));

      lexFeat.setHasVagueWords(lookupVagueWords(reqSt));
      lexFeat.setHasUnits(lookupUnits(reqSt));
      lexFeat.addToIndexes();
    }
  }

  /**** Lexical Features *****/
  // One Character Token but not a punctuation
  private int oneLetterToken(RequirementStatement reqSt) {
    int numOneLetterToken = 0;
    for (Token token : selectCovered(Token.class, reqSt)) {
      if (token.getCoveredText().length() == 1
          && Character.isLetter(token.getCoveredText().charAt(0))) {
        numOneLetterToken++;
      }
    }
    return numOneLetterToken;
  }

  // Number of words in the sentence
  public int numAlphabetics(RequirementStatement reqSt) {
    int numAlphabetics = 0;
    for (Token token : selectCovered(Token.class, reqSt)) {
      if (StringUtils.isAlpha(token.getCoveredText())) {
        ++numAlphabetics;
      }
    }
    return numAlphabetics;
  }

  // Find the list id
  private int findList(JCas jcas, RequirementStatement reqSt) {
    // Loop over EnumeratedList
    for (EnumeratedList el : select(jcas, EnumeratedList.class)) {
      if (reqSt.getBegin() >= el.getBegin() && reqSt.getEnd() <= el.getEnd()) {
        return el.getBegin();
      }
    }
    return -1;
  }

  // Find if the statement is a header of a list
  private boolean isParent(JCas jcas, RequirementStatement reqSt) {
    // Loop over EnumeratedList
    for (EnumeratedList el : select(jcas, EnumeratedList.class)) {
      if (el.getParent() == null) {
        return false;
      }
      if (reqSt.getBegin() == el.getParent().getBegin()) {
        return true;
      }
    }
    return false;
  }

  // Find the text segment id to which the statement belongs
  private int findTextSegment(JCas jcas, RequirementStatement reqSt) {
    int segId = 0;
    for (DocxSentence seg : select(jcas, DocxSentence.class)) {
      if (reqSt.getBegin() >= seg.getBegin() && reqSt.getEnd() <= seg.getEnd()) {
        segId = seg.getBegin();
      }
    }
    return segId;
  }

  // Get the id-pattern
  private String findIdPattern(RequirementStatement reqSt) {
    String pattern = "";
    String id = reqSt.getId();
    for (char c : id.toCharArray()) {
      if ((int) c >= 65 && c <= 90) { // A:65 - Z:90
        pattern += "C";
      } else if ((int) c >= 97 && c <= 122) { // a:97 - z:122
        pattern += "c";
      } else if ((int) c >= 48 && c <= 57) { // 0:48 - 9:57
        pattern += "d";
      } else {
        pattern += c;
      }
    }
    return pattern;
  }

  // Verify if the statement starts with a trigger word
  private boolean verifyTriggers(RequirementStatement reqSt) {
    String title = reqSt.getTitle().toLowerCase();
    Set<String> triggers = new HashSet<String>();
    //triggers.add(REQUIREMENT);
    triggers.add(RATIONALE);
    triggers.add(COMMENT);
    triggers.add(NOTE);
    Set<String> toFind = new HashSet<String>();
    toFind.add(title);
    triggers.retainAll(toFind);

    return triggers.size() != 0;
  }

  // Look up vague words from an external list
  private boolean lookupVagueWords(RequirementStatement reqSt) {
    if (selectCovered(NGram.class, reqSt).size() > 0) {
      return true;
      }
    return false;
  }

  // Look up units from an external list
  private boolean lookupUnits(RequirementStatement reqSt) {
    for (int i = 0; i < selectCovered(Token.class, reqSt).size() - 1; ++i) {
      Token token = selectCovered(Token.class, reqSt).get(i);
      if (StringUtils.isNumeric(token.getCoveredText())) {
        Token nextToken = selectCovered(Token.class, reqSt).get(i + 1);
        if (selectCovered(NGram.class, nextToken).size() > 0) {
          return true;
        }
      }
    }
    return false;
  }

  @Override
  public void collectionProcessComplete() {
    String message = String.format("%s has been processed successfully ..",
        "Lexical Feature Extraction");
    this.logger.info(message);
  }
}
