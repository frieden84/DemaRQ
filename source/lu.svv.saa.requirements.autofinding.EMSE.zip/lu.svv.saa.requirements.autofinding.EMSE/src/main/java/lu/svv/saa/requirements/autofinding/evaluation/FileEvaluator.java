/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.evaluation;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileEvaluator {

  public static void main(String[] args) {
    // READ Files into list
    final String goldStandardPath = "src/main/resources/GoldStandards/lunarRoverC.txt";
    final String resultsPath = "src/main/resources/output/test.txt";

    BufferedReader gold = null;
    BufferedReader results = null;
    List<String> goldList = new ArrayList<String>();
    List<String> resultsList = new ArrayList<String>();
    try {
      results = new BufferedReader(new FileReader(resultsPath));
      gold = new BufferedReader(new FileReader(goldStandardPath));

      String sCurrentLine;

      while ((sCurrentLine = gold.readLine()) != null) {
        goldList.add(sCurrentLine);
      }
      while ((sCurrentLine = results.readLine()) != null) {
        resultsList.add(sCurrentLine);
      }
    } catch (IOException e) {
      e.printStackTrace();
    }

    // compare lists:
    double correct = 0;
    boolean found;
    for (String statement : resultsList) {
      found = false;
      for (String req : goldList) {
        if (matches(req, statement)) {
          found = true;
          break;
        }
      }
      if (found) {
        ++correct;
      } else {
        System.out.println(statement);
      }
    }
    // System.out.println(correct + " " + resultsList.size());
    double precision = correct / resultsList.size();
    double recall = correct / goldList.size();
    System.out.println("Precision (correct/found by System) = " + precision);
    System.out.println("Recall (correct/total in Gold) = " + recall);

  }

  private static boolean matches(String req, String statement) {
    boolean equal = false;
    req = req.replaceAll("\\s", "");
    statement = statement.replaceAll("\\s", "");
    if (req.equals(statement)) {
      equal = true;
    }
    /*
     * if(!equal) { System.out.println(req + " | \n\t" + statement); }
     */
    return equal;
  }
}
