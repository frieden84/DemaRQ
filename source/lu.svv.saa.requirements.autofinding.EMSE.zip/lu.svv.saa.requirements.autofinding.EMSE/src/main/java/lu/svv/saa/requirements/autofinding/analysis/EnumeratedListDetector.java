package lu.svv.saa.requirements.autofinding.analysis;

import static org.apache.uima.fit.util.JCasUtil.select;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.jcas.JCas;
import org.uimafit.component.JCasAnnotator_ImplBase;
import org.uimafit.descriptor.ConfigurationParameter;
import lu.svv.saa.requirements.autofinding.type.DocxSentence;
import lu.svv.saa.requirements.autofinding.type.EnumeratedList;

public class EnumeratedListDetector extends JCasAnnotator_ImplBase {

  public static final String PARAM_PARAPHRASE = "paraphrase";
  @ConfigurationParameter(name = PARAM_PARAPHRASE, mandatory = true,
      description = "If the header is rephrased by appending the items in the list",
      defaultValue = "false")
  private boolean paraphrase;

  public static final String PARAM_PARENT_NGRAM = "parentNgram";
  @ConfigurationParameter(name = PARAM_PARENT_NGRAM, mandatory = true,
      description = "Number of sentences to look for parents above the list starting point",
      defaultValue = "3")
  private int parentNgram;

  public static final String PARAM_SIBLINGS_NGRAM = "siblingsNgram";
  @ConfigurationParameter(name = PARAM_SIBLINGS_NGRAM, mandatory = true,
      description = "Number of sentences to skip while finding the rest of list",
      defaultValue = "2")
  private int siblingsNgram;

  private final Logger logger = Logger.getLogger(getClass());

  private List<String> inList = new ArrayList<String>();
  private boolean roman = false;

  @Override
  public void process(JCas jcas) throws AnalysisEngineProcessException {
    // listrecognizerTimer = new RunningTimeLogger(docName, "Enumerated List Recognition");
    // loop over all sentences
    // find the starting point of an enumerated list = mark begin
    // loop over next few sentences
    // find the end = mark end
    // look for parent in the previous few sentences
    List<DocxSentence> sents = new ArrayList<DocxSentence>();
    for (DocxSentence sent : select(jcas, DocxSentence.class)) {
      sents.add(sent);
    }

    int begin = 0;
    int end = 0;
    int index = 0;
    while (index < sents.size()) {
      DocxSentence sent = sents.get(index);
      if (StartOfList(sent.getText())) {
        begin = sent.getBegin();
        DocxSentence parent = null;
        if (sents.indexOf(sent) > 1) {
          parent = lookForParent(jcas, sents, sents.indexOf(sent));
        }
        end = lookForEnd(jcas, sent);
        newEnumeratedList(jcas, begin, end, parent);
      }
      ++index;
    }
    if (paraphrase) {
      rephrase(jcas);
    }
  }

  private void rephrase(JCas jcas) {
    for (EnumeratedList enumList : select(jcas, EnumeratedList.class)) {
      DocxSentence parent = enumList.getParent();
      // if parent is not complete,
      // then 1. get sub-items 2. rephrase
      List<DocxSentence> subitems = new ArrayList<DocxSentence>();
      if (!isComplete(parent)) {
        subitems = findList(jcas, enumList.getBegin(), enumList.getEnd());
        for (DocxSentence child : subitems) {
          DocxSentence merged = merge(jcas, parent, child);
          merged.setBegin(parent.getBegin());
          merged.setEnd(child.getEnd());
          merged.addToIndexes(jcas);
          child.removeFromIndexes();
        }
        parent.removeFromIndexes();
      }
    }
  }

  private DocxSentence merge(JCas jcas, DocxSentence parent, DocxSentence child) {
    DocxSentence merged = new DocxSentence(jcas);

    merged.setElementType(parent.getElementType());
    merged.setFontName(parent.getFontName());
    merged.setFontSize(parent.getFontSize());
    merged.setIsBold(parent.getIsBold());
    merged.setIsItalic(parent.getIsItalic());
    String text = (child.getText().trim().endsWith(".") ? parent.getText() + child.getText()
        : parent.getText() + child.getText().trim() + ".");
    merged.setText(text);
    return merged;
  }

  private List<DocxSentence> findList(JCas jcas, int begin, int end) {
    List<DocxSentence> subitems = new ArrayList<DocxSentence>();
    for (DocxSentence sent : select(jcas, DocxSentence.class)) {
      if (sent.getBegin() < begin) {
        continue;
      }
      subitems.add(sent);
      if (sent.getEnd() >= end) {
        break;
      }
    }
    return subitems;
  }

  private boolean isComplete(DocxSentence parent) {
    if (parent.getText().trim().endsWith(".")) {
      return true;
    }
    return false;
  }

  private EnumeratedList newEnumeratedList(JCas jcas, int begin, int end, DocxSentence parent) {
    EnumeratedList list = new EnumeratedList(jcas);
    list.setBegin(begin);
    list.setEnd(end);
    list.setParent(parent);
    list.addToIndexes();
    return list;
  }

  private int lookForEnd(JCas jcas, DocxSentence start) {
    int end = start.getEnd();
    int asciiStart = 0;
    int t = 0;
    if (roman) {
      asciiStart = calculateAscii(convertToNumber(start.getText().split(" ")[0].toLowerCase()));
    } else {
      asciiStart = calculateAscii(start.getText().split(" ")[0]);
    }
    for (DocxSentence sent : select(jcas, DocxSentence.class)) {
      if (sent.getBegin() < start.getEnd())
        continue;
      int asciiNext = 0;
      if (!sent.getText().trim().isEmpty())
        if (!roman)
          asciiNext = calculateAscii(sent.getText().split(" ")[0]);
        else
          asciiNext = calculateAscii(convertToNumber(sent.getText().split(" ")[0].toLowerCase()));

      if (asciiNext - asciiStart >= 1 && asciiNext
          - asciiStart <= siblingsNgram) { 
        end = sent.getEnd();
        asciiStart = asciiNext;
        start = sent;
        if (sent.getText().startsWith("i)")) {
          inList.add(sent.getText());
        }
        t = 0;
      } else {
        ++t;
        if (t > siblingsNgram)
          break;
        continue;
      }
    }
    roman = false;
    return end;
  }

  private DocxSentence lookForParent(JCas jcas, List<DocxSentence> sents, int index) {

    for (int i = index - 1; i >= index - parentNgram; --i) {
      DocxSentence sent = sents.get(i);
      if ((parentPotential(sent.getText()) && sameFormat(sent, sents.get(index)))
          || sameFormat(sent, sents.get(index))) {
        return sent;
      }
    }
    return null;
  }

  public boolean parentPotential(String text) {
    if (text.matches(".*[the following|includes].*") && text.endsWith(":")) {
      return true;
    }
    if (!text.endsWith("."))
      return true;
    return false;
  }

  private boolean sameFormat(DocxSentence first, DocxSentence second) {
    if (first.getFontSize() == second.getFontSize() && first.getIsItalic() == second.getIsItalic()
        && first.getIsBold() == second.getIsBold())
      return true;
    return false;
  }

  public boolean PartOfList(String text) {
    if (Character.isLetterOrDigit(text.charAt(0)) && (int) text.charAt(1) == 41)
      return true;
    return false;
  }

  public boolean StartOfList(String text) {
    if (text.split(" ").length < 2)
      return false;
    int ascii = calculateAscii(text.split(" ")[0]);
    if (!text.split(" ")[0].endsWith(")"))
      return false;
    if (ascii == (int) ('1') + (int) (')') || ascii == (int) ('a') + (int) (')'))
      return true;
    if (ascii == (int) ('i') + (int) (')') && !inList.contains(text)) {
      roman = true;
      return true;
    }
    return false;
  }

  public int calculateAscii(String token) {
    int ascii = 0;
    for (int i = 0; i < token.toCharArray().length; ++i) { 
      char c = Character.toLowerCase(token.toCharArray()[i]);
      ascii += (int) c;
    }
    return ascii;
  }

  private String convertToNumber(String token) {
    Map<Character, Integer> symbols = new HashMap<Character, Integer>();
    symbols.put('i', 1);
    symbols.put('v', 5);
    symbols.put('x', 10);
    symbols.put('l', 50);
    symbols.put('c', 100);
    symbols.put('d', 500);
    symbols.put('m', 1000);
    for (char c : token.substring(0, token.length() - 1).toCharArray()) {
      if (!symbols.containsKey(c))
        return token;
    }
    int number = 0;
    char[] chars = token.toCharArray();
    Character keep = 'i';
    for (int i = chars.length - 2; i >= 0; i--) {
      char c = chars[i];
      if (c >= keep) {
        number += symbols.get(c);
      } else {
        number -= symbols.get(c);
      }
      keep = c;
    }
    return Integer.toString(number) + ")";
  }

  @Override
  public void collectionProcessComplete() {
    String message = String.format("%s has been processed successfully ..",
        "List Recognition Task");
    this.logger.info(message);
  }

}
