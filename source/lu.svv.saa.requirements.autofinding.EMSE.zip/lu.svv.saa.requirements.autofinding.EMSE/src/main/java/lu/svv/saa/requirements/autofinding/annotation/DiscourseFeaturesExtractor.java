/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.annotation;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngine;
import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;
import static org.apache.uima.fit.util.JCasUtil.select;
import static org.apache.uima.fit.util.JCasUtil.selectCovered;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.stat.Frequency;
import org.apache.log4j.Logger;
import org.apache.uima.UIMAException;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_engine.AnalysisEngine;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.factory.JCasFactory;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;
import org.uimafit.component.JCasAnnotator_ImplBase;
import org.uimafit.descriptor.ConfigurationParameter;
import com.ibm.icu.text.DecimalFormat;
import de.tudarmstadt.ukp.dkpro.core.api.lexmorph.type.pos.POS_NOUN;
import de.tudarmstadt.ukp.dkpro.core.languagetool.LanguageToolSegmenter;
import de.tudarmstadt.ukp.dkpro.core.opennlp.OpenNlpPosTagger;
import lu.svv.saa.requirements.autofinding.type.DiscourseFeatures;
import lu.svv.saa.requirements.autofinding.type.DiscourseMetadata;
import lu.svv.saa.requirements.autofinding.type.DocxSentence;
import lu.svv.saa.requirements.autofinding.type.RequirementStatement;
import net.sf.extjwnl.JWNLException;
import net.sf.extjwnl.data.IndexWord;
import net.sf.extjwnl.data.POS;
import net.sf.extjwnl.data.Pointer;
import net.sf.extjwnl.data.PointerType;
import net.sf.extjwnl.data.Word;
import net.sf.extjwnl.dictionary.Dictionary;

public class DiscourseFeaturesExtractor extends JCasAnnotator_ImplBase {

  public static final String PARAM_DEMARCATION = "demarcation";
  @ConfigurationParameter(name = PARAM_DEMARCATION, mandatory = true,
      description = "A boolean if the IDs are well demarcated", defaultValue = "true")
  private boolean demarcation;

  public static final String PARAM_HIGH_FREQ_CUTOFF = "highFreqCutoff";
  @ConfigurationParameter(name = PARAM_HIGH_FREQ_CUTOFF, mandatory = true,
      description = "where to cut off the high frequency of id patterns: default 0.3",
      defaultValue = "0.3")
  private double highFreqCutoff;

  public static final String PARAM_MED_FREQ_CUTOFF = "medFreqCutoff";
  @ConfigurationParameter(name = PARAM_MED_FREQ_CUTOFF, mandatory = true,
      description = "where to cut off the med frequency of id patterns: default 0.3",
      defaultValue = "0.3")
  private double medFreqCutoff;

  private final Logger logger = Logger.getLogger(getClass());

  private static final String HIGH = "HIGH";
  private static final String MED = "MED";
  private static final String LOW = "LOW";
  private static final String MISSING = "MISSING";

  private Frequency frequencyDistributionOfIdPatterns = new Frequency();
  private AnalysisEngine postaggingPipeline;

  Dictionary d;

  @Override
  public void initialize(final UimaContext context) throws ResourceInitializationException {
    super.initialize(context);
    postaggingPipeline =
        createEngine(createEngineDescription(createEngineDescription(LanguageToolSegmenter.class),
            createEngineDescription(OpenNlpPosTagger.class)));
    try {
      d = Dictionary.getDefaultResourceInstance();
    } catch (JWNLException e) {
      e.printStackTrace();
    }
  }

  @Override
  public void process(JCas jcas) throws AnalysisEngineProcessException {
    // For each docxSentence
    String MFFontName = "";
    int MFFontSize = -1;
    boolean MFItalic = false;
    boolean MFBold = false;
    String MFNP = "";
    String MFModal = "";
    String MFCategory = "";
    long min = -1;
    long max = -1;

    for (DiscourseMetadata discourseMeta : select(jcas, DiscourseMetadata.class)) {
      MFFontName = discourseMeta.getMFFontName();
      MFFontSize = Integer.parseInt(discourseMeta.getMFFontSize());
      MFItalic = discourseMeta.getMFFontItalic();
      MFBold = discourseMeta.getMFFontBold();

      min = 0;
      max = (discourseMeta.getIdPattern() != null
          ? discourseMeta.getIdPattern().getMFIdPatternFrequency()
          : -1);
      MFCategory = discourseMeta.getMFCategory();
      MFModal = discourseMeta.getMFModal();
      MFNP = discourseMeta.getMFNP();
    }
    for (RequirementStatement reqSt : select(jcas, RequirementStatement.class)) {
      // id-pattern
      String pattern = findIdPattern(reqSt);
      if (pattern.length() > 0)
        this.frequencyDistributionOfIdPatterns.addValue(pattern);
    }

    for (DocxSentence docx : select(jcas, DocxSentence.class)) {
      String fontName = "";
      int fontSize = -1;
      boolean italic = false;
      boolean bold = false;
      if (docx.getFontName() != null)
        fontName = docx.getFontName();
      if (docx.getFontSize() != -1 && docx.getFontSize() > 0)
        fontSize = docx.getFontSize();
      bold = docx.getIsBold();
      italic = docx.getIsItalic();

      for (RequirementStatement reqSt : selectCovered(RequirementStatement.class, docx)) {
        DiscourseFeatures discourseFeat = new DiscourseFeatures(jcas);
        discourseFeat.setBegin(reqSt.getBegin());
        discourseFeat.setEnd(reqSt.getEnd());

        // matches MF font style
        discourseFeat
            .setMatchesMFFontName(fontName.length() > 0 ? fontName.equals(MFFontName) : false);
        discourseFeat.setMatchesMFFontSize(fontSize > 0 ? fontSize == MFFontSize : false);
        discourseFeat.setMatchesMFFontItalic(!(italic ^ MFItalic)); // not a xor b: (1,1)->1,
                                                                    // (0,0)->1
        discourseFeat.setMatchesMFFontBold(!(bold ^ MFBold));

        // includes mf np, mf modal
        DecimalFormat df = new DecimalFormat("#.##");
        discourseFeat
            .setPctMFNP(Double.valueOf(df.format(tokensJaccard(MFNP, reqSt.getCoveredText()))));
        discourseFeat.setHasMFNP(reqSt.getCoveredText().toLowerCase().contains(MFNP));
        discourseFeat.setHasMFModal(reqSt.getCoveredText().toLowerCase().contains(MFModal));

        // matches MF category

        for (String cat : getCategory(reqSt)) {
          boolean containsCat = MFCategory.contains(cat);
          discourseFeat.setMatchesMFCategory(containsCat);
          if (containsCat) {
            break;
          }
        }

        // id-pattern
        String pattern = findIdPattern(reqSt);
        double freq =
            (pattern.isEmpty() ? -1 : frequencyDistributionOfIdPatterns.getCount(pattern));
        if (pattern.trim().isEmpty() && demarcation) {
          discourseFeat.setIdPatternFrequency(MISSING);
        } else {
          discourseFeat.setIdPatternFrequency(getFrequencyCategory(freq, min, max));
        }
        discourseFeat.addToIndexes();
      }
    }
  }

  private double tokensJaccard(String mFNP, String text) {
    List<String> st = new ArrayList<String>();
    for (String t : text.toLowerCase().split(" "))
      st.add(t);
    List<String> np = new ArrayList<String>();
    for (String t : mFNP.split(" "))
      np.add(t);

    np.retainAll(st);
    return (double) np.size() / mFNP.split(" ").length;
  }

  // Get the id-pattern
  private String findIdPattern(RequirementStatement reqSt) {
    String pattern = "";
    String id = reqSt.getId();
    for (char c : id.toCharArray()) {
      if ((int) c >= 65 && c <= 90) { // A:65 - Z:90
        pattern += "C";
      } else if ((int) c >= 97 && c <= 122) { // a:97 - z:122
        pattern += "c";
      } else if ((int) c >= 48 && c <= 57) { // 0:48 - 9:57
        pattern += "d";
      } else {
        pattern += c;
      }
    }
    return pattern;
  }

  private String getFrequencyCategory(double freq, long min, long max) {
    if (!demarcation) {
      return MISSING;
    }
    long range = max - min;
    if (freq >= (max - highFreqCutoff * range))
      return HIGH;
    if (freq < (max - highFreqCutoff * range) && freq >= (min + medFreqCutoff * range))
      return MED;
    else if (freq < (min + medFreqCutoff * range))
      return LOW;
    return MISSING;
  }

//Applying the chunking pipeline
 public JCas posTagging(String text) {
   JCas tcas = null;
   try {
     tcas = JCasFactory.createJCas();
     tcas.setDocumentLanguage("en");
     tcas.setDocumentText(text);
     postaggingPipeline.process(tcas);
   } catch (UIMAException e) {
     e.printStackTrace();
   }
   return tcas;
 }
  private List<String> getCategory(RequirementStatement req) {
    JCas tcas = posTagging(req.getText());

    List<String> cat = new ArrayList<String>();

    for (POS_NOUN noun : select(tcas, POS_NOUN.class)) {

      IndexWord word;
      try {
        word = d.lookupIndexWord(POS.NOUN, noun.getCoveredText());

        if (word != null && word.getSenses().size() > 0) {
          List<Pointer> categories = word.getSenses().get(0).getPointers(PointerType.CATEGORY);
          if (categories.size() > 0)
            for (Word w : categories.get(0).getTarget().getSynset().getWords()) {
              cat.add(w.getLemma());
            }
        }
      } catch (JWNLException e) {
        e.printStackTrace();
      }
    }
    return cat;
  }

  @Override
  public void collectionProcessComplete() {
    String message = String.format("%s has been processed successfully ..",
        "Discourse Features Extraction");
    this.logger.info(message);
  }

}
