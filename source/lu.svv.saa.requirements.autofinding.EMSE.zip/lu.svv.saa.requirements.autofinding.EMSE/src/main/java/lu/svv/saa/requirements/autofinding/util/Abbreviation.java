package lu.svv.saa.requirements.autofinding.util;

public enum Abbreviation {
  // Documents initials to be used as a requirement candidate unique id for tracing them
  LR, CT, MHP, AP, Eu, EB, FSM, NN, NLG, Reg, Swm, Tri, TI, KP, KT, WM, PS, ALI, DID, DR, ERMS, HCS, Pmkr, RS, DOC
}
