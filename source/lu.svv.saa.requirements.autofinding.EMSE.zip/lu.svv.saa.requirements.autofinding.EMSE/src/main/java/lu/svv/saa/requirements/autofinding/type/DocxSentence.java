package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;
import org.apache.uima.jcas.tcas.Annotation;

public class DocxSentence extends Annotation {
  /**
   * @generated
   * @ordered
   */
  public final static int typeIndexID = JCasRegistry.register(DocxSentence.class);
  /**
   * @generated
   * @ordered
   */
  public final static int type = typeIndexID;

  /** @generated */
  @Override
  public int getTypeIndexID() {
    return typeIndexID;
  }

  /**
   * Never called. Disable default constructor
   * 
   * @generated
   */
  public DocxSentence() {}

  /**
   * Internal - constructor used by generator
   * 
   * @generated
   */
  public DocxSentence(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  /** @generated */
  public DocxSentence(JCas jCas) {
    super(jCas);
    readObject();
  }

  /** @generated */
  public DocxSentence(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  /**
   * <!-- begin-user-doc --> Write your own initialization here <!-- end-user-doc -->
   * 
   * @generated modifiable
   */
  private void readObject() {}

  // *--------------*
  // * Feature: text

  /**
   * getter for text
   * 
   * @generated
   */
  public String getText() {
    if (DocxSentence_Type.featOkTst && ((DocxSentence_Type) jcasType).casFeat_text == null) {
      jcasType.jcas.throwFeatMissing("text",
          "lu.svv.saa.requirements.autofinding.type.DocxSentence");
    }
    return jcasType.ll_cas.ll_getStringValue(addr, ((DocxSentence_Type) jcasType).casFeatCode_text);
  }

  /**
   * setter for text
   * 
   * @generated
   */
  public void setText(String v) {
    if (DocxSentence_Type.featOkTst && ((DocxSentence_Type) jcasType).casFeat_text == null) {
      jcasType.jcas.throwFeatMissing("text",
          "lu.svv.saa.requirements.autofinding.type.DocxSentence");
    }
    jcasType.ll_cas.ll_setStringValue(addr, ((DocxSentence_Type) jcasType).casFeatCode_text, v);
  }

  // *--------------*
  // * Feature: elementType

  /**
   * getter for elementType
   * 
   * @generated
   */
  public String getElementType() {
    if (DocxSentence_Type.featOkTst && ((DocxSentence_Type) jcasType).casFeat_elementType == null) {
      jcasType.jcas.throwFeatMissing("elementType",
          "lu.svv.saa.requirements.autofinding.type.DocxSentence");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((DocxSentence_Type) jcasType).casFeatCode_elementType);
  }

  /**
   * setter for type
   * 
   * @generated
   */
  public void setElementType(String v) {
    if (DocxSentence_Type.featOkTst && ((DocxSentence_Type) jcasType).casFeat_elementType == null) {
      jcasType.jcas.throwFeatMissing("elementType",
          "lu.svv.saa.requirements.autofinding.type.DocxSentence");
    }
    jcasType.ll_cas.ll_setStringValue(addr, ((DocxSentence_Type) jcasType).casFeatCode_elementType,
        v);
  }

  // *--------------*
  // * Feature: fontName

  /**
   * getter for fontName
   * 
   * @generated
   */
  public String getFontName() {
    if (DocxSentence_Type.featOkTst && ((DocxSentence_Type) jcasType).casFeat_fontName == null) {
      jcasType.jcas.throwFeatMissing("fontName",
          "lu.svv.saa.requirements.autofinding.type.DocxSentence");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((DocxSentence_Type) jcasType).casFeatCode_fontName);
  }

  /**
   * setter for fontName
   * 
   * @generated
   */
  public void setFontName(String v) {
    if (DocxSentence_Type.featOkTst && ((DocxSentence_Type) jcasType).casFeat_fontName == null) {
      jcasType.jcas.throwFeatMissing("fontName",
          "lu.svv.saa.requirements.autofinding.type.DocxSentence");
    }
    jcasType.ll_cas.ll_setStringValue(addr, ((DocxSentence_Type) jcasType).casFeatCode_fontName, v);
  }

  // *--------------*
  // * Feature: fontSize

  /**
   * getter for fontSize
   * 
   * @generated
   */
  public int getFontSize() {
    if (DocxSentence_Type.featOkTst && ((DocxSentence_Type) jcasType).casFeat_fontSize == null) {
      jcasType.jcas.throwFeatMissing("fontSize",
          "lu.svv.saa.requirements.autofinding.type.DocxSentence");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((DocxSentence_Type) jcasType).casFeatCode_fontSize);
  }

  /**
   * setter for fontSize
   * 
   * @generated
   */
  public void setFontSize(int v) {
    if (DocxSentence_Type.featOkTst && ((DocxSentence_Type) jcasType).casFeat_fontSize == null) {
      jcasType.jcas.throwFeatMissing("fontSize",
          "lu.svv.saa.requirements.autofinding.type.DocxSentence");
    }
    jcasType.ll_cas.ll_setIntValue(addr, ((DocxSentence_Type) jcasType).casFeatCode_fontSize, v);
  }

  // *--------------*
  // * Feature: isItalic

  /**
   * getter for isItalic
   * 
   * @generated
   */
  public boolean getIsItalic() {
    if (DocxSentence_Type.featOkTst && ((DocxSentence_Type) jcasType).casFeat_isItalic == null) {
      jcasType.jcas.throwFeatMissing("isItalic",
          "lu.svv.saa.requirements.autofinding.type.DocxSentence");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((DocxSentence_Type) jcasType).casFeatCode_isItalic);
  }

  /**
   * setter for isItalic
   * 
   * @generated
   */
  public void setIsItalic(boolean v) {
    if (DocxSentence_Type.featOkTst && ((DocxSentence_Type) jcasType).casFeat_isItalic == null) {
      jcasType.jcas.throwFeatMissing("isItalic",
          "lu.svv.saa.requirements.autofinding.type.DocxSentence");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr, ((DocxSentence_Type) jcasType).casFeatCode_isItalic,
        v);
  }

  // *--------------*
  // * Feature: isBold

  /**
   * getter for isBold
   * 
   * @generated
   */
  public boolean getIsBold() {
    if (DocxSentence_Type.featOkTst && ((DocxSentence_Type) jcasType).casFeat_isBold == null) {
      jcasType.jcas.throwFeatMissing("isBold",
          "lu.svv.saa.requirements.autofinding.type.DocxSentence");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((DocxSentence_Type) jcasType).casFeatCode_isBold);
  }

  /**
   * setter for isBold
   * 
   * @generated
   */
  public void setIsBold(boolean v) {
    if (DocxSentence_Type.featOkTst && ((DocxSentence_Type) jcasType).casFeat_isBold == null) {
      jcasType.jcas.throwFeatMissing("isBold",
          "lu.svv.saa.requirements.autofinding.type.DocxSentence");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr, ((DocxSentence_Type) jcasType).casFeatCode_isBold, v);
  }

}
