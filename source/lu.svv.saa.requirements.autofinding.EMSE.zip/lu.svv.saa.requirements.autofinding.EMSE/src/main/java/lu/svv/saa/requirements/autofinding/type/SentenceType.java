/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.StringList;
import org.apache.uima.jcas.cas.TOP_Type;
import org.apache.uima.jcas.tcas.Annotation;

public class SentenceType extends Annotation {
  /**
   * @generated
   * @ordered
   */
  public final static int typeIndexID = JCasRegistry.register(SentenceType.class);
  /**
   * @generated
   * @ordered
   */
  public final static int type = typeIndexID;

  /** @generated */
  @Override
  public int getTypeIndexID() {
    return typeIndexID;
  }

  /**
   * Never called. Disable default constructor
   * 
   * @generated
   */
  public SentenceType() {}

  /**
   * Internal - constructor used by generator
   * 
   * @generated
   */
  public SentenceType(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  /** @generated */
  public SentenceType(JCas jCas) {
    super(jCas);
    readObject();
  }

  /** @generated */
  public SentenceType(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  /**
   * <!-- begin-user-doc --> Write your own initialization here <!-- end-user-doc -->
   * 
   * @generated modifiable
   */
  private void readObject() {}

  // *--------------*
  // * Feature: isSimple

  /**
   * getter for isSimple
   * 
   * @generated
   */
  public boolean getIsSimple() {
    if (SentenceType_Type.featOkTst && ((SentenceType_Type) jcasType).casFeat_isSimple == null) {
      jcasType.jcas.throwFeatMissing("isSimple",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SentenceType_Type) jcasType).casFeatCode_isSimple);
  }

  /**
   * setter for isSimple
   * 
   * @generated
   */
  public void setIsSimple(boolean v) {
    if (SentenceType_Type.featOkTst && ((SentenceType_Type) jcasType).casFeat_isSimple == null) {
      jcasType.jcas.throwFeatMissing("isSimple",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr, ((SentenceType_Type) jcasType).casFeatCode_isSimple,
        v);
  }


  // *--------------*
  // * Feature: isCompound

  /**
   * getter for isCompound
   * 
   * @generated
   */
  public boolean getIsCompound() {
    if (SentenceType_Type.featOkTst && ((SentenceType_Type) jcasType).casFeat_isCompound == null) {
      jcasType.jcas.throwFeatMissing("isCompound",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SentenceType_Type) jcasType).casFeatCode_isCompound);
  }

  /**
   * setter for isCompound
   * 
   * @generated
   */
  public void setIsCompound(boolean v) {
    if (SentenceType_Type.featOkTst && ((SentenceType_Type) jcasType).casFeat_isCompound == null) {
      jcasType.jcas.throwFeatMissing("isCompound",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr, ((SentenceType_Type) jcasType).casFeatCode_isCompound,
        v);
  }

  // *--------------*
  // * Feature: isComplex

  /**
   * getter for isComplex
   * 
   * @generated
   */
  public boolean getIsComplex() {
    if (SentenceType_Type.featOkTst && ((SentenceType_Type) jcasType).casFeat_isComplex == null) {
      jcasType.jcas.throwFeatMissing("isComplex",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SentenceType_Type) jcasType).casFeatCode_isComplex);
  }

  /**
   * setter for isComplex
   * 
   * @generated
   */
  public void setIsComplex(boolean v) {
    if (SentenceType_Type.featOkTst && ((SentenceType_Type) jcasType).casFeat_isComplex == null) {
      jcasType.jcas.throwFeatMissing("isComplex",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr, ((SentenceType_Type) jcasType).casFeatCode_isComplex,
        v);
  }

  // *--------------*
  // * Feature: independentClauses

  /**
   * getter for independentClauses
   * 
   * @generated
   * @return value of the feature
   */
  public StringList getIndependentClauses() {
    if (SentenceType_Type.featOkTst
        && ((SentenceType_Type) jcasType).casFeat_independentClauses == null)
      jcasType.jcas.throwFeatMissing("independentClauses",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    return (StringList) (jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefValue(addr,
        ((SentenceType_Type) jcasType).casFeatCode_independentClauses)));
  }

  /**
   * setter for independentClauses
   * 
   * @generated
   * @param v value to set into the feature
   */
  public void setIndependentClauses(StringList v) {
    if (SentenceType_Type.featOkTst
        && ((SentenceType_Type) jcasType).casFeat_independentClauses == null)
      jcasType.jcas.throwFeatMissing("independentClauses",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    jcasType.ll_cas.ll_setRefValue(addr,
        ((SentenceType_Type) jcasType).casFeatCode_independentClauses,
        jcasType.ll_cas.ll_getFSRef(v));
  }

  /* *//**
        * indexed getter for independentClauses
        * 
        * @generated
        */
  /*
   * public String getIndependentClauses(int i) { if (SentenceType_Type.featOkTst &&
   * ((SentenceType_Type)jcasType).casFeat_independentClauses == null)
   * jcasType.jcas.throwFeatMissing("independentClauses",
   * "lu.svv.saa.requirements.autofinding.type.SentenceType");
   * jcasType.jcas.checkArrayBounds(jcasType.ll_cas.ll_getRefValue(addr,
   * ((SentenceType_Type)jcasType).casFeatCode_independentClauses), i); return
   * jcasType.ll_cas.ll_getStringValue(jcasType.ll_cas.ll_getRefValue(addr,
   * ((SentenceType_Type)jcasType).casFeatCode_independentClauses), i);} /** indexed getter for
   * constituents - gets an indexed value - Array of all constituents for this WSDItem.
   * 
   * @generated public LexicalItemConstituent getConstituents(int i) { if (WSDItem_Type.featOkTst &&
   * ((WSDItem_Type)jcasType).casFeat_constituents == null)
   * jcasType.jcas.throwFeatMissing("constituents", "de.tudarmstadt.ukp.dkpro.wsd.type.WSDItem");
   * jcasType.jcas.checkArrayBounds(jcasType.ll_cas.ll_getRefValue(addr,
   * ((WSDItem_Type)jcasType).casFeatCode_constituents), i); return
   * (LexicalItemConstituent)(jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefArrayValue(
   * jcasType.ll_cas.ll_getRefValue(addr, ((WSDItem_Type)jcasType).casFeatCode_constituents), i)));}
   * 
   *//**
      * indexed setter for independentClauses
      * 
      * @generated
      *//*
         * public void setIndependentClauses(int i, String v) { if (SentenceType_Type.featOkTst &&
         * ((SentenceType_Type)jcasType).casFeat_independentClauses == null)
         * jcasType.jcas.throwFeatMissing("independentClauses",
         * "lu.svv.saa.requirements.autofinding.type.SentenceType");
         * jcasType.jcas.checkArrayBounds(jcasType.ll_cas.ll_getRefValue(addr,
         * ((SentenceType_Type)jcasType).casFeatCode_independentClauses), i);
         * jcasType.ll_cas.ll_setRefArrayValue(jcasType.ll_cas.ll_getRefValue(addr,
         * ((SentenceType_Type)jcasType).casFeatCode_independentClauses), i,
         * jcasType.ll_cas.ll_getFSRef(v));}
         */

  // *--------------*
  // * Feature: dependentClauses

  /**
   * getter for independentClauses
   * 
   * @generated
   * @return value of the feature
   */
  public StringList getDependentClauses() {
    if (SentenceType_Type.featOkTst
        && ((SentenceType_Type) jcasType).casFeat_dependentClauses == null)
      jcasType.jcas.throwFeatMissing("dependentClauses",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    return (StringList) (jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefValue(addr,
        ((SentenceType_Type) jcasType).casFeatCode_dependentClauses)));
  }

  /**
   * setter for independentClauses
   * 
   * @generated
   * @param v value to set into the feature
   */
  public void setDependentClauses(StringList v) {
    if (SentenceType_Type.featOkTst
        && ((SentenceType_Type) jcasType).casFeat_dependentClauses == null)
      jcasType.jcas.throwFeatMissing("dependentClauses",
          "lu.svv.saa.requirements.autofinding.type.SentenceType");
    jcasType.ll_cas.ll_setRefValue(addr,
        ((SentenceType_Type) jcasType).casFeatCode_dependentClauses,
        jcasType.ll_cas.ll_getFSRef(v));
  }

}
