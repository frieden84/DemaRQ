/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.annotation;

import static org.apache.uima.fit.util.JCasUtil.select;
import static org.apache.uima.fit.util.JCasUtil.selectCovered;
import org.apache.log4j.Logger;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.jcas.JCas;
import org.springframework.util.StringUtils;
import org.uimafit.component.JCasAnnotator_ImplBase;
import org.uimafit.descriptor.ConfigurationParameter;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import lu.svv.saa.requirements.autofinding.type.DocxSentence;
import lu.svv.saa.requirements.autofinding.type.RequirementStatement;

public class RequirementStatementAnnotator extends JCasAnnotator_ImplBase {

  public static final String PARAM_DEMARCATION = "demarcation";
  @ConfigurationParameter(name = PARAM_DEMARCATION, mandatory = true,
      description = "A boolean if the IDs are well demarcated", defaultValue = "true")
  private boolean demarcation;

  private final Logger logger = Logger.getLogger(getClass());

  @Override
  public void process(JCas jcas) throws AnalysisEngineProcessException {
    int begin, end;
    String coveredText;

    for (DocxSentence txtSegment : select(jcas, DocxSentence.class)) {
      if (selectCovered(Sentence.class, txtSegment).size() == 0
          && txtSegment.getText().trim().length() > 1) {
        begin = txtSegment.getBegin();
        end = txtSegment.getEnd();
        coveredText = txtSegment.getText();
        newRequirementStatement(jcas, begin, end, coveredText);
      } else {
        boolean first = true;
        boolean last = true;
        for (Sentence sentence : selectCovered(Sentence.class, txtSegment)) {
          if (selectCovered(Sentence.class, txtSegment).get(0).getBegin() != txtSegment.getBegin()
              && first) {
            begin = txtSegment.getBegin();
            end = selectCovered(Sentence.class, txtSegment).get(0).getBegin();
            coveredText = txtSegment.getText().substring(begin - txtSegment.getBegin(),
                end - txtSegment.getBegin());
            if (coveredText.trim().length() > 1)
              newRequirementStatement(jcas, begin, end, coveredText);
            first = false;
          }
          if (selectCovered(Sentence.class, txtSegment)
              .get(selectCovered(Sentence.class, txtSegment).size() - 1)
              .getEnd() != txtSegment.getEnd() && last) {
            begin = selectCovered(Sentence.class, txtSegment)
                .get(selectCovered(Sentence.class, txtSegment).size() - 1).getEnd() + 1;
            end = txtSegment.getEnd();
            coveredText = txtSegment.getText().substring(begin - txtSegment.getBegin(),
                end - txtSegment.getBegin());
            if (!coveredText.isEmpty())
              newRequirementStatement(jcas, begin, end, coveredText);
            last = false;
          }
          begin = sentence.getBegin();
          end = sentence.getEnd();
          coveredText = sentence.getCoveredText();
          if (coveredText.trim().length() > 1)
            newRequirementStatement(jcas, begin, end, coveredText);
        }
      }
    }
  }

  private void newRequirementStatement(JCas jcas, int begin, int end, String coveredText) {
    RequirementStatement statementAnnotation = new RequirementStatement(jcas);
    statementAnnotation.setBegin(begin);
    statementAnnotation.setEnd(end);

    String id = (demarcation ? extractId(coveredText) : "");
    String title = extractTitle(coveredText).replace(id, "").trim();
    String text = coveredText.replace(id, "").replace(title, "").trim();

    if (text.startsWith(":")) {
      text = text.substring(1).trim();
    }

    statementAnnotation.setId(id);
    statementAnnotation.setIdBegin(statementAnnotation.getId().isEmpty() ? -1 : begin);
    statementAnnotation.setIdEnd(statementAnnotation.getId().isEmpty() ? -1 : begin + id.length());

    statementAnnotation.setTitle(title);
    statementAnnotation
        .setTitleBegin(title.isEmpty() ? -1 : statementAnnotation.getIdEnd() + 1 + begin);
    statementAnnotation
        .setTitleEnd(title.isEmpty() ? -1 : statementAnnotation.getTitleBegin() + title.length());

    statementAnnotation.setText(text);
    statementAnnotation.setTextBegin(end - text.length());
    statementAnnotation.setTextEnd(end);

    statementAnnotation.addToIndexes();
  }

  private String extractId(String text) {
    String firstToken = text.trim().split(" ")[0];

    if (firstToken.length() < 2) {
      return "";
    }
    char[] chars = firstToken.toCharArray();
    boolean isAlphabetic = false;
    boolean isNumeric = false;
    boolean hasSpecialCharacters = false;
    for (char c : chars) {
      if (Character.isDigit(c)) {
        isNumeric = true;
      } else if (Character.isLetter(c)) {
        isAlphabetic = true;
      } else if (!Character.isLetter(c) && !Character.isDigit(c)) {
        hasSpecialCharacters = true;
      }
    }
    if ((isAlphabetic && !isNumeric && !hasSpecialCharacters) && firstToken.endsWith(":")) {
      return "";
    }
    if (isAlphabetic && isNumeric) {
      return firstToken;
    }
    if (hasSpecialCharacters && (isAlphabetic || isNumeric) && !firstToken.endsWith(":")) {
      return firstToken;
    }
    return "";
  }

  /***** DOCUMENT DEPENDENT *****/
  private String extractTitle(String text) {
    int index = text.indexOf(":");
    if (StringUtils.countOccurrencesOf(text, ":") > 2 || index == -1) {
      return "";
    }
    // index is in the next half of the sentence
    if (index >= (double) text.length() / 2) {
      return "";
    }
    // Title includes many words
    if (text.substring(0, index).split(" ").length > 4) {
      return "";
    }
    return (text.substring(0, index));
  }

  @Override
  public void collectionProcessComplete() {
    String message = String.format("%s has been processed successfully ..",
        "Splitting Requirements");
    this.logger.info(message);
  }

}


