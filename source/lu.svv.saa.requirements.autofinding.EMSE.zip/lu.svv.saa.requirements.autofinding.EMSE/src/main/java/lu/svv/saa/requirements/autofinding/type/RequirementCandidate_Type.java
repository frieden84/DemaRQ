package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.cas.Feature;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.tcas.Annotation_Type;


public class RequirementCandidate_Type extends Annotation_Type {
  /** @generated */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  protected FSGenerator getFSGenerator() {
    return fsGenerator;
  }

  /** @generated */
  @SuppressWarnings("rawtypes")
  private final FSGenerator fsGenerator = new FSGenerator() {
    public FeatureStructure createFS(int addr, CASImpl cas) {
      if (RequirementCandidate_Type.this.useExistingInstance) {
        // Return eq fs instance if already created
        FeatureStructure fs = RequirementCandidate_Type.this.jcas.getJfsFromCaddr(addr);
        if (null == fs) {
          fs = new RequirementCandidate(addr, RequirementCandidate_Type.this);
          RequirementCandidate_Type.this.jcas.putJfsFromCaddr(addr, fs);
          return fs;
        }
        return fs;
      } else {
        return new RequirementCandidate(addr, RequirementCandidate_Type.this);
      }
    }
  };
  /** @generated */
  public final static int typeIndexID = RequirementCandidate.typeIndexID;
  /**
   * @generated
   * @modifiable
   */
  public final static boolean featOkTst =
      JCasRegistry.getFeatOkTst("lu.svv.saa.requirements.autofinding.type.RequirementCandidate");

  /**** Feature: ID ***/
  /** @generated */
  final Feature casFeat_ID;
  /** @generated */
  final int casFeatCode_ID;

  /** @generated */
  public String getID(int addr) {
    if (featOkTst && casFeat_ID == null) {
      jcas.throwFeatMissing("ID", "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_ID);
  }

  /** @generated */
  public void setID(int addr, String v) {
    if (featOkTst && casFeat_ID == null) {
      jcas.throwFeatMissing("ID", "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_ID, v);
  }

  /**** Feature: requirement ****/

  /** @generated */
  final Feature casFeat_requirement;
  /** @generated */
  final int casFeatCode_requirement;

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @return the feature value
   */
  public int getRequirement(int addr) {
    if (featOkTst && casFeat_requirement == null)
      jcas.throwFeatMissing("requirement",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    return ll_cas.ll_getRefValue(addr, casFeatCode_requirement);
  }

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @param v value to set
   */
  public void setRequirement(int addr, int v) {
    if (featOkTst && casFeat_requirement == null)
      jcas.throwFeatMissing("requirement",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    ll_cas.ll_setRefValue(addr, casFeatCode_requirement, v);
  }

  /**** Feature: lexFeatures ****/

  /** @generated */
  final Feature casFeat_lexFeatures;
  /** @generated */
  final int casFeatCode_lexFeatures;

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @return the feature value
   */
  public int getLexFeatures(int addr) {
    if (featOkTst && casFeat_lexFeatures == null)
      jcas.throwFeatMissing("lexFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    return ll_cas.ll_getRefValue(addr, casFeatCode_lexFeatures);
  }

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @param v value to set
   */
  public void setLexFeatures(int addr, int v) {
    if (featOkTst && casFeat_lexFeatures == null)
      jcas.throwFeatMissing("lexFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    ll_cas.ll_setRefValue(addr, casFeatCode_lexFeatures, v);
  }

  /**** Feature: synFeatures ****/

  /** @generated */
  final Feature casFeat_synFeatures;
  /** @generated */
  final int casFeatCode_synFeatures;

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @return the feature value
   */
  public int getSynFeatures(int addr) {
    if (featOkTst && casFeat_synFeatures == null)
      jcas.throwFeatMissing("synFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    return ll_cas.ll_getRefValue(addr, casFeatCode_synFeatures);
  }

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @param v value to set
   */
  public void setSynFeatures(int addr, int v) {
    if (featOkTst && casFeat_synFeatures == null)
      jcas.throwFeatMissing("synFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    ll_cas.ll_setRefValue(addr, casFeatCode_synFeatures, v);
  }

  /**** Feature: semFeatures ****/

  /** @generated */
  final Feature casFeat_semFeatures;
  /** @generated */
  final int casFeatCode_semFeatures;

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @return the feature value
   */
  public int getSemFeatures(int addr) {
    if (featOkTst && casFeat_semFeatures == null)
      jcas.throwFeatMissing("semFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    return ll_cas.ll_getRefValue(addr, casFeatCode_semFeatures);
  }

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @param v value to set
   */
  public void setSemFeatures(int addr, int v) {
    if (featOkTst && casFeat_semFeatures == null)
      jcas.throwFeatMissing("semFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    ll_cas.ll_setRefValue(addr, casFeatCode_semFeatures, v);
  }

  /**** Feature: discourseFeatures ****/

  /** @generated */
  final Feature casFeat_discourseFeatures;
  /** @generated */
  final int casFeatCode_discourseFeatures;

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @return the feature value
   */
  public int getDiscourseFeatures(int addr) {
    if (featOkTst && casFeat_discourseFeatures == null)
      jcas.throwFeatMissing("discourseFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    return ll_cas.ll_getRefValue(addr, casFeatCode_discourseFeatures);
  }

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @param v value to set
   */
  public void setDiscourseFeatures(int addr, int v) {
    if (featOkTst && casFeat_discourseFeatures == null)
      jcas.throwFeatMissing("discourseFeatures",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    ll_cas.ll_setRefValue(addr, casFeatCode_discourseFeatures, v);
  }

  /**** Feature: isRequirement ***/
  /** @generated */
  final Feature casFeat_isRequirement;
  /** @generated */
  final int casFeatCode_isRequirement;

  /** @generated */
  public boolean isRequirement(int addr) {
    if (featOkTst && casFeat_isRequirement == null) {
      jcas.throwFeatMissing("isRequirement",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_isRequirement);
  }

  /** @generated */
  public void setIsRequirement(int addr, boolean v) {
    if (featOkTst && casFeat_isRequirement == null) {
      jcas.throwFeatMissing("isRequirement",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_isRequirement, v);
  }

  /**** Feature: confidence ***/
  /** @generated */
  final Feature casFeat_confidence;
  /** @generated */
  final int casFeatCode_confidence;

  /** @generated */
  public double getConfidence(int addr) {
    if (featOkTst && casFeat_confidence == null) {
      jcas.throwFeatMissing("confidence",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    }
    return ll_cas.ll_getDoubleValue(addr, casFeatCode_confidence);
  }

  /** @generated */
  public void setConfidence(int addr, double v) {
    if (featOkTst && casFeat_confidence == null) {
      jcas.throwFeatMissing("confidence",
          "lu.svv.saa.requirements.autofinding.type.RequirementCandidate");
    }
    ll_cas.ll_setDoubleValue(addr, casFeatCode_confidence, v);
  }


  /**
   * initialize variables to correspond with Cas Type and Features
   * 
   * @generated
   */
  public RequirementCandidate_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl) this.casType, getFSGenerator());

    casFeat_ID = jcas.getRequiredFeatureDE(casType, "ID", "uima.cas.String", featOkTst);
    casFeatCode_ID =
        (null == casFeat_ID) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl) casFeat_ID).getCode();

    casFeat_requirement = jcas.getRequiredFeatureDE(casType, "requirement",
        "lu.svv.saa.requirements.autofinding.type.RequirementStatement", featOkTst);
    casFeatCode_requirement = (null == casFeat_requirement) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_requirement).getCode();

    casFeat_lexFeatures = jcas.getRequiredFeatureDE(casType, "lexFeatures",
        "lu.svv.saa.requirements.autofinding.type.LexicalFeatures", featOkTst);
    casFeatCode_lexFeatures = (null == casFeat_lexFeatures) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_lexFeatures).getCode();

    casFeat_synFeatures = jcas.getRequiredFeatureDE(casType, "synFeatures",
        "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures", featOkTst);
    casFeatCode_synFeatures = (null == casFeat_synFeatures) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_synFeatures).getCode();

    casFeat_semFeatures = jcas.getRequiredFeatureDE(casType, "semFeatures",
        "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures", featOkTst);
    casFeatCode_semFeatures = (null == casFeat_semFeatures) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_semFeatures).getCode();

    casFeat_discourseFeatures = jcas.getRequiredFeatureDE(casType, "discourseFeatures",
        "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures", featOkTst);
    casFeatCode_discourseFeatures = (null == casFeat_discourseFeatures) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_discourseFeatures).getCode();

    casFeat_isRequirement =
        jcas.getRequiredFeatureDE(casType, "isRequirement", "uima.cas.Boolean", featOkTst);
    casFeatCode_isRequirement = (null == casFeat_isRequirement) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_isRequirement).getCode();

    casFeat_confidence =
        jcas.getRequiredFeatureDE(casType, "confidence", "uima.cas.Double", featOkTst);
    casFeatCode_confidence = (null == casFeat_confidence) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_confidence).getCode();

  }

}
