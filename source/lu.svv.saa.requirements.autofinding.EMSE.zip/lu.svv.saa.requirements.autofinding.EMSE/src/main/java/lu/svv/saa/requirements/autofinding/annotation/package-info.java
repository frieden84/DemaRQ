/**
 * Feature extractors on different linguistics layers for each sentence
 */
/**
 * @author <a href="mailto:sallam.abualhaija@uni.lu">Sallam Abualhaija</a> 
 *
 */
package lu.svv.saa.requirements.autofinding.annotation;
