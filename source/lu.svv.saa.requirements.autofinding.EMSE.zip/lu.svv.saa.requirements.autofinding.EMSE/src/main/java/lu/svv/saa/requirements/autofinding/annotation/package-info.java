/**
 * Feature extractors on different linguistics layers for each sentence
 */
/**
 * @author sallam.abualhaija
 *
 */
package lu.svv.saa.requirements.autofinding.annotation;
