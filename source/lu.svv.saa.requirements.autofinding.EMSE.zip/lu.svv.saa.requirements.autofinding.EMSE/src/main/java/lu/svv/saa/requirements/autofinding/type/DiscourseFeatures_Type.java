/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.cas.Feature;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.tcas.Annotation_Type;

public class DiscourseFeatures_Type extends Annotation_Type {
  /** @generated */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  protected FSGenerator getFSGenerator() {
    return fsGenerator;
  }

  /** @generated */
  @SuppressWarnings("rawtypes")
  private final FSGenerator fsGenerator = new FSGenerator() {
    public FeatureStructure createFS(int addr, CASImpl cas) {
      if (DiscourseFeatures_Type.this.useExistingInstance) {
        // Return eq fs instance if already created
        FeatureStructure fs = DiscourseFeatures_Type.this.jcas.getJfsFromCaddr(addr);
        if (null == fs) {
          fs = new DiscourseFeatures(addr, DiscourseFeatures_Type.this);
          DiscourseFeatures_Type.this.jcas.putJfsFromCaddr(addr, fs);
          return fs;
        }
        return fs;
      } else {
        return new DiscourseFeatures(addr, DiscourseFeatures_Type.this);
      }
    }
  };
  /** @generated */
  public final static int typeIndexID = DiscourseFeatures.typeIndexID;
  /**
   * @generated
   * @modifiable
   */
  public final static boolean featOkTst =
      JCasRegistry.getFeatOkTst("lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");

  /**** Feature: matchesMFFontName ****/
  /** @generated */
  final Feature casFeat_matchesMFFontName;
  /** @generated */
  final int casFeatCode_matchesMFFontName;

  /** @generated */
  public boolean matchesMFFontName(int addr) {
    if (featOkTst && casFeat_matchesMFFontName == null) {
      jcas.throwFeatMissing("matchesMFFontName",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_matchesMFFontName);
  }

  /** @generated */
  public void setMatchesMFFontName(int addr, boolean v) {
    if (featOkTst && casFeat_matchesMFFontName == null) {
      jcas.throwFeatMissing("matchesMFFontName",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_matchesMFFontName, v);
  }

  /**** Feature: matchesMFFontSize ****/
  /** @generated */
  final Feature casFeat_matchesMFFontSize;
  /** @generated */
  final int casFeatCode_matchesMFFontSize;

  /** @generated */
  public boolean matchesMFFontSize(int addr) {
    if (featOkTst && casFeat_matchesMFFontSize == null) {
      jcas.throwFeatMissing("matchesMFFontSize",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_matchesMFFontSize);
  }

  /** @generated */
  public void setMatchesMFFontSize(int addr, boolean v) {
    if (featOkTst && casFeat_matchesMFFontSize == null) {
      jcas.throwFeatMissing("matchesMFFontSize",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_matchesMFFontSize, v);
  }

  /**** Feature: matchesMFFontItalic ****/
  /** @generated */
  final Feature casFeat_matchesMFFontItalic;
  /** @generated */
  final int casFeatCode_matchesMFFontItalic;

  /** @generated */
  public boolean matchesMFFontItalic(int addr) {
    if (featOkTst && casFeat_matchesMFFontItalic == null) {
      jcas.throwFeatMissing("matchesMFFontItalic",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_matchesMFFontItalic);
  }

  /** @generated */
  public void setMatchesMFFontItalic(int addr, boolean v) {
    if (featOkTst && casFeat_matchesMFFontItalic == null) {
      jcas.throwFeatMissing("matchesMFFontItalic",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_matchesMFFontItalic, v);
  }

  /**** Feature: matchesMFFontBold ****/
  /** @generated */
  final Feature casFeat_matchesMFFontBold;
  /** @generated */
  final int casFeatCode_matchesMFFontBold;

  /** @generated */
  public boolean matchesMFFontBold(int addr) {
    if (featOkTst && casFeat_matchesMFFontBold == null) {
      jcas.throwFeatMissing("matchesMFFontBold",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_matchesMFFontBold);
  }

  /** @generated */
  public void setMatchesMFFontBold(int addr, boolean v) {
    if (featOkTst && casFeat_matchesMFFontBold == null) {
      jcas.throwFeatMissing("matchesMFFontBold",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_matchesMFFontBold, v);
  }

  /**** Feature: pctMFNP ****/
  /** @generated */
  final Feature casFeat_pctMFNP;
  /** @generated */
  final int casFeatCode_pctMFNP;

  /** @generated */
  public double getPctMFNP(int addr) {
    if (featOkTst && casFeat_pctMFNP == null) {
      jcas.throwFeatMissing("pctMFNP",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return ll_cas.ll_getDoubleValue(addr, casFeatCode_pctMFNP);
  }

  /** @generated */
  public void setPctMFNP(int addr, double v) {
    if (featOkTst && casFeat_pctMFNP == null) {
      jcas.throwFeatMissing("pctMFNP",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    ll_cas.ll_setDoubleValue(addr, casFeatCode_pctMFNP, v);
  }

  /**** Feature: idPatternFrequency ****/
  /** @generated */
  final Feature casFeat_idPatternFrequency;
  /** @generated */
  final int casFeatCode_idPatternFrequency;

  /** @generated */
  public String getIdPatternFrequency(int addr) {
    if (featOkTst && casFeat_idPatternFrequency == null) {
      jcas.throwFeatMissing("idPatternFrequency",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_idPatternFrequency);
  }

  /** @generated */
  public void setIdPatternFrequency(int addr, String v) {
    if (featOkTst && casFeat_idPatternFrequency == null) {
      jcas.throwFeatMissing("idPatternFrequency",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_idPatternFrequency, v);
  }

  /**** Feature: hasMFModal ****/
  /** @generated */
  final Feature casFeat_hasMFModal;
  /** @generated */
  final int casFeatCode_hasMFModal;

  /** @generated */
  public boolean hasMFModal(int addr) {
    if (featOkTst && casFeat_hasMFModal == null) {
      jcas.throwFeatMissing("hasMFModal",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_hasMFModal);
  }

  /** @generated */
  public void setHasMFModal(int addr, boolean v) {
    if (featOkTst && casFeat_hasMFModal == null) {
      jcas.throwFeatMissing("hasMFModal",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_hasMFModal, v);
  }

  /**** Feature: hasMFNP ****/
  /** @generated */
  final Feature casFeat_hasMFNP;
  /** @generated */
  final int casFeatCode_hasMFNP;

  /** @generated */
  public boolean hasMFNP(int addr) {
    if (featOkTst && casFeat_hasMFNP == null) {
      jcas.throwFeatMissing("hasMFNP",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_hasMFNP);
  }

  /** @generated */
  public void setHasMFNP(int addr, boolean v) {
    if (featOkTst && casFeat_hasMFNP == null) {
      jcas.throwFeatMissing("hasMFNP",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_hasMFNP, v);
  }

  /**** Feature: matchesMFCategory ****/
  /** @generated */
  final Feature casFeat_matchesMFCategory;
  /** @generated */
  final int casFeatCode_matchesMFCategory;

  /** @generated */
  public boolean matchesMFCategory(int addr) {
    if (featOkTst && casFeat_matchesMFCategory == null) {
      jcas.throwFeatMissing("matchesMFCategory",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_matchesMFCategory);
  }

  /** @generated */
  public void setMatchesMFCategory(int addr, boolean v) {
    if (featOkTst && casFeat_matchesMFCategory == null) {
      jcas.throwFeatMissing("matchesMFCategory",
          "lu.svv.saa.requirements.autofinding.type.DiscourseFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_matchesMFCategory, v);
  }

  /**
   * initialize variables to correspond with Cas Type and Features
   * 
   * @generated
   */
  public DiscourseFeatures_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl) this.casType, getFSGenerator());

    casFeat_matchesMFFontName =
        jcas.getRequiredFeatureDE(casType, "matchesMFFontName", "uima.cas.Boolean", featOkTst);
    casFeatCode_matchesMFFontName = (null == casFeat_matchesMFFontName) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_matchesMFFontName).getCode();

    casFeat_matchesMFFontSize =
        jcas.getRequiredFeatureDE(casType, "matchesMFFontSize", "uima.cas.Boolean", featOkTst);
    casFeatCode_matchesMFFontSize = (null == casFeat_matchesMFFontSize) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_matchesMFFontSize).getCode();

    casFeat_matchesMFFontItalic =
        jcas.getRequiredFeatureDE(casType, "matchesMFFontItalic", "uima.cas.Boolean", featOkTst);
    casFeatCode_matchesMFFontItalic =
        (null == casFeat_matchesMFFontItalic) ? JCas.INVALID_FEATURE_CODE
            : ((FeatureImpl) casFeat_matchesMFFontItalic).getCode();

    casFeat_matchesMFFontBold =
        jcas.getRequiredFeatureDE(casType, "matchesMFFontBold", "uima.cas.Boolean", featOkTst);
    casFeatCode_matchesMFFontBold = (null == casFeat_matchesMFFontBold) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_matchesMFFontBold).getCode();

    casFeat_pctMFNP = jcas.getRequiredFeatureDE(casType, "pctMFNP", "uima.cas.Double", featOkTst);
    casFeatCode_pctMFNP = (null == casFeat_pctMFNP) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_pctMFNP).getCode();

    casFeat_idPatternFrequency =
        jcas.getRequiredFeatureDE(casType, "idPatternFrequency", "uima.cas.String", featOkTst);
    casFeatCode_idPatternFrequency =
        (null == casFeat_idPatternFrequency) ? JCas.INVALID_FEATURE_CODE
            : ((FeatureImpl) casFeat_idPatternFrequency).getCode();

    casFeat_hasMFModal =
        jcas.getRequiredFeatureDE(casType, "hasMFModal", "uima.cas.Boolean", featOkTst);
    casFeatCode_hasMFModal = (null == casFeat_hasMFModal) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_hasMFModal).getCode();

    casFeat_hasMFNP = jcas.getRequiredFeatureDE(casType, "hasMFNP", "uima.cas.Boolean", featOkTst);
    casFeatCode_hasMFNP = (null == casFeat_hasMFNP) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_hasMFNP).getCode();

    casFeat_matchesMFCategory =
        jcas.getRequiredFeatureDE(casType, "matchesMFCategory", "uima.cas.Boolean", featOkTst);
    casFeatCode_matchesMFCategory = (null == casFeat_matchesMFCategory) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_matchesMFCategory).getCode();

  }

}
