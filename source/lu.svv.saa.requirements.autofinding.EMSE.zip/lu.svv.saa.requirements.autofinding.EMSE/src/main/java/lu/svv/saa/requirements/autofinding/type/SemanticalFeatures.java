/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;
import org.apache.uima.jcas.tcas.Annotation;

public class SemanticalFeatures extends Annotation {
  /**
   * @generated
   * @ordered
   */
  public final static int typeIndexID = JCasRegistry.register(SemanticalFeatures.class);
  /**
   * @generated
   * @ordered
   */
  public final static int type = typeIndexID;

  /** @generated */
  @Override
  public int getTypeIndexID() {
    return typeIndexID;
  }

  /**
   * Never called. Disable default constructor
   * 
   * @generated
   */
  public SemanticalFeatures() {}

  /**
   * Internal - constructor used by generator
   * 
   * @generated
   */
  public SemanticalFeatures(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  /** @generated */
  public SemanticalFeatures(JCas jCas) {
    super(jCas);
    readObject();
  }

  /** @generated */
  public SemanticalFeatures(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  /**
   * <!-- begin-user-doc --> Write your own initialization here <!-- end-user-doc -->
   * 
   * @generated modifiable
   */
  private void readObject() {}

  // *--------------*
  // * Feature: isExplanation

  /**
   * getter for isExplanation
   * 
   * @generated
   */
  public boolean isExplanation() {
    if (SemanticalFeatures_Type.featOkTst
        && ((SemanticalFeatures_Type) jcasType).casFeat_isExplanation == null) {
      jcasType.jcas.throwFeatMissing("isExplanation",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SemanticalFeatures_Type) jcasType).casFeatCode_isExplanation);
  }

  /**
   * setter for hasVerb
   * 
   * @generated
   */
  public void setIsExplanation(boolean v) {
    if (SemanticalFeatures_Type.featOkTst
        && ((SemanticalFeatures_Type) jcasType).casFeat_isExplanation == null) {
      jcasType.jcas.throwFeatMissing("isExplanation",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SemanticalFeatures_Type) jcasType).casFeatCode_isExplanation, v);
  }

  // *--------------*
  // * Feature: expressesProbability

  /**
   * getter for expressesProbability
   * 
   * @generated
   */
  public boolean expressesProbability() {
    if (SemanticalFeatures_Type.featOkTst
        && ((SemanticalFeatures_Type) jcasType).casFeat_expressesProbability == null) {
      jcasType.jcas.throwFeatMissing("expressesProbability",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SemanticalFeatures_Type) jcasType).casFeatCode_expressesProbability);
  }

  /**
   * setter for hasVerb
   * 
   * @generated
   */
  public void setExpressesProbability(boolean v) {
    if (SemanticalFeatures_Type.featOkTst
        && ((SemanticalFeatures_Type) jcasType).casFeat_expressesProbability == null) {
      jcasType.jcas.throwFeatMissing("expressesProbability",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SemanticalFeatures_Type) jcasType).casFeatCode_expressesProbability, v);
  }

  // *--------------*
  // * Feature: hasActionVerb

  /**
   * getter for hasActionVerb
   * 
   * @generated
   */
  public boolean hasActionVerb() {
    if (SemanticalFeatures_Type.featOkTst
        && ((SemanticalFeatures_Type) jcasType).casFeat_hasActionVerb == null) {
      jcasType.jcas.throwFeatMissing("hasActionVerb",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SemanticalFeatures_Type) jcasType).casFeatCode_hasActionVerb);
  }

  /**
   * setter for hasVerb
   * 
   * @generated
   */
  public void setHasActionVerb(boolean v) {
    if (SemanticalFeatures_Type.featOkTst
        && ((SemanticalFeatures_Type) jcasType).casFeat_hasActionVerb == null) {
      jcasType.jcas.throwFeatMissing("hasActionVerb",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SemanticalFeatures_Type) jcasType).casFeatCode_hasActionVerb, v);
  }

  // *--------------*
  // * Feature: hasStativeVerb

  /**
   * getter for hasStativeVerb
   * 
   * @generated
   */
  public boolean hasStativeVerb() {
    if (SemanticalFeatures_Type.featOkTst
        && ((SemanticalFeatures_Type) jcasType).casFeat_hasStativeVerb == null) {
      jcasType.jcas.throwFeatMissing("hasStativeVerb",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    return jcasType.ll_cas.ll_getBooleanValue(addr,
        ((SemanticalFeatures_Type) jcasType).casFeatCode_hasStativeVerb);
  }

  /**
   * setter for hasVerb
   * 
   * @generated
   */
  public void setHasStativeVerb(boolean v) {
    if (SemanticalFeatures_Type.featOkTst
        && ((SemanticalFeatures_Type) jcasType).casFeat_hasStativeVerb == null) {
      jcasType.jcas.throwFeatMissing("hasStativeVerb",
          "lu.svv.saa.requirements.autofinding.type.SemanticalFeatures");
    }
    jcasType.ll_cas.ll_setBooleanValue(addr,
        ((SemanticalFeatures_Type) jcasType).casFeatCode_hasStativeVerb, v);
  }

}
