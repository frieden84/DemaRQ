/**
 * Defining the different types to be used throughout the pipeline by just looping over them
 */
/**
 * @author sallam.abualhaija
 *
 */
package lu.svv.saa.requirements.autofinding.type;
