/**
 * Defining the different types to be used throughout the pipeline by just looping over them
 */
/**
 * @author <a href="mailto:sallam.abualhaija@uni.lu">Sallam Abualhaija</a> 
 *
 */
package lu.svv.saa.requirements.autofinding.type;
