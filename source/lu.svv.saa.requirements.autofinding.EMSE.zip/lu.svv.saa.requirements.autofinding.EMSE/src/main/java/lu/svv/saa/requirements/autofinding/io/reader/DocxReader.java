/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.io.reader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.uima.UimaContext;
import org.apache.uima.collection.CollectionException;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Progress;
import org.apache.uima.util.ProgressImpl;
import org.uimafit.component.JCasCollectionReader_ImplBase;
import org.uimafit.descriptor.ConfigurationParameter;
import com.aspose.words.Document;
import com.aspose.words.License;
import com.aspose.words.Node;
import com.aspose.words.NodeCollection;
import com.aspose.words.NodeType;
import com.aspose.words.Paragraph;
import com.aspose.words.Row;
import com.aspose.words.Run;
import com.aspose.words.Section;
import com.aspose.words.Table;
import de.tudarmstadt.ukp.dkpro.core.api.metadata.type.DocumentMetaData;
import lu.svv.saa.requirements.autofinding.type.DocxSentence;
import lu.svv.saa.requirements.autofinding.type.WordDocFeatures;
import lu.svv.saa.requirements.autofinding.util.ReaderHelper;

public class DocxReader extends JCasCollectionReader_ImplBase {

  public static final String PARAM_INPUT_PATH = "inputPath";
  @ConfigurationParameter(name = PARAM_INPUT_PATH, mandatory = true,
      description = "Input path for dataset")
  private String inputPath;

  public static final String PARAM_LICENSE_PATH = "licensePath";
  @ConfigurationParameter(name = PARAM_LICENSE_PATH, mandatory = true,
      description = "license Path")
  private String licensePath;

  public static final String PARAM_ITALIC_RATIO = "italicRatio";
  @ConfigurationParameter(name = PARAM_ITALIC_RATIO, mandatory = true,
      description = "ratio of italics per Run to decide on italic feature for text segment",
      defaultValue = "0.75")
  private double italicRatio;

  public static final String PARAM_BOLD_RATIO = "BoldRatio";
  @ConfigurationParameter(name = PARAM_BOLD_RATIO, mandatory = true,
      description = "ratio of bolds per Run to decide on bold feature for text segment",
      defaultValue = "0.75")
  private double boldRatio;

  private Document docx;
  private StringBuilder documentText;
  private int counter;
  private Map<String, Integer> defaultFontName;
  private Map<Integer, Integer> defaultFontSize;
  private ReaderHelper helper = new ReaderHelper();
  private Logger logger;

  @Override
  public void initialize(final UimaContext context) throws ResourceInitializationException {
    super.initialize(context);
    this.logger = Logger.getLogger(getClass());
    BasicConfigurator.configure();

    // Apply the license
    License license = new License();
    try {
      license.setLicense(licensePath + "/Aspose.Words.lic");
    } catch (Exception e1) {
      e1.printStackTrace();
    }
    try {
      this.docx = new Document(inputPath);
    } catch (Exception e) {
      e.printStackTrace();
    }
    if (this.docx == null)
      throw new ResourceInitializationException(
          new IOException("Word document in " + this.inputPath + " could not be parsed!"));

    this.logger.info("Reading \"" + FilenameUtils.getName(docx.getOriginalFileName()) + "\"");
    this.counter = 0;
    this.documentText = new StringBuilder();
    this.defaultFontName = new HashMap<String, Integer>();
    this.defaultFontSize = new HashMap<Integer, Integer>();
  }

  @SuppressWarnings({"static-access", "unchecked", "rawtypes"})
  @Override
  public void getNext(JCas jCas) throws IOException, CollectionException {
    List<DocxSentence> textSegments = new ArrayList<DocxSentence>();
    int offset = 0;
    for (Section section : docx.getSections()) {
      NodeCollection children = section.getBody().getChildNodes();
      for (Node child : (Iterable<Node>) children) {
        String text = "";
        if (child.nodeTypeToString(child.getNodeType()).equalsIgnoreCase("paragraph")) {
          Paragraph paragraph = (Paragraph) child;
          WordDocFeatures formatting = newWordDocFeatures(jCas, paragraph, offset);
          text = paragraph.getText().replaceAll("\\s+", " ").trim();

          String numbering = helper.extractNumbering(paragraph);
          if (!numbering.isEmpty())
            text = helper.changeNumbering(numbering + " " + text);
          else
            text = helper.changeNumbering(text);

          if (!text.trim().isEmpty()) {
            DocxSentence extractParagraph = new DocxSentence(jCas);
            extractParagraph.setBegin(offset);
            extractParagraph.setEnd(offset + text.length());
            extractParagraph.setText(text);
            extractParagraph
                .setElementType(child.nodeTypeToString(child.getNodeType()).toUpperCase());
            extractParagraph.setFontName(formatting.getFontName());
            extractParagraph.setFontSize(formatting.getFontSize());
            extractParagraph.setIsItalic(formatting.getIsItalic());
            extractParagraph.setIsBold(formatting.getIsBold());

            textSegments.add(extractParagraph);
            documentText.append(text + " ");
            offset += text.length() + 1;
          }
        } else if (child.nodeTypeToString(child.getNodeType()).equalsIgnoreCase("table")) {
          Table table = (Table) child;
          for (Row row : table.getRows()) {
            text = "";
            NodeCollection rowParagraphs = row.getChildNodes(NodeType.PARAGRAPH, true);
            WordDocFeatures formatting =
                newWordDocFeatures(jCas, (Paragraph) rowParagraphs.get(0), offset);
            for (Paragraph paragraph : (Iterable<Paragraph>) rowParagraphs) {
              text +=
                  helper.changeNumbering(paragraph.getText().replaceAll("\\s+", " ").trim()) + " ";
            }
            if (!text.trim().isEmpty()) {
              DocxSentence extractTable = new DocxSentence(jCas);
              extractTable.setBegin(offset);
              extractTable.setEnd(offset + text.length());
              extractTable.setText(text);
              extractTable
                  .setElementType(child.nodeTypeToString(child.getNodeType()).toUpperCase());
              extractTable.setFontName(formatting.getFontName());
              extractTable.setFontSize(formatting.getFontSize());
              extractTable.setIsItalic(formatting.getIsItalic());
              extractTable.setIsBold(formatting.getIsBold());

              textSegments.add(extractTable);
              documentText.append(text + " ");
              offset += text.length() + 1;
            }
          }
        }
      }
      ++counter;
    }

    for (DocxSentence s : textSegments) {

      if (s.getFontName() == null)
        s.setFontName(helper.getMFName(defaultFontName));
      if (s.getFontSize() == -1)
        s.setFontSize(helper.getMFSize(defaultFontSize));
      s.addToIndexes();
    }
    setDocumentMetadata(jCas, documentText.toString());
  }

  public int getNumTables() {
    return this.docx.getChildNodes(NodeType.TABLE, true).getCount();
  }

  public int getNumPictures() {
    return this.docx.getChildNodes(NodeType.SHAPE, true).getCount();
  }

  @Override
  public void close() throws IOException {
    // nop
  }

  public boolean hasNext() throws IOException, CollectionException {
    return counter < docx.getSections().getCount();
  }

  public Progress[] getProgress() {
    return new Progress[] {new ProgressImpl(counter,
        docx.getChildNodes(NodeType.PARAGRAPH, true).getCount(), "text segments")};
  }

  /**
   * Sets the metadata of the current document.
   *
   * @param jCas
   * @throws CollectionException
   */
  private void setDocumentMetadata(JCas jCas, String text) throws CollectionException {
    DocumentMetaData d = DocumentMetaData.create(jCas);
    String language = "en";
    String docName =
        docx.getOriginalFileName().substring(docx.getOriginalFileName().lastIndexOf("/"));
    String title = docName.substring(1, docName.indexOf("."));

    d.setDocumentTitle(title);
    d.addToIndexes();

    jCas.setDocumentLanguage(language);
    jCas.setDocumentText(text);
  }

  /*** Extract metadata from word doc paragraphs *****/
  private WordDocFeatures newWordDocFeatures(JCas jcas, Paragraph paragraph, int offset) {
    WordDocFeatures formatting = new WordDocFeatures(jcas);
    String paraText = paragraph.getText().replaceAll("\\s+", " ").trim();
    String fontName = "";
    int fontSize = -1;
    int italics = 0;
    int bolds = 0;
    for (int index = 0; index < paragraph.getRuns().getCount(); ++index) {
      Run run = paragraph.getRuns().get(index);
      fontName = run.getFont().getName();
      if (fontName != null) {
        if (defaultFontName.isEmpty() || !defaultFontName.containsKey(fontName)) {
          defaultFontName.put(fontName, 1);
        } else {
          defaultFontName.put(fontName, defaultFontName.get(fontName) + 1);
        }
      }
      fontSize = (int) run.getFont().getSize();
      if (fontSize != -1) {
        if (defaultFontSize.isEmpty() || !defaultFontSize.containsKey(fontSize)) {
          defaultFontSize.put(fontSize, 1);
        } else {
          defaultFontSize.put(fontSize, defaultFontSize.get(fontSize) + 1);
        }
      }
      if (run.getFont().getItalic()) {
        italics++;
      }
      if (run.getFont().getBold()) {
        bolds++;
      }
    }
    formatting.setBegin(offset);
    formatting.setEnd(offset + paraText.length() + 1);
    formatting.setFontName(fontName);
    formatting.setFontSize(fontSize);
    formatting.setIsItalic(
        (double) italics / paragraph.getRuns().getCount() > italicRatio ? true : false);
    formatting
        .setIsBold((double) bolds / paragraph.getRuns().getCount() > boldRatio ? true : false);
    return formatting;
  }

}
