/*
 * Copyright 2020
 * Software Validation and Verification (SVV) Lab
 * Interdisciplinary Centre for Security, Reliability and Trust (SnT)
 * University of Luxembourg
 *
 */
package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;
import org.apache.uima.jcas.tcas.Annotation;

public class IdPatternMetadata extends Annotation {
  /**
   * @generated
   * @ordered
   */
  public final static int typeIndexID = JCasRegistry.register(IdPatternMetadata.class);
  /**
   * @generated
   * @ordered
   */
  public final static int type = typeIndexID;

  /** @generated */
  @Override
  public int getTypeIndexID() {
    return typeIndexID;
  }

  /**
   * Never called. Disable default constructor
   * 
   * @generated
   */
  public IdPatternMetadata() {}

  /**
   * Internal - constructor used by generator
   * 
   * @generated
   */
  public IdPatternMetadata(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  /** @generated */
  public IdPatternMetadata(JCas jCas) {
    super(jCas);
    readObject();
  }

  /** @generated */
  public IdPatternMetadata(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  /**
   * <!-- begin-user-doc --> Write your own initialization here <!-- end-user-doc -->
   * 
   * @generated modifiable
   */
  private void readObject() {}


  // *--------------*
  // * Feature: MFIdPattern
  /**
   * getter for MFIdPattern
   * 
   * @generated
   */
  public String getMFIdPattern() {
    if (IdPatternMetadata_Type.featOkTst
        && ((IdPatternMetadata_Type) jcasType).casFeat_MFIdPattern == null) {
      jcasType.jcas.throwFeatMissing("MFIdPattern",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    return jcasType.ll_cas.ll_getStringValue(addr,
        ((IdPatternMetadata_Type) jcasType).casFeatCode_MFIdPattern);
  }

  /**
   * setter for MFIdPattern
   * 
   * @generated
   */
  public void setMFIdPattern(String v) {
    if (IdPatternMetadata_Type.featOkTst
        && ((IdPatternMetadata_Type) jcasType).casFeat_MFIdPattern == null) {
      jcasType.jcas.throwFeatMissing("MFIdPattern",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    jcasType.ll_cas.ll_setStringValue(addr,
        ((IdPatternMetadata_Type) jcasType).casFeatCode_MFIdPattern, v);
  }

  // *--------------*
  // * Feature: MFIdPatternFrequency
  /**
   * getter for MFIdPatternFrequency
   * 
   * @generated
   */
  public long getMFIdPatternFrequency() {
    if (IdPatternMetadata_Type.featOkTst
        && ((IdPatternMetadata_Type) jcasType).casFeat_MFIdPatternFrequency == null) {
      jcasType.jcas.throwFeatMissing("MFIdPatternFrequency",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    return jcasType.ll_cas.ll_getLongValue(addr,
        ((IdPatternMetadata_Type) jcasType).casFeatCode_MFIdPatternFrequency);
  }

  /**
   * setter for MFIdPatternFrequency
   * 
   * @generated
   */
  public void setMFIdPatternFrequency(long v) {
    if (IdPatternMetadata_Type.featOkTst
        && ((IdPatternMetadata_Type) jcasType).casFeat_MFIdPatternFrequency == null) {
      jcasType.jcas.throwFeatMissing("MFIdPatternFrequency",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    jcasType.ll_cas.ll_setLongValue(addr,
        ((IdPatternMetadata_Type) jcasType).casFeatCode_MFIdPatternFrequency, v);
  }

  // *--------------*
  // * Feature: MFIdPatternPct
  /**
   * getter for MFIdPatternPct
   * 
   * @generated
   */
  public double getMFIdPatternPct() {
    if (IdPatternMetadata_Type.featOkTst
        && ((IdPatternMetadata_Type) jcasType).casFeat_MFIdPatternPct == null) {
      jcasType.jcas.throwFeatMissing("MFIdPatternPct",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    return jcasType.ll_cas.ll_getDoubleValue(addr,
        ((IdPatternMetadata_Type) jcasType).casFeatCode_MFIdPatternPct);
  }

  /**
   * setter for MFIdPatternPct
   * 
   * @generated
   */
  public void setMFIdPatternPct(double v) {
    if (IdPatternMetadata_Type.featOkTst
        && ((IdPatternMetadata_Type) jcasType).casFeat_MFIdPatternPct == null) {
      jcasType.jcas.throwFeatMissing("MFIdPatternPct",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    jcasType.ll_cas.ll_setDoubleValue(addr,
        ((IdPatternMetadata_Type) jcasType).casFeatCode_MFIdPatternPct, v);
  }

  // *--------------*
  // * Feature: minimumFrequency
  /**
   * getter for minimumFrequency
   * 
   * @generated
   */
  public long getMinimumFrequency() {
    if (IdPatternMetadata_Type.featOkTst
        && ((IdPatternMetadata_Type) jcasType).casFeat_minimumFrequency == null) {
      jcasType.jcas.throwFeatMissing("minimumFrequency",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    return jcasType.ll_cas.ll_getLongValue(addr,
        ((IdPatternMetadata_Type) jcasType).casFeatCode_minimumFrequency);
  }

  /**
   * setter for minimumFrequency
   * 
   * @generated
   */
  public void setMinimumFrequency(long v) {
    if (IdPatternMetadata_Type.featOkTst
        && ((IdPatternMetadata_Type) jcasType).casFeat_minimumFrequency == null) {
      jcasType.jcas.throwFeatMissing("minimumFrequency",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    jcasType.ll_cas.ll_setLongValue(addr,
        ((IdPatternMetadata_Type) jcasType).casFeatCode_minimumFrequency, v);
  }

  // *--------------*
  // * Feature: totalIdPatterns
  /**
   * getter for totalIdPatterns
   * 
   * @generated
   */
  public int getTotalIdPatterns() {
    if (IdPatternMetadata_Type.featOkTst
        && ((IdPatternMetadata_Type) jcasType).casFeat_totalIdPatterns == null) {
      jcasType.jcas.throwFeatMissing("totalIdPatterns",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    return jcasType.ll_cas.ll_getIntValue(addr,
        ((IdPatternMetadata_Type) jcasType).casFeatCode_totalIdPatterns);
  }

  /**
   * setter for totalIdPatterns
   * 
   * @generated
   */
  public void setTotalIdPatterns(int v) {
    if (IdPatternMetadata_Type.featOkTst
        && ((IdPatternMetadata_Type) jcasType).casFeat_totalIdPatterns == null) {
      jcasType.jcas.throwFeatMissing("totalIdPatterns",
          "lu.svv.saa.requirements.autofinding.type.IdPatternMetadata");
    }
    jcasType.ll_cas.ll_setIntValue(addr,
        ((IdPatternMetadata_Type) jcasType).casFeatCode_totalIdPatterns, v);
  }

}
