/**
 * Analyzing the document and extracting useful features on the global level
 */
/**
 * @author <a href="mailto:sallam.abualhaija@uni.lu">Sallam Abualhaija</a> 
 *
 */
package lu.svv.saa.requirements.autofinding.analysis;
