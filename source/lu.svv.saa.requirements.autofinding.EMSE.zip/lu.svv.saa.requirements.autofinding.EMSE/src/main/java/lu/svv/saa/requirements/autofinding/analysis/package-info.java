/**
 * Analyzing the document and extracting useful features on the global level
 */
/**
 * @author sallam.abualhaija
 *
 */
package lu.svv.saa.requirements.autofinding.analysis;
