package lu.svv.saa.requirements.autofinding.type;

import org.apache.uima.cas.Feature;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.tcas.Annotation_Type;


public class SyntacticalFeatures_Type extends Annotation_Type {
  /** @generated */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  protected FSGenerator getFSGenerator() {
    return fsGenerator;
  }

  /** @generated */
  @SuppressWarnings("rawtypes")
  private final FSGenerator fsGenerator = new FSGenerator() {
    public FeatureStructure createFS(int addr, CASImpl cas) {
      if (SyntacticalFeatures_Type.this.useExistingInstance) {
        // Return eq fs instance if already created
        FeatureStructure fs = SyntacticalFeatures_Type.this.jcas.getJfsFromCaddr(addr);
        if (null == fs) {
          fs = new SyntacticalFeatures(addr, SyntacticalFeatures_Type.this);
          SyntacticalFeatures_Type.this.jcas.putJfsFromCaddr(addr, fs);
          return fs;
        }
        return fs;
      } else {
        return new SyntacticalFeatures(addr, SyntacticalFeatures_Type.this);
      }
    }
  };
  /** @generated */
  public final static int typeIndexID = SyntacticalFeatures.typeIndexID;
  /**
   * @generated
   * @modifiable
   */
  public final static boolean featOkTst =
      JCasRegistry.getFeatOkTst("lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");

  /**** Feature: sentenceType ****/
  /** @generated */
  final Feature casFeat_sentenceType;
  /** @generated */
  final int casFeatCode_sentenceType;

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @return the feature value
   */
  public int getSentenceType(int addr) {
    if (featOkTst && casFeat_sentenceType == null)
      jcas.throwFeatMissing("sentenceType",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    return ll_cas.ll_getRefValue(addr, casFeatCode_sentenceType);
  }

  /**
   * @generated
   * @param addr low level Feature Structure reference
   * @param v value to set
   */
  public void setSentenceType(int addr, int v) {
    if (featOkTst && casFeat_sentenceType == null)
      jcas.throwFeatMissing("sentenceType",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    ll_cas.ll_setRefValue(addr, casFeatCode_sentenceType, v);
  }

  /**** Feature: hasVerb ****/
  /** @generated */
  final Feature casFeat_hasVerb;
  /** @generated */
  final int casFeatCode_hasVerb;

  /** @generated */
  public boolean hasVerb(int addr) {
    if (featOkTst && casFeat_hasVerb == null) {
      jcas.throwFeatMissing("hasVerb",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_hasVerb);
  }

  /** @generated */
  public void setHasVerb(int addr, boolean v) {
    if (featOkTst && casFeat_hasVerb == null) {
      jcas.throwFeatMissing("hasVerb",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_hasVerb, v);
  }


  /**** Feature: startsWithVerb ***/
  /** @generated */
  final Feature casFeat_startsWithVerb;
  /** @generated */
  final int casFeatCode_startsWithVerb;

  /** @generated */
  public boolean startsWithVerb(int addr) {
    if (featOkTst && casFeat_startsWithVerb == null) {
      jcas.throwFeatMissing("startsWithVerb",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_startsWithVerb);
  }

  /** @generated */
  public void setStartsWithVerb(int addr, boolean v) {
    if (featOkTst && casFeat_startsWithVerb == null) {
      jcas.throwFeatMissing("startsWithVerb",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_startsWithVerb, v);
  }

  /**** Feature: startsWithPronoun ***/
  /** @generated */
  final Feature casFeat_startsWithPronoun;
  /** @generated */
  final int casFeatCode_startsWithPronoun;

  /** @generated */
  public boolean startsWithPronoun(int addr) {
    if (featOkTst && casFeat_startsWithPronoun == null) {
      jcas.throwFeatMissing("startsWithPronoun",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_startsWithPronoun);
  }

  /** @generated */
  public void setStartsWithPronoun(int addr, boolean v) {
    if (featOkTst && casFeat_startsWithPronoun == null) {
      jcas.throwFeatMissing("startsWithPronoun",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_startsWithPronoun, v);
  }

  /**** Feature: startsWithDTVB ***/
  /** @generated */
  final Feature casFeat_startsWithDTVB;
  /** @generated */
  final int casFeatCode_startsWithDTVB;

  /** @generated */
  public boolean startsWithDTVB(int addr) {
    if (featOkTst && casFeat_startsWithDTVB == null) {
      jcas.throwFeatMissing("startsWithDTVB",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_startsWithDTVB);
  }

  /** @generated */
  public void setStartsWithDTVB(int addr, boolean v) {
    if (featOkTst && casFeat_startsWithDTVB == null) {
      jcas.throwFeatMissing("startsWithDTVB",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_startsWithDTVB, v);
  }

  /**** Feature: hasModal ****/
  /** @generated */
  final Feature casFeat_hasModal;
  /** @generated */
  final int casFeatCode_hasModal;

  /** @generated */
  public boolean hasModal(int addr) {
    if (featOkTst && casFeat_hasModal == null) {
      jcas.throwFeatMissing("hasModal",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_hasModal);
  }

  /** @generated */
  public void sethasModal(int addr, boolean v) {
    if (featOkTst && casFeat_hasModal == null) {
      jcas.throwFeatMissing("hasModal",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_hasModal, v);
  }

  /**** Feature: whichModals ****/
  /** @generated */
  final Feature casFeat_whichModals;
  /** @generated */
  final int casFeatCode_whichModals;

  /** @generated */
  public String getWhichModals(int addr) {
    if (featOkTst && casFeat_whichModals == null) {
      jcas.throwFeatMissing("whichModals",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return ll_cas.ll_getStringValue(addr, casFeatCode_whichModals);
  }

  /** @generated */
  public void setWhichModals(int addr, String v) {
    if (featOkTst && casFeat_whichModals == null) {
      jcas.throwFeatMissing("whichModals",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    ll_cas.ll_setStringValue(addr, casFeatCode_whichModals, v);
  }

  /**** Feature: hasNPmodalVP ***/
  /** @generated */
  final Feature casFeat_hasNPmodalVP;
  /** @generated */
  final int casFeatCode_hasNPmodalVP;

  /** @generated */
  public boolean hasNPmodalVP(int addr) {
    if (featOkTst && casFeat_hasNPmodalVP == null) {
      jcas.throwFeatMissing("hasNPmodalVP",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_hasNPmodalVP);
  }

  /** @generated */
  public void setHasNPmodalVP(int addr, boolean v) {
    if (featOkTst && casFeat_hasNPmodalVP == null) {
      jcas.throwFeatMissing("hasNPmodalVP",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_hasNPmodalVP, v);
  }

  /**** Feature: isConditional ***/
  /** @generated */
  final Feature casFeat_isConditional;
  /** @generated */
  final int casFeatCode_isConditional;

  /** @generated */
  public boolean isConditional(int addr) {
    if (featOkTst && casFeat_isConditional == null) {
      jcas.throwFeatMissing("isConditional",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_isConditional);
  }

  /** @generated */
  public void setIsConditional(int addr, boolean v) {
    if (featOkTst && casFeat_isConditional == null) {
      jcas.throwFeatMissing("isConditional",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_isConditional, v);
  }


  /**** Feature: hasPassive ***/
  /** @generated */
  final Feature casFeat_hasPassive;
  /** @generated */
  final int casFeatCode_hasPassive;

  /** @generated */
  public boolean hasPassive(int addr) {
    if (featOkTst && casFeat_hasPassive == null) {
      jcas.throwFeatMissing("hasPassive",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_hasPassive);
  }

  /** @generated */
  public void setHasPassive(int addr, boolean v) {
    if (featOkTst && casFeat_hasPassive == null) {
      jcas.throwFeatMissing("hasPassive",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_hasPassive, v);
  }
  
  /**** Feature: isPresentTense ***/
  /** @generated */
  final Feature casFeat_isPresentTense;
  /** @generated */
  final int casFeatCode_isPresentTense;

  /** @generated */
  public boolean isPresentTense(int addr) {
    if (featOkTst && casFeat_isPresentTense == null) {
      jcas.throwFeatMissing("isPresentTense",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_isPresentTense);
  }

  /** @generated */
  public void setIsPresentTense(int addr, boolean v) {
    if (featOkTst && casFeat_isPresentTense == null) {
      jcas.throwFeatMissing("isPresentTense",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_isPresentTense, v);
  }
  
  /**** Feature: hasVerbToBeAdj ***/
  /** @generated */
  final Feature casFeat_hasVerbToBeAdj;
  /** @generated */
  final int casFeatCode_hasVerbToBeAdj;

  /** @generated */
  public boolean hasVerbToBeAdj(int addr) {
    if (featOkTst && casFeat_hasVerbToBeAdj == null) {
      jcas.throwFeatMissing("hasVerbToBeAdj",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    return ll_cas.ll_getBooleanValue(addr, casFeatCode_hasVerbToBeAdj);
  }

  /** @generated */
  public void sethasVerbToBeAdj(int addr, boolean v) {
    if (featOkTst && casFeat_hasVerbToBeAdj == null) {
      jcas.throwFeatMissing("hasVerbToBeAdj",
          "lu.svv.saa.requirements.autofinding.type.SyntacticalFeatures");
    }
    ll_cas.ll_setBooleanValue(addr, casFeatCode_hasVerbToBeAdj, v);
  }
  
  /**
   * initialize variables to correspond with Cas Type and Features
   * 
   * @generated
   */
  public SyntacticalFeatures_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl) this.casType, getFSGenerator());

    casFeat_sentenceType = jcas.getRequiredFeatureDE(casType, "sentenceType",
        "lu.svv.saa.requirements.autofinding.type.SentenceType", featOkTst);
    casFeatCode_sentenceType = (null == casFeat_sentenceType) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_sentenceType).getCode();

    casFeat_hasVerb = jcas.getRequiredFeatureDE(casType, "hasVerb", "uima.cas.Boolean", featOkTst);
    casFeatCode_hasVerb = (null == casFeat_hasVerb) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_hasVerb).getCode();

    casFeat_startsWithVerb =
        jcas.getRequiredFeatureDE(casType, "startsWithVerb", "uima.cas.Boolean", featOkTst);
    casFeatCode_startsWithVerb = (null == casFeat_startsWithVerb) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_startsWithVerb).getCode();

    casFeat_startsWithPronoun =
        jcas.getRequiredFeatureDE(casType, "startsWithPronoun", "uima.cas.Boolean", featOkTst);
    casFeatCode_startsWithPronoun = (null == casFeat_startsWithPronoun) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_startsWithPronoun).getCode();

    casFeat_startsWithDTVB =
        jcas.getRequiredFeatureDE(casType, "startsWithDTVB", "uima.cas.Boolean", featOkTst);
    casFeatCode_startsWithDTVB = (null == casFeat_startsWithDTVB) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_startsWithDTVB).getCode();

    casFeat_hasModal =
        jcas.getRequiredFeatureDE(casType, "hasModal", "uima.cas.Boolean", featOkTst);
    casFeatCode_hasModal = (null == casFeat_hasModal) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_hasModal).getCode();

    casFeat_whichModals =
        jcas.getRequiredFeatureDE(casType, "whichModals", "uima.cas.String", featOkTst);
    casFeatCode_whichModals = (null == casFeat_whichModals) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_whichModals).getCode();

    casFeat_isConditional =
        jcas.getRequiredFeatureDE(casType, "isConditional", "uima.cas.Boolean", featOkTst);
    casFeatCode_isConditional = (null == casFeat_isConditional) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_isConditional).getCode();

    casFeat_hasNPmodalVP =
        jcas.getRequiredFeatureDE(casType, "hasNPmodalVP", "uima.cas.Boolean", featOkTst);
    casFeatCode_hasNPmodalVP = (null == casFeat_hasNPmodalVP) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_hasNPmodalVP).getCode();

    casFeat_hasPassive =
        jcas.getRequiredFeatureDE(casType, "hasPassive", "uima.cas.Boolean", featOkTst);
    casFeatCode_hasPassive = (null == casFeat_hasPassive) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_hasPassive).getCode();
    
    casFeat_isPresentTense =
        jcas.getRequiredFeatureDE(casType, "isPresentTense", "uima.cas.Boolean", featOkTst);
    casFeatCode_isPresentTense = (null == casFeat_isPresentTense) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_isPresentTense).getCode();
   
    casFeat_hasVerbToBeAdj =
        jcas.getRequiredFeatureDE(casType, "hasVerbToBeAdj", "uima.cas.Boolean", featOkTst);
    casFeatCode_hasVerbToBeAdj = (null == casFeat_hasVerbToBeAdj) ? JCas.INVALID_FEATURE_CODE
        : ((FeatureImpl) casFeat_hasVerbToBeAdj).getCode();
  
    
  }

}
