/**
 * class with the main method 
 */
/**
 * @author sallam.abualhaija
 *
 */
package lu.svv.saa.requirements.autofinding.pipelines;
